package com.example.autofire

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.TextView

class OverlayService : Service() {
    companion object { @Volatile var running = false }

    private lateinit var wm: WindowManager
    private lateinit var a: TextView
    private lateinit var b: TextView
    private lateinit var lock: TextView
    private lateinit var aBg: GradientDrawable
    private val lpA by lazy { params(100, 600) }
    private val lpB by lazy { params(100, 300) }
    private val lpL by lazy { params(20, 120) }
    private var locked = false
    private var firing = false
    private var gen = 0
    private var curSz = 0
    private val h = Handler(Looper.getMainLooper())

    private fun prefs() = getSharedPreferences("cfg", MODE_PRIVATE)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toggleMode() = prefs().getBoolean("toggle", false)

    private fun params(x: Int, y: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
        PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun circle(label: String, bg: GradientDrawable, sizePx: Int) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        width = sizePx; height = sizePx; background = bg
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(color); setStroke(dp(2), Color.WHITE)
    }

    // ---- Ateş döngüsü: her tıklama bitince bir sonrakini planlar (üst üste binmez) ----
    private fun startFire() { if (firing) return; firing = true; gen++; setFiringUi(true); loop(gen) }
    private fun stopFire() { firing = false; gen++; h.removeCallbacksAndMessages(null); setFiringUi(false) }

    private fun loop(g: Int) {
        if (!firing || g != gen) return
        val svc = TapService.instance
        if (svc == null) { h.postDelayed({ loop(g) }, 300); return }
        val c = prefs()
        val dur = c.getInt("duration", 25).toLong()
        val gap = maxOf(c.getInt("interval", 100) - dur, 20L)
        val loc = IntArray(2); b.getLocationOnScreen(loc)
        svc.tap(loc[0] + b.width / 2f, loc[1] + b.height / 2f, dur) {
            if (firing && g == gen) h.postDelayed({ loop(g) }, gap)
        }
    }

    private fun setFiringUi(on: Boolean) {
        aBg.setColor(if (on) Color.parseColor("#2E7D32") else Color.parseColor("#D32F2F"))
        a.text = if (on && toggleMode()) "■" else "A"
    }

    // ---- Sürükleme ----
    private fun drag(v: View, lp: WindowManager.LayoutParams, onTap: (() -> Unit)? = null,
                     onDown: (() -> Unit)? = null, onUp: (() -> Unit)? = null,
                     canDrag: () -> Boolean = { true }) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; onDown?.invoke() }
                MotionEvent.ACTION_MOVE -> if (canDrag()) {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true
                    lp.x = ox + dx; lp.y = oy + dy; wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    onUp?.invoke(); if (!moved && e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
                }
            }
            true
        }
    }

    private fun applyLock() {
        lock.text = if (locked) "🔒" else "🔓"
        lpB.flags = if (locked) lpB.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    else lpB.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        wm.updateViewLayout(b, lpB)
        if (!locked) stopFire()
    }

    // ---- Canlı ayar: boyut + saydamlık ----
    private fun applySettings() {
        val sz = dp(prefs().getInt("size", 60))
        if (sz != curSz) {
            val d = (curSz - sz) / 2
            for ((v, lp) in listOf(a to lpA, b to lpB)) {
                lp.x += d; lp.y += d
                v.width = sz; v.height = sz
                v.textSize = sz / resources.displayMetrics.density * 0.33f
                wm.updateViewLayout(v, lp)
            }
            curSz = sz
        }
        val al = prefs().getInt("alpha", 80) / 100f
        a.alpha = al; b.alpha = al; lock.alpha = maxOf(al, 0.5f)
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "UPDATE") applySettings()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        val ch = NotificationChannel("af", "AutoFire", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        startForeground(1, Notification.Builder(this, "af").setContentTitle("AutoFire çalışıyor")
            .setSmallIcon(android.R.drawable.ic_menu_compass).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        curSz = dp(prefs().getInt("size", 60))
        aBg = oval(Color.parseColor("#D32F2F"))
        a = circle("A", aBg, curSz)
        b = circle("B", oval(Color.parseColor("#1976D2")), curSz)
        lock = circle("🔓", oval(Color.DKGRAY), dp(44))

        // A: kilitliyken -> basılı tut = ateş (veya "aç/kapa" modunda tek dokunuş)
        drag(a, lpA,
            onDown = {
                if (locked) {
                    if (toggleMode()) { if (firing) stopFire() else startFire() } else startFire()
                }
            },
            onUp = { if (!toggleMode()) stopFire() },
            canDrag = { !locked })
        drag(b, lpB, canDrag = { !locked })
        drag(lock, lpL, onTap = { locked = !locked; applyLock() }, canDrag = { !locked })

        wm.addView(a, lpA); wm.addView(b, lpB); wm.addView(lock, lpL)
        applySettings()
    }

    override fun onDestroy() {
        stopFire(); running = false
        listOf(a, b, lock).forEach { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }
    override fun onBind(i: Intent?): IBinder? = null
}
