package com.example.autofire

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class MainActivity : AppCompatActivity() {
    private val cBg = Color.parseColor("#0F1115")
    private val cCard = Color.parseColor("#1A1D24")
    private val cAccent = Color.parseColor("#FF5A36")
    private val cSub = Color.parseColor("#9AA3B2")
    private val cOk = Color.parseColor("#43D17A")
    private val cBad = Color.parseColor("#FF5A5A")

    private lateinit var tvAcc: TextView
    private lateinit var tvOv: TextView
    private lateinit var btnStart: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, r: Int = 16) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(color) }
    private fun prefs() = getSharedPreferences("cfg", MODE_PRIVATE)

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun card(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = rounded(cCard)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) }
        addView(tv(title, 15f, Color.WHITE, true))
    }

    private fun button(text: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); isAllCaps = false; textSize = 15f
        background = rounded(color, 12)
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(50)).apply { topMargin = dp(10) }
        setOnClickListener { onClick() }
    }

    private fun notifyService() {
        if (OverlayService.running)
            startService(Intent(this, OverlayService::class.java).setAction("UPDATE"))
    }

    private fun slider(parent: LinearLayout, label: String, unit: String, hint: String,
                       key: String, min: Int, max: Int, def: Int) {
        val v = prefs().getInt(key, def).coerceIn(min, max)
        val t = tv("$label: $v $unit", 14f, Color.WHITE).apply { setPadding(0, dp(14), 0, 0) }
        val s = SeekBar(this).apply {
            this.max = max - min; progress = v - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, pr: Int, u: Boolean) {
                    t.text = "$label: ${pr + min} $unit"
                    prefs().edit().putInt(key, pr + min).apply()
                    notifyService()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        parent.addView(t); parent.addView(s)
        parent.addView(tv(hint, 11f, cSub))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(36), dp(16), dp(24))
        }
        root.addView(tv("AutoFire", 28f, Color.WHITE, true))
        root.addView(tv("Tekli silahlar için otomatik tıklama", 13f, cSub))

        // Durum
        val st = card("1 · İzinler")
        tvAcc = tv("", 14f, Color.WHITE).apply { setPadding(0, dp(10), 0, 0) }
        tvOv = tv("", 14f, Color.WHITE).apply { setPadding(0, dp(4), 0, 0) }
        st.addView(tvAcc); st.addView(tvOv)
        st.addView(button("Erişilebilirlik ayarlarını aç", Color.parseColor("#2C3140")) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "\"AutoFire Tap\" servisini bulup aç", Toast.LENGTH_LONG).show()
        })
        st.addView(button("Üstte gösterme iznini aç", Color.parseColor("#2C3140")) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(st)

        // Başlat
        val go = card("2 · Başlat")
        btnStart = button("BAŞLAT", cAccent) { toggleService() }
        go.addView(btnStart)
        root.addView(go)

        // Ayarlar
        val set = card("3 · Ayarlar (anında uygulanır)")
        slider(set, "Buton boyutu", "dp", "A ve B butonlarının büyüklüğü", "size", 30, 120, 60)
        slider(set, "Saydamlık", "%", "Düşük değer = daha saydam", "alpha", 20, 100, 80)
        slider(set, "Tıklama aralığı", "ms", "İki tıklama arası süre. Küçük = hızlı ateş. Tıklamalar algılanmazsa artır.", "interval", 40, 400, 100)
        slider(set, "Tıklama süresi", "ms", "Her tıklamanın parmakta kalma süresi", "duration", 5, 80, 25)
        val sw = SwitchCompat(this).apply {
            text = "Aç/Kapa modu (A'ya bir kez bas)"; setTextColor(Color.WHITE)
            isChecked = prefs().getBoolean("toggle", false)
            setPadding(0, dp(16), 0, 0)
            setOnCheckedChangeListener { _, c -> prefs().edit().putBoolean("toggle", c).apply() }
        }
        set.addView(sw)
        set.addView(tv("Basılı tutmak yerine A'ya bir kez basınca ateş başlar, tekrar basınca durur. " +
            "Nişan alırken ya da dürbün açarken oyun takılıyorsa bu modu aç.", 11f, cSub))
        root.addView(set)

        // Kullanım
        val how = card("Nasıl kullanılır?")
        how.addView(tv("1. Erişilebilirlikten \"AutoFire Tap\" servisini aç.\n" +
            "2. BAŞLAT'a bas, sonra PUBG'i aç.\n" +
            "3. 🔓 açıkken B'yi (mavi) ateş tuşunun tam üstüne sürükle. A'yı (kırmızı) rahat basacağın yere koy.\n" +
            "4. 🔒'e bas: butonlar kilitlenir, B dokunmaya kapanır.\n" +
            "5. A'ya basılı tut: B'nin altındaki ateş tuşuna ard arda tıklama gider. " +
            "Düzenlemek için tekrar 🔓'e bas.", 13f, cSub).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.15f) })
        root.addView(how)

        setContentView(ScrollView(this).apply { setBackgroundColor(cBg); addView(root) })
    }

    private fun toggleService() {
        when {
            OverlayService.running -> stopService(Intent(this, OverlayService::class.java))
            TapService.instance == null ->
                Toast.makeText(this, "Önce erişilebilirlik servisini aç", Toast.LENGTH_LONG).show()
            !Settings.canDrawOverlays(this) ->
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else -> startForegroundService(Intent(this, OverlayService::class.java))
        }
        btnStart.postDelayed({ refresh() }, 500)
    }

    private fun refresh() {
        val acc = TapService.instance != null
        val ov = Settings.canDrawOverlays(this)
        tvAcc.text = if (acc) "● Erişilebilirlik: Açık" else "● Erişilebilirlik: Kapalı"
        tvAcc.setTextColor(if (acc) cOk else cBad)
        tvOv.text = if (ov) "● Üstte gösterme: Açık" else "● Üstte gösterme: Kapalı"
        tvOv.setTextColor(if (ov) cOk else cBad)
        btnStart.text = if (OverlayService.running) "DURDUR" else "BAŞLAT"
        btnStart.background = rounded(if (OverlayService.running) Color.parseColor("#C62828") else cAccent, 12)
    }

    override fun onResume() { super.onResume(); refresh() }
}
