# AZ PadView — lightweight Android gaming utility

A Kotlin Android starter project with a dark blue lightweight UI, Shizuku-based display-size commands, screen/device diagnostics, and an optional compact overlay showing approximate RAM use, battery percentage, and Android thermal status.

## Build APK on GitHub from a phone
1. Upload the **contents** of this folder to the root of a GitHub repository (the `.github/workflows/build-apk.yml` file must remain inside `.github/workflows/`).
2. Open the repository's **Actions** tab.
3. Select **Build AZ PadView APK** and tap **Run workflow**, or push a commit to `main` / `master`.
4. Open the completed run and download the `AZ-PadView-debug` artifact.

The workflow installs JDK 17, Android SDK platform 35, build-tools 35.0.0 and Gradle 8.9. This project does not currently include a Gradle wrapper, so the workflow installs and invokes Gradle directly.

## Features in this starter
- Shizuku permission check and user-service connection.
- Logical screen size and density information.
- A 4:3 display-size test and reset commands.
- Approximate system RAM use, battery percentage, and thermal status.
- Optional foreground overlay; the overlay is off unless the user starts it and grants Android's “display over other apps” permission. It refreshes every 10 seconds and does not claim to measure PUBG's FPS.
- Shortcuts to Android display and Do Not Disturb settings.

## Important limits
- This is a starter MVP, not a verified exact clone of any other app.
- Shizuku must be installed and started by the user. Device/Android vendor restrictions may limit available commands.
- A 4:3 virtual display size does not guarantee an iPad-like field of view, better FPS, or fair-play compatibility in any game.
- The overlay uses a foreground service and a small notification. Some devices may restrict overlays over games.
- Test display changes carefully. Recovery commands through Shizuku/ADB are `wm size reset` and `wm density reset`.

## Build status
The source has not been compiled in the authoring environment because an Android SDK and Gradle installation are unavailable there. GitHub Actions is configured to perform the build. If a build fails, the workflow uploads a `build-log` artifact (build.log + Gradle reports) that can be downloaded from the run page.
