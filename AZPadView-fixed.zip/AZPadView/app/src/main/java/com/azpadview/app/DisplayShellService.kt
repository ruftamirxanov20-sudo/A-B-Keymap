package com.azpadview.app

import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Runs only the display commands exposed by the AIDL interface.
 *
 * Errors are reported with IllegalStateException / IllegalArgumentException because
 * Binder can marshal those back to the caller. A checked RemoteException thrown from
 * a Stub would not be marshaled and could crash this service process.
 */
class DisplayShellService : IDisplayShell.Stub() {
    override fun applySize(width: Int, height: Int): String {
        if (width !in 320..10000 || height !in 320..10000) {
            throw IllegalArgumentException("Geçersiz ekran boyutu.")
        }
        return execute(arrayOf("wm", "size", "${width}x${height}"))
    }

    override fun resetDisplay(): String {
        val size = execute(arrayOf("wm", "size", "reset"))
        val density = execute(arrayOf("wm", "density", "reset"))
        return "$size\n$density"
    }

    private fun execute(args: Array<String>): String {
        val process = try {
            Runtime.getRuntime().exec(args)
        } catch (e: Exception) {
            throw IllegalStateException(e.message ?: "Komut çalıştırılamadı.")
        }
        val out = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
        val err = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
        val code = process.waitFor()
        val result = listOf(out.trim(), err.trim(), "exit=$code").filter { it.isNotEmpty() }.joinToString("\n")
        if (code != 0) throw IllegalStateException(result)
        return result
    }

    override fun destroy() {
        System.exit(0)
    }
}
