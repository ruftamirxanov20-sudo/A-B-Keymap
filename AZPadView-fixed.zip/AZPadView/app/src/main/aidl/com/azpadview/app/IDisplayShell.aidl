package com.azpadview.app;

interface IDisplayShell {
    // Shizuku's reserved destroy() transaction. When explicit IDs are used,
    // EVERY method in the interface must have one.
    void destroy() = 16777114;

    String applySize(int width, int height) = 1;
    String resetDisplay() = 2;
}
