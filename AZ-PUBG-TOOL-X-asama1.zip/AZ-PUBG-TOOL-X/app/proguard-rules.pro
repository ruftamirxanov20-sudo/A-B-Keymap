# Aşama 8'de küçültme açıldığında Shizuku için gerekirse kurallar buraya eklenecek.
-keep class rikka.shizuku.** { *; }
