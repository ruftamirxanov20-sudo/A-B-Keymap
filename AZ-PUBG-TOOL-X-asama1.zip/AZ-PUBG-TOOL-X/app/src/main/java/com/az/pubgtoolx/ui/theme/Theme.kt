package com.az.pubgtoolx.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AzColorScheme = darkColorScheme(
    primary = CyberPrimary,
    onPrimary = Color.White,
    secondary = CyberSecondary,
    onSecondary = Color.White,
    background = CyberBackground,
    onBackground = CyberText,
    surface = CyberSurface,
    onSurface = CyberText,
    surfaceVariant = CyberSurface,
    onSurfaceVariant = CyberTextMuted,
    outline = CyberOutline,
    error = CyberError,
)

@Composable
fun AzTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AzColorScheme,
        typography = Typography(),
        content = content,
    )
}
