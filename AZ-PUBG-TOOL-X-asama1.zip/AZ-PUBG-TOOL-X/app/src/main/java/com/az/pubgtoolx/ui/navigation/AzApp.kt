package com.az.pubgtoolx.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.az.pubgtoolx.ui.screens.SettingsScreen
import com.az.pubgtoolx.ui.screens.StubScreen
import com.az.pubgtoolx.ui.screens.ToolsScreen
import com.az.pubgtoolx.ui.screens.home.HomeScreen
import com.az.pubgtoolx.ui.theme.CyberBackground
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSurface
import com.az.pubgtoolx.ui.theme.CyberText
import com.az.pubgtoolx.ui.theme.CyberTextMuted

private enum class BottomTab(val route: String, val label: String, val icon: ImageVector) {
    HOME("home", "Home", Icons.Filled.Home),
    TOOLS("tools", "Tools", Icons.Filled.Build),
    AIM("aim_lab", "Aim Lab", Icons.Filled.GpsFixed),
    PROFILES("profiles", "Profiles", Icons.Filled.Person),
    SETTINGS("settings", "Settings", Icons.Filled.Settings),
}

private const val MODULE_ROUTE = "module/{id}"

private fun NavController.openTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun AzApp() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val openModule: (ToolModule) -> Unit = { navController.navigate("module/${it.id}") }

    Scaffold(
        containerColor = CyberBackground,
        bottomBar = {
            NavigationBar(containerColor = CyberSurface, contentColor = CyberText) {
                BottomTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route,
                        onClick = { navController.openTab(tab.route) },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label, fontSize = 11.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberPrimary,
                            selectedTextColor = CyberPrimary,
                            indicatorColor = CyberPrimary.copy(alpha = 0.18f),
                            unselectedIconColor = CyberTextMuted,
                            unselectedTextColor = CyberTextMuted,
                        ),
                    )
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = BottomTab.HOME.route,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(BottomTab.HOME.route) {
                HomeScreen(
                    onOpenModule = openModule,
                    onOpenSettings = { navController.openTab(BottomTab.SETTINGS.route) },
                )
            }
            composable(BottomTab.TOOLS.route) {
                ToolsScreen(onOpenModule = openModule)
            }
            composable(BottomTab.AIM.route) {
                StubScreen(
                    title = "Aim Lab",
                    description = "Nişan antrenmanı modları ve geçmişi",
                    stage = ToolModule.AIM_TRAINING.stage,
                    icon = ToolModule.AIM_TRAINING.icon,
                )
            }
            composable(BottomTab.PROFILES.route) {
                StubScreen(
                    title = "Profiles",
                    description = "Hassasiyet ve HUD profilleri",
                    stage = ToolModule.SENSITIVITY.stage,
                    icon = ToolModule.SENSITIVITY.icon,
                )
            }
            composable(BottomTab.SETTINGS.route) {
                SettingsScreen()
            }
            composable(MODULE_ROUTE) { entry ->
                val module = ToolModule.fromId(entry.arguments?.getString("id"))
                if (module != null) {
                    StubScreen(
                        title = module.title,
                        description = module.description,
                        stage = module.stage,
                        icon = module.icon,
                        onBack = { navController.popBackStack() },
                    )
                }
            }
        }
    }
}
