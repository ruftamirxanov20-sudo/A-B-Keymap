package com.az.pubgtoolx.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.navigation.ToolModule
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning

@Composable
fun ToolsScreen(onOpenModule: (ToolModule) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Text("Tools", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text("Tüm modüller ve geliştirme aşamaları", fontSize = 13.sp, color = CyberTextMuted)
        }
        items(ToolModule.entries) { module ->
            CyberCard(modifier = Modifier.fillMaxWidth(), onClick = { onOpenModule(module) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(module.icon, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(module.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(module.description, fontSize = 12.sp, color = CyberTextMuted)
                    }
                    Text("Aşama ${module.stage}", fontSize = 11.sp, color = CyberWarning)
                }
            }
        }
    }
}
