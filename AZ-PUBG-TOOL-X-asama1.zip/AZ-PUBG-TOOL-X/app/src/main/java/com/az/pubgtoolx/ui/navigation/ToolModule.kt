package com.az.pubgtoolx.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Uygulamadaki tüm modüller. [stage] = modülün geliştirileceği aşama.
 * Aşaması gelmemiş modüller dürüstçe "geliştirmede" olarak gösterilir.
 */
enum class ToolModule(
    val id: String,
    val title: String,
    val shortTitle: String,
    val description: String,
    val stage: Int,
    val icon: ImageVector,
) {
    AIM_TRAINING("aim", "Aim Training Lab", "Aim Training", "Nişan antrenman simülatörü", 3, Icons.Filled.GpsFixed),
    SENSITIVITY("sensitivity", "Sensitivity Studio", "Sensitivity", "Hassasiyet profilleri", 4, Icons.Filled.Tune),
    HUD("hud", "HUD Designer", "HUD Designer", "Parmak düzeni editörü", 4, Icons.Filled.Dashboard),
    FPS_LAB("fps", "FPS & Graphics Lab", "FPS & Graphics", "FPS ve performans izleme", 5, Icons.Filled.BarChart),
    COMPAT("compat", "Device Compatibility", "Compatibility", "Cihaz uyumluluk motoru", 5, Icons.Filled.PhoneAndroid),
    POTATO("potato", "Potato Graphics", "Potato Graphics", "Düşük grafik rehberi", 5, Icons.Filled.Speed),
    ACTIVE_SAV("activesav", "Active.sav Manager", "Active.sav", "Dosya analizi ve yedekleme", 6, Icons.Filled.Save),
    RESOLUTION("resolution", "Resolution & iPad View", "Resolution", "Çözünürlük ve iPad görünümü", 6, Icons.Filled.AspectRatio),
    DPI("dpi", "DP/DPI Controller", "DP/DPI", "DPI profilleri", 6, Icons.Filled.Straighten),
    CLEANER("cleaner", "Phone Cleaner", "Cleaner", "Önbellek ve depolama analizi", 7, Icons.Filled.CleaningServices),
    WEAPONS("weapons", "Weapon Database", "Weapons", "Silah verileri ve karşılaştırma", 7, Icons.Filled.Storage),
    OVERLAY("overlay", "Gaming Overlay", "Overlay", "İsteğe bağlı kayan panel", 7, Icons.Filled.Layers);

    companion object {
        /** Ana ekrandaki hızlı erişim kutucukları. */
        val homeTiles: List<ToolModule> = listOf(
            AIM_TRAINING, SENSITIVITY, HUD, FPS_LAB, RESOLUTION, CLEANER,
        )

        fun fromId(id: String?): ToolModule? = entries.firstOrNull { it.id == id }
    }
}
