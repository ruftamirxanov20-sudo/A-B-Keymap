package com.az.pubgtoolx.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.az.pubgtoolx.BuildConfig
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning

@Composable
fun SettingsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)

        CyberCard(modifier = Modifier.fillMaxWidth()) {
            Text("Hakkında", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            InfoLine("Uygulama", "AZ PUBG TOOL X")
            InfoLine("Sürüm", BuildConfig.VERSION_NAME)
            InfoLine("Paket", BuildConfig.APPLICATION_ID)
            InfoLine("Tema", "Cyber Blue (sabit)")
        }

        CyberCard(modifier = Modifier.fillMaxWidth()) {
            Text("Geliştirmede", color = CyberWarning, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Ayar seçenekleri (yedekleme, dil, bildirimler) sonraki aşamalarda eklenecek. Şu an değiştirilebilir bir ayar yok.",
                fontSize = 13.sp,
                color = CyberTextMuted,
            )
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 13.sp, color = CyberTextMuted)
        Text(value, fontSize = 13.sp)
    }
}
