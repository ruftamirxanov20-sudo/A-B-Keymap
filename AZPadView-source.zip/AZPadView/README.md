# AZ PadView (starter MVP)

A minimal Android display utility prototype with Shizuku permission handling and a GitHub Actions debug APK workflow.

## Important limitations
- This is an initial starter project, not a verified exact clone of Cat Resolution Pro.
- The interface is original and simplified; use screenshots from the reference app to refine it.
- Android games may not gain iPad camera/FOV from display-size changes.
- Test on a spare/accessible device first. Display changes can make the UI awkward to use.

## Build
Push the repository to GitHub, then open **Actions → Build AZ PadView APK → Run workflow**. Download the `AZ-PadView-debug` artifact after a successful run.

## Recovery
If display overrides cause problems, use Shizuku/ADB shell:

```sh
wm size reset
wm density reset
```
