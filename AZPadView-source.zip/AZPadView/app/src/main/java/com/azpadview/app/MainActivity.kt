package com.azpadview.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 13, 18)
    private val panel = Color.rgb(20, 27, 35)
    private val mint = Color.rgb(53, 242, 181)
    private val white = Color.rgb(239, 245, 249)
    private val muted = Color.rgb(157, 174, 188)
    private lateinit var status: TextView
    private lateinit var deviceInfo: TextView
    private val worker = Executors.newSingleThreadExecutor()
    private val requestCode = 421
    @Volatile private var remoteShell: IDisplayShell? = null
    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(this, DisplayShellService::class.java))
            .daemon(false).processNameSuffix("azpadview_shell").tag("AZPadViewShell").version(1)
    }
    private val shellConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            remoteShell = IDisplayShell.Stub.asInterface(service)
            runOnUiThread { status.text = "● Shizuku bağlı ve hazır"; status.setTextColor(mint) }
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            remoteShell = null
            runOnUiThread { status.text = "● Shizuku bağlantısı kesildi"; status.setTextColor(Color.RED) }
        }
    }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, grantResult ->
        if (code == requestCode) {
            runOnUiThread {
                status.text = if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) "● Shizuku izni verildi" else "● Shizuku izni verilmedi"
                status.setTextColor(if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) mint else Color.rgb(255, 110, 110))
                if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) connectUserService()
                refreshInfo()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        buildUi()
        refreshInfo()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(20), dp(18), dp(20)) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brand = TextView(this).apply { text = "AZ PADVIEW"; textSize = 27f; setTextColor(mint); typeface = android.graphics.Typeface.DEFAULT_BOLD; letterSpacing = .08f }
        content.addView(brand)
        content.addView(text("TABLET VIEW • DISPLAY TOOL", 11f, muted).apply { setPadding(0, dp(4), 0, dp(18)); letterSpacing = .12f })

        val hero = card()
        hero.addView(text("Ekran ayarları", 20f, white, true))
        hero.addView(text("Cihazının ekran bilgilerini görüntüle ve desteklenen yapılandırmaları dene.", 13f, muted).apply { setPadding(0, dp(7), 0, dp(12)) })
        status = text("● Shizuku durumu kontrol ediliyor…", 13f, mint, true)
        hero.addView(status)
        hero.addView(button("Shizuku iznini kontrol et / iste") { requestShizuku() })
        content.addView(hero, marginBottom())

        val infoCard = card()
        infoCard.addView(text("CİHAZ BİLGİLERİ", 12f, mint, true))
        deviceInfo = text("Bilgiler yükleniyor…", 14f, white)
        deviceInfo.setPadding(0, dp(12), 0, dp(4))
        infoCard.addView(deviceInfo)
        infoCard.addView(button("Bilgileri yenile") { refreshInfo() })
        content.addView(infoCard, marginBottom())

        val presetCard = card()
        presetCard.addView(text("OYUN PROFİLLERİ", 12f, mint, true))
        presetCard.addView(text("Önce orijinal ayarları kaydet. 4:3 profili her oyunda iPad kamera açısı garantilemez.", 13f, muted).apply { setPadding(0, dp(8), 0, dp(10)) })
        presetCard.addView(button("PUBG MOBILE · 4:3 dene") { applyFourThree() })
        presetCard.addView(button("CALL OF DUTY MOBILE · 4:3 dene") { applyFourThree() })
        presetCard.addView(button("Orijinal ekran ayarlarına dön") { resetDisplay() })
        content.addView(presetCard, marginBottom())

        content.addView(text("GÜVENLİK NOTU", 12f, mint, true).apply { setPadding(0, dp(8), 0, dp(6)) })
        content.addView(text("Ekran boyutu ve DPI değişikliği oyunların görüş alanını değiştirmeyi garanti etmez. Değişiklik yapmadan önce Shizuku iznini ver. Ekran kullanılamaz hâle gelirse Shizuku/ADB üzerinden wm size reset ve wm density reset komutları kurtarma için kullanılabilir.", 12f, muted))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(14))
        setBackgroundColor(panel)
        background = android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius = dp(18).toFloat() }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(bg); setBackgroundTintList(android.content.res.ColorStateList.valueOf(mint));
        setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
    }

    private fun marginBottom() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun requestShizuku() {
        try {
            if (Shizuku.isPreV11()) {
                status.text = "Bu Shizuku sürümü desteklenmiyor"
                return
            }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                status.text = "● Shizuku izni verildi"
                status.setTextColor(mint)
                connectUserService()
                refreshInfo()
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                Shizuku.requestPermission(requestCode)
            } else {
                Shizuku.requestPermission(requestCode)
            }
        } catch (e: Exception) {
            status.text = "Shizuku hazır değil. Önce Shizuku'yu başlat."
            status.setTextColor(Color.rgb(255, 110, 110))
        }
    }

    private fun refreshInfo() {
        val dm = resources.displayMetrics
        val width = dm.widthPixels
        val height = dm.heightPixels
        val dpi = dm.densityDpi
        deviceInfo.text = "Mantıksal ekran: ${width} × ${height}\nYoğunluk: ${dpi} DPI\nOran: %.3f\nAndroid: %s".format(
            minOf(width, height).toFloat() / maxOf(width, height).toFloat(), android.os.Build.VERSION.RELEASE
        )
        try {
            val granted = Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
            status.text = if (granted) "● Shizuku bağlı ve izinli" else "● Shizuku izni gerekiyor"
            status.setTextColor(if (granted) mint else Color.rgb(255, 190, 80))
        } catch (_: Exception) { status.text = "● Shizuku çalışmıyor" }
    }

    private fun connectUserService() {
        try {
            if (!Shizuku.pingBinder()) {
                status.text = "Shizuku hizmeti çalışmıyor"
                return
            }
            Shizuku.bindUserService(userServiceArgs, shellConnection)
        } catch (e: Exception) {
            status.text = "Shizuku servisine bağlanılamadı: ${e.message}"
        }
    }

    private fun applySize(width: Int, height: Int, onDone: (String, Boolean) -> Unit) {
        worker.execute {
            try {
                if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread { onDone("Önce Shizuku izni ver.", false) }; return@execute
                }
                val shell = remoteShell
                if (shell == null) {
                    runOnUiThread { onDone("Shizuku servisi hazır değil. İzin düğmesine tekrar bas.", false) }; return@execute
                }
                val result = shell.applySize(width, height)
                runOnUiThread { onDone(result, true) }
            } catch (e: Exception) {
                runOnUiThread { onDone("İşlem başarısız: ${e.message ?: "bilinmeyen hata"}", false) }
            }
        }
    }

    private fun resetDisplayCommand(onDone: (String, Boolean) -> Unit) {
        worker.execute {
            try {
                if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread { onDone("Önce Shizuku izni ver.", false) }; return@execute
                }
                val shell = remoteShell
                if (shell == null) {
                    runOnUiThread { onDone("Shizuku servisi hazır değil. İzin düğmesine tekrar bas.", false) }; return@execute
                }
                val result = shell.resetDisplay()
                runOnUiThread { onDone(result, true) }
            } catch (e: Exception) {
                runOnUiThread { onDone("İşlem başarısız: ${e.message ?: "bilinmeyen hata"}", false) }
            }
        }
    }

    private fun applyFourThree() {
        val dm = resources.displayMetrics
        val longSide = maxOf(dm.widthPixels, dm.heightPixels)
        val shortSide = minOf(dm.widthPixels, dm.heightPixels)
        val targetWidth = (shortSide * 4f / 3f).toInt().coerceAtMost(longSide)
        val targetHeight = shortSide
        android.app.AlertDialog.Builder(this)
            .setTitle("4:3 ekran profilini uygula?")
            .setMessage("Denenecek sanal boyut: ${targetWidth}×${targetHeight}. Sonuç oyuna ve cihaza bağlıdır. Önce orijinal ayarlarını not et.")
            .setNegativeButton("İptal", null)
            .setPositiveButton("Uygula") { _, _ ->
                applySize(targetWidth, targetHeight) { output, ok ->
                    Toast.makeText(this, if (ok) "Komut çalıştı. Ekranı kontrol et." else output, Toast.LENGTH_LONG).show()
                    refreshInfo()
                }
            }.show()
    }

    private fun resetDisplay() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Ekran ayarlarını sıfırla?")
            .setMessage("Android'in çözünürlük ve DPI üzerine yazılmış ayarları sıfırlanacak.")
            .setNegativeButton("İptal", null)
            .setPositiveButton("Sıfırla") { _, _ ->
                resetDisplayCommand { output, ok ->
                    Toast.makeText(this, if (ok) "Ekran ayarları sıfırlama komutu çalıştı." else output, Toast.LENGTH_LONG).show()
                    refreshInfo()
                }
            }.show()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        try { Shizuku.unbindUserService(userServiceArgs, shellConnection, true) } catch (_: Exception) {}
        worker.shutdownNow()
        super.onDestroy()
    }
}
