package com.azpadview.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Small, opt-in overlay. It shows device status only; it does not claim to measure game FPS. */
class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var overlay: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            updateOverlay()
            handler.postDelayed(this, 10_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        createNotificationChannel()
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("AZ PadView açık")
                .setContentText("Hafif cihaz durumu paneli çalışıyor")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("AZ PadView açık")
                .setContentText("Hafif cihaz durumu paneli çalışıyor")
                .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        }
        startForeground(41, notification)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
        handler.postDelayed(refreshTask, 1_000L)
    }

    @Suppress("DEPRECATION")
    private fun showOverlay() {
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(8))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.argb(238, 7, 17, 32))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.rgb(52, 133, 220))
            }
        }
        val info = TextView(this).apply {
            tag = "info"
            text = "AZ PADVIEW  •  hazırlanıyor"
            textSize = 11f
            setTextColor(Color.rgb(215, 235, 255))
            setPadding(0, 0, dp(8), 0)
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 22f
            setTextColor(Color.rgb(100, 190, 255))
            setPadding(dp(8), 0, dp(4), 0)
            setOnClickListener { stopSelf() }
        }
        line.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(close)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(8); y = dp(110) }
        try {
            windowManager.addView(line, params)
            overlay = line
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun updateOverlay() {
        val info = overlay?.findViewWithTag<TextView>("info") ?: return
        try {
            val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
            val memory = android.app.ActivityManager.MemoryInfo()
            am.getMemoryInfo(memory)
            val used = (memory.totalMem - memory.availMem) / (1024L * 1024L)
            val total = memory.totalMem / (1024L * 1024L)
            val batteryManager = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
            val battery = batteryManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val temp = if (Build.VERSION.SDK_INT >= 29) {
                val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
                when (pm.currentThermalStatus) {
                    android.os.PowerManager.THERMAL_STATUS_NONE -> "Normal"
                    android.os.PowerManager.THERMAL_STATUS_LIGHT -> "Ilık"
                    android.os.PowerManager.THERMAL_STATUS_MODERATE -> "Sıcak"
                    android.os.PowerManager.THERMAL_STATUS_SEVERE,
                    android.os.PowerManager.THERMAL_STATUS_CRITICAL,
                    android.os.PowerManager.THERMAL_STATUS_EMERGENCY,
                    android.os.PowerManager.THERMAL_STATUS_SHUTDOWN -> "Çok sıcak"
                    else -> "?"
                }
            } else "?"
            val batteryText = if (battery in 0..100) "$battery%" else "?"
            info.text = "AZ  •  RAM $used/$total MB  •  Pil $batteryText  •  $temp"
        } catch (_: Exception) {
            info.text = "AZ PADVIEW  •  durum okunamadı"
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "AZ PadView paneli", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(refreshTask)
        try { overlay?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        overlay = null
        running = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "azpadview_overlay"
        @Volatile var running: Boolean = false
            private set
    }
}
