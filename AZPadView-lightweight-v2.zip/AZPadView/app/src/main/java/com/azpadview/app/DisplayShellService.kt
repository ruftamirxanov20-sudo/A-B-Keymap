package com.azpadview.app

import android.os.RemoteException
import java.io.BufferedReader
import java.io.InputStreamReader

/** Runs only the display commands exposed by the AIDL interface. */
class DisplayShellService : IDisplayShell.Stub() {
    override fun applySize(width: Int, height: Int): String {
        if (width !in 320..10000 || height !in 320..10000) {
            throw RemoteException("Geçersiz ekran boyutu.")
        }
        return execute(arrayOf("wm", "size", "${width}x${height}"))
    }

    override fun resetDisplay(): String {
        val size = execute(arrayOf("wm", "size", "reset"))
        val density = execute(arrayOf("wm", "density", "reset"))
        return "$size\n$density"
    }

    private fun execute(args: Array<String>): String {
        return try {
            val process = Runtime.getRuntime().exec(args)
            val out = BufferedReader(InputStreamReader(process.inputStream)).readText()
            val err = BufferedReader(InputStreamReader(process.errorStream)).readText()
            val code = process.waitFor()
            val result = listOf(out.trim(), err.trim(), "exit=$code").filter { it.isNotEmpty() }.joinToString("\n")
            if (code != 0) throw RemoteException(result)
            result
        } catch (e: Exception) {
            throw RemoteException(e.message ?: "Komut çalıştırılamadı.")
        }
    }

    @Suppress("unused")
    override fun destroy() { System.exit(0) }
}
