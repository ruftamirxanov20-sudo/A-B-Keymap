package com.azpadview.app;

interface IDisplayShell {
    String applySize(int width, int height);
    String resetDisplay();
    void destroy() = 16777114;
}
