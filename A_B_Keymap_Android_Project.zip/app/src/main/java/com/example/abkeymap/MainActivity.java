package com.example.abkeymap;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private int size = 64;
    private int interval = 120;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 24);
        root.setBackgroundColor(Color.rgb(15, 23, 42));

        TextView title = new TextView(this);
        title.setText("A → B KEYMAP");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("Üzən düymələrin ilkin versiyası");
        info.setTextColor(Color.LTGRAY);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 10, 0, 24);
        root.addView(info);

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(15);
        status.setText("Örtük icazəsi yoxlanılır…");
        root.addView(status);

        Button permission = button("ÜZƏN DÜYMƏ İCAZƏSİ");
        permission.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else updateStatus();
        });
        root.addView(permission);

        TextView sizeLabel = label("Düymə ölçüsü: 64 px");
        root.addView(sizeLabel);
        SeekBar sizeBar = new SeekBar(this);
        sizeBar.setMax(78);
        sizeBar.setProgress(32);
        sizeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                size = 32 + p;
                sizeLabel.setText("Düymə ölçüsü: " + size + " px");
                OverlayService.updateSettings(size, interval);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        root.addView(sizeBar);

        TextView speedLabel = label("Klik intervalı: 120 ms");
        root.addView(speedLabel);
        SeekBar speedBar = new SeekBar(this);
        speedBar.setMax(470);
        speedBar.setProgress(90);
        speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                interval = 30 + p;
                speedLabel.setText("Klik intervalı: " + interval + " ms");
                OverlayService.updateSettings(size, interval);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        root.addView(speedBar);

        Button start = button("ÜZƏN A / B DÜYMƏLƏRİNİ GÖSTƏR");
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                status.setText("Əvvəlcə üzən düymə icazəsini ver.");
                return;
            }
            OverlayService.updateSettings(size, interval);
            startService(new Intent(this, OverlayService.class));
            status.setText("A/B paneli başladıldı. Mövqeləri paneldəki Kilid düyməsi ilə sabitləyə bilərsən.");
        });
        root.addView(start);

        Button stop = button("PANELİ BAĞLA");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            status.setText("Panel bağlandı.");
        });
        root.addView(stop);

        TextView note = new TextView(this);
        note.setText("\nQeyd: Bu ilkin layihə üzən A/B panelini, ölçü və interval ayarlarını göstərir. B düyməsinin PUBG-yə avtomatik toxunuş göndərməsi hələ daxil edilməyib.");
        note.setTextColor(Color.rgb(203, 213, 225));
        note.setTextSize(13);
        root.addView(note);

        setContentView(root);
        updateStatus();
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 10, 0, 6);
        b.setLayoutParams(lp);
        return b;
    }
    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(Color.WHITE); t.setPadding(0, 18, 0, 4);
        return t;
    }
    private void updateStatus() {
        boolean allowed = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        status.setText(allowed ? "Üzən düymə icazəsi: verilib" : "Üzən düymə icazəsi: verilməyib");
    }
    @Override protected void onResume() { super.onResume(); if (status != null) updateStatus(); }
}
