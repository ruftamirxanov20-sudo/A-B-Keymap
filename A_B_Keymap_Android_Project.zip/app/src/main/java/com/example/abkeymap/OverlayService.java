package com.example.abkeymap;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class OverlayService extends Service {
    private static int buttonSize = 64;
    private static int clickInterval = 120;
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;
    private boolean locked = false;

    public static void updateSettings(int size, int interval) {
        buttonSize = size;
        clickInterval = interval;
    }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createPanel();
    }

    private void createPanel() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(8, 8, 8, 8);
        root.setBackgroundColor(Color.argb(190, 15, 23, 42));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        Button a = bubble("A", Color.rgb(37, 99, 235));
        Button b = bubble("B", Color.rgb(22, 163, 74));
        row.addView(a);
        row.addView(b);
        root.addView(row);

        LinearLayout controls = new LinearLayout(this);
        Button lock = new Button(this);
        lock.setText("KİLİDLƏ");
        lock.setTextSize(10);
        lock.setOnClickListener(v -> {
            locked = !locked;
            lock.setText(locked ? "DÜZƏLT" : "KİLİDLƏ");
            Toast.makeText(this, locked ? "Mövqe kilidləndi" : "Mövqe redaktə edilə bilər", Toast.LENGTH_SHORT).show();
        });
        Button close = new Button(this);
        close.setText("X");
        close.setTextSize(10);
        close.setOnClickListener(v -> stopSelf());
        controls.addView(lock, new LinearLayout.LayoutParams(0, -2, 1));
        controls.addView(close, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(controls);

        a.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                Toast.makeText(this, "A basıldı — B auto-click bu ilkin versiyada aktiv deyil", Toast.LENGTH_SHORT).show();
                return true;
            }
            return e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL;
        });
        b.setOnClickListener(v -> Toast.makeText(this, "B düyməsi seçildi", Toast.LENGTH_SHORT).show());

        panel = root;
        int type = Build.VERSION.SDK_INT >= 26
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 30; params.y = 180;

        root.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY; float touchX, touchY;
            public boolean onTouch(View v, MotionEvent e) {
                if (locked) return false;
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = params.x; startY = params.y;
                    touchX = e.getRawX(); touchY = e.getRawY(); return true;
                } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = startX + (int)(e.getRawX() - touchX);
                    params.y = startY + (int)(e.getRawY() - touchY);
                    try { wm.updateViewLayout(panel, params); } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }
        });
        try { wm.addView(panel, params); } catch (Exception ex) {
            Toast.makeText(this, "Panel göstərilə bilmədi. İcazəni yoxla.", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private Button bubble(String text, int color) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(18);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        int px = (int)(buttonSize * getResources().getDisplayMetrics().density);
        b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding(0, 0, 0, 0);
        b.setWidth(px); b.setHeight(px);
        return b;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (panel != null && panel.getParent() == null) createPanel();
        return START_NOT_STICKY;
    }
    @Override public void onDestroy() {
        if (wm != null && panel != null) try { wm.removeView(panel); } catch (Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
