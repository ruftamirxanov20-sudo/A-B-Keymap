# A → B Keymap (ilkin Android layihəsi)

Bu ZIP Android Studio ilə açılan **mənbə layihəsidir**, hazır APK deyil.

## Hazır olan ilkin hissələr
- Android overlay icazəsini yoxlamaq və parametrləri açmaq
- Ekranda A və B üzən düymələrini göstərmək
- Paneli sürüşdürmək
- Panel mövqeyini kilidləmək / redaktəyə qaytarmaq
- Düymə ölçüsü və klik intervalı üçün ayar interfeysi

## Hələ daxil edilməyib
- A basılı saxlananda B-nin başqa tətbiqə/PUBG-yə avtomatik toxunuş göndərməsi
- Ölçü dəyişdikdə artıq açıq üzən düymələrin dərhal yenilənməsi
- Mövqelərin və profillərin yadda saxlanması
- Real cihazda sınaq və buraxılış imzalı APK

## Necə açmaq
1. ZIP-i kompüterə çıxart.
2. Android Studio-da `A_B_Keymap_Android_Project` qovluğunu aç.
3. Gradle sync et və `app` konfiqurasiyasını işə sal.
4. Telefonunda sınaq üçün USB debugging və ya Android Studio-nun uyğun quraşdırma üsulundan istifadə et.

Bu mühitdə Android SDK/Gradle quraşdırılmadığı üçün APK-ni burada kompilyasiya etmək mümkün olmadı. Kod ilkin skeletdir və real cihazda test edilməlidir.
