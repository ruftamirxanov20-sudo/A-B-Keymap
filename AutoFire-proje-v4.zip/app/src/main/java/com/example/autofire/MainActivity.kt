package com.example.autofire

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {
    private val cBg = Color.parseColor("#0F1115")
    private val cCard = Color.parseColor("#1A1D24")
    private val cAccent = Color.parseColor("#FF5A36")
    private val cSub = Color.parseColor("#9AA3B2")
    private val cOk = Color.parseColor("#43D17A")
    private val cBad = Color.parseColor("#FF5A5A")
    private val cWarn = Color.parseColor("#FFC04D")

    private lateinit var tvAcc: TextView
    private lateinit var tvOv: TextView
    private lateinit var tvEng: TextView
    private lateinit var btnStart: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, r: Int = 16) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(color) }
    private fun prefs() = getSharedPreferences("cfg", MODE_PRIVATE)
    private fun engine() = prefs().getString("engine", "acc") ?: "acc"
    private fun isRoot() = engine() != "acc"
    private fun shizukuRunning() = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    private fun shizukuGranted() = try { shizukuRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun card(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = rounded(cCard)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) }
        addView(tv(title, 15f, Color.WHITE, true))
    }

    private fun button(text: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE); isAllCaps = false; textSize = 15f
        background = rounded(color, 12)
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(50)).apply { topMargin = dp(10) }
        setOnClickListener { onClick() }
    }

    private fun notifyService() {
        if (OverlayService.running)
            startService(Intent(this, OverlayService::class.java).setAction("UPDATE"))
    }

    private fun slider(parent: LinearLayout, label: String, unit: String, hint: String,
                       key: String, min: Int, max: Int, def: Int) {
        val v = prefs().getInt(key, def).coerceIn(min, max)
        val t = tv("$label: $v $unit", 14f, Color.WHITE).apply { setPadding(0, dp(14), 0, 0) }
        val s = SeekBar(this).apply {
            this.max = max - min; progress = v - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, pr: Int, u: Boolean) {
                    t.text = "$label: ${pr + min} $unit"
                    prefs().edit().putInt(key, pr + min).apply()
                    notifyService()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        parent.addView(t); parent.addView(s)
        parent.addView(tv(hint, 11f, cSub))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(36), dp(16), dp(24))
        }
        root.addView(tv("AutoFire", 28f, Color.WHITE, true))
        root.addView(tv("Tək atəşli silahlar üçün avtomatik klik", 13f, cSub))

        // 1 · Mühərrik
        val eng = card("1 · Klik göndərmə üsulu")
        val rg = RadioGroup(this)
        val r1 = RadioButton(this).apply { text = "Əlçatanlıq (root lazım deyil)"; setTextColor(Color.WHITE); id = 1001 }
        val r2 = RadioButton(this).apply { text = "Root (aim DONMUR)"; setTextColor(Color.WHITE); id = 1002 }
        val r3 = RadioButton(this).apply { text = "Shizuku (root-suz, aim donmamalıdır)"; setTextColor(Color.WHITE); id = 1003 }
        rg.addView(r1); rg.addView(r2); rg.addView(r3)
        rg.check(when (engine()) { "root" -> 1002; "shizuku" -> 1003; else -> 1001 })
        rg.setOnCheckedChangeListener { _, id ->
            prefs().edit().putString("engine", when (id) { 1002 -> "root"; 1003 -> "shizuku"; else -> "acc" }).apply()
            if (OverlayService.running) Toast.makeText(this, "Dayandırıb yenidən başlat", Toast.LENGTH_SHORT).show()
            refresh()
        }
        eng.addView(rg)
        eng.addView(tv("Əlçatanlıq üsulunda Android özü real toxunuşları ləğv edir: A-ya basanda aim/hərəkət/dürbün " +
            "donur. Bu, Android-in məhdudiyyətidir, tətbiq bunu aradan qaldıra bilməz. Root üsulu isə klikləri " +
            "ekranın öz toxunma kanalına əlavə barmaq kimi yazır, buna görə heç nə donmur. " +
            "Root və ya Shizuku seçəndə Əlçatanlıq xidmətini SÖNDÜR (gecikmə yaradır). " +
            "Shizuku: əvvəl Shizuku tətbiqini qur və başlat, sonra aşağıdakı düymə ilə icazə ver.", 11f, cSub))
        eng.addView(button("Shizuku icazəsi ver", Color.parseColor("#2C3140")) {
            when {
                !shizukuRunning() -> {
                    Toast.makeText(this, "Shizuku işləmir. Shizuku-nu aç və başlat.", Toast.LENGTH_LONG).show()
                    packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
                }
                shizukuGranted() -> Toast.makeText(this, "İcazə artıq verilib ✔", Toast.LENGTH_SHORT).show()
                else -> Shizuku.requestPermission(100)
            }
        })
        eng.addView(button("Root / Shizuku testi", Color.parseColor("#2C3140")) {
            RootInput.useShizuku = engine() == "shizuku"
            Toast.makeText(this, "Yoxlanılır… root icazəsi istənə bilər", Toast.LENGTH_SHORT).show()
            Thread {
                val err = RootInput.detect()
                val i = RootInput.info
                runOnUiThread {
                    AlertDialog.Builder(this).setTitle(if (err == null) "İşləyir ✔" else "Xəta")
                        .setMessage(if (err == null && i != null)
                            "Toxunma cihazı: ${i.node}\nPanel ölçüsü: ${i.maxX + 1} x ${i.maxY + 1}\nSlot sayı: ${i.maxSlot + 1}"
                        else err).setPositiveButton("OK", null).show()
                }
            }.start()
        })
        root.addView(eng)

        // 2 · İcazələr
        val st = card("2 · İcazələr")
        tvAcc = tv("", 14f, Color.WHITE).apply { setPadding(0, dp(10), 0, 0) }
        tvOv = tv("", 14f, Color.WHITE).apply { setPadding(0, dp(4), 0, 0) }
        tvEng = tv("", 12f, cWarn).apply { setPadding(0, dp(6), 0, 0) }
        st.addView(tvAcc); st.addView(tvOv); st.addView(tvEng)
        st.addView(button("Əlçatanlıq ayarlarını aç", Color.parseColor("#2C3140")) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        st.addView(button("Üstdə göstərmə icazəsini aç", Color.parseColor("#2C3140")) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(st)

        // 3 · Başlat
        val go = card("3 · Başlat")
        btnStart = button("BAŞLAT", cAccent) { toggleService() }
        go.addView(btnStart)
        root.addView(go)

        // 4 · Ayarlar
        val set = card("4 · Ayarlar (dərhal tətbiq olunur)")
        slider(set, "A düyməsinin ölçüsü", "dp", "Qırmızı düymə", "sizeA", 30, 140, 60)
        slider(set, "B düyməsinin ölçüsü", "dp", "Mavi düymə (atəş düyməsinin üstündə)", "sizeB", 20, 140, 60)
        slider(set, "Şəffaflıq", "%", "Aşağı dəyər = daha şəffaf", "alpha", 20, 100, 80)
        slider(set, "Klik intervalı", "ms", "İki klik arası. Kiçik = sürətli atəş. Klik tanınmırsa artır.", "interval", 40, 400, 100)
        slider(set, "Klik müddəti", "ms", "Hər klikin barmaqda qalma müddəti (qısa = daha az müdaxilə)", "duration", 1, 80, 10)
        val sw = SwitchCompat(this).apply {
            text = "Aç/Bağla rejimi (A-ya bir dəfə bas)"; setTextColor(Color.WHITE)
            isChecked = prefs().getBoolean("toggle", false)
            setPadding(0, dp(16), 0, 0)
            setOnCheckedChangeListener { _, c -> prefs().edit().putBoolean("toggle", c).apply() }
        }
        set.addView(sw)
        set.addView(tv("Basılı saxlamaq əvəzinə A-ya bir dəfə basanda atəş başlayır, yenə basanda dayanır.", 11f, cSub))
        root.addView(set)

        // İstifadə
        val how = card("Necə istifadə olunur?")
        how.addView(tv("1. Üsulu seç (Root varsa Root).\n" +
            "2. BAŞLAT-a bas, sonra PUBG-ni aç.\n" +
            "3. 🔓 açıq ikən B-ni (mavi) atəş düyməsinin tam üstünə sürüklə. A-nı (qırmızı) rahat basacağın yerə qoy.\n" +
            "4. 🔒-ə bas: düymələr kilidlənir, B toxunuşa bağlanır.\n" +
            "5. A-ya basılı saxla: B-nin altındakı atəş düyməsinə ard-arda klik gedir. " +
            "Düzəliş üçün yenə 🔓-ə bas.", 13f, cSub).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.15f) })
        root.addView(how)

        setContentView(ScrollView(this).apply { setBackgroundColor(cBg); addView(root) })
    }

    private fun toggleService() {
        when {
            OverlayService.running -> stopService(Intent(this, OverlayService::class.java))
            engine() == "shizuku" && !shizukuGranted() ->
                Toast.makeText(this, "Əvvəl Shizuku-nu başlat və icazə ver", Toast.LENGTH_LONG).show()
            engine() == "acc" && TapService.instance == null ->
                Toast.makeText(this, "Əvvəl Əlçatanlıq xidmətini aç (\"AutoFire Tap\")", Toast.LENGTH_LONG).show()
            !Settings.canDrawOverlays(this) ->
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else -> startForegroundService(Intent(this, OverlayService::class.java))
        }
        btnStart.postDelayed({ refresh() }, 500)
    }

    private fun refresh() {
        val acc = TapService.instance != null
        val ov = Settings.canDrawOverlays(this)
        val root = isRoot()
        tvAcc.text = if (acc) "● Əlçatanlıq: Açıq" else "● Əlçatanlıq: Bağlı"
        tvAcc.setTextColor(if (root) (if (acc) cWarn else cOk) else (if (acc) cOk else cBad))
        tvOv.text = if (ov) "● Üstdə göstərmə: Açıq" else "● Üstdə göstərmə: Bağlı"
        tvOv.setTextColor(if (ov) cOk else cBad)
        tvEng.text = when {
            engine() == "shizuku" -> (if (acc) "Əlçatanlıq xidmətini söndür, yoxsa gecikmə olacaq.\n" else "") +
                (if (shizukuGranted()) "● Shizuku: hazırdır" else if (shizukuRunning()) "● Shizuku: işləyir, icazə lazımdır" else "● Shizuku: işləmir")
            root -> if (acc) "Root rejimi: Əlçatanlıq xidmətini söndür, yoxsa gecikmə olacaq." else "Root rejimi: Əlçatanlıq lazım deyil."
            else -> "Əlçatanlıq rejimi: xidmət açıq olmalıdır."
        }
        btnStart.text = if (OverlayService.running) "DAYANDIR" else "BAŞLAT"
        btnStart.background = rounded(if (OverlayService.running) Color.parseColor("#C62828") else cAccent, 12)
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onStart() { super.onStart(); runCatching { Shizuku.addRequestPermissionResultListener(shizukuListener) } }
    override fun onStop() { super.onStop(); runCatching { Shizuku.removeRequestPermissionResultListener(shizukuListener) } }
}
