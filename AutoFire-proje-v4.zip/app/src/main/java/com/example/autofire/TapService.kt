package com.example.autofire

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class TapService : AccessibilityService() {
    companion object { @Volatile var instance: TapService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Tek bir tıklama gönderir; bitince (ya da iptal olunca) onDone çağrılır. Böylece tıklamalar üst üste binmez. */
    fun tap(x: Float, y: Float, durationMs: Long, onDone: () -> Unit) {
        val p = Path().apply { moveTo(x, y); lineTo(x + 0.1f, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, durationMs.coerceAtLeast(1)))
            .build()
        val cb = object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { onDone() }
            override fun onCancelled(d: GestureDescription?) { onDone() }
        }
        if (!dispatchGesture(g, cb, null)) onDone()
    }
}
