package com.example.autofire

import android.os.Handler
import android.os.Looper
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors

/**
 * Root rejimi: toxunma ekranının öz cihaz faylına (/dev/input/eventN) boş bir "slot"da əlavə barmaq yazır.
 * Sistem bunu real barmaq kimi görür -> aim, hərəkət və dürbün DONMUR.
 */
object RootInput {
    class Info(val node: String, val maxX: Int, val maxY: Int, val maxSlot: Int)

    @Volatile var info: Info? = null
    @Volatile var ready = false
    @Volatile var useShizuku = false
    private var proc: Process? = null
    private var out: OutputStream? = null
    private var tid = 20000
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private fun spawn(cmd: String): Process {
        if (useShizuku) {
            val m = Class.forName("rikka.shizuku.Shizuku").getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
            m.isAccessible = true
            return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        }
        return ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
    }

    private fun run(cmd: String): String? = try {
        val p = spawn(cmd)
        val s = p.inputStream.bufferedReader().readText(); p.waitFor(); s
    } catch (e: Throwable) { null }

    private fun maxOf(b: List<String>, hex: String, name: String): Int? {
        val re = Regex("(^|\\s)$hex(\\s|:)")
        val l = b.firstOrNull { it.contains("max") && (it.contains(name) || re.containsMatchIn(it)) } ?: return null
        return Regex("max\\s+(-?\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull()
    }

    /** null = uğurlu, əks halda xəta mətni */
    fun detect(): String? {
        if (useShizuku) {
            val ok = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
            if (!ok) return "Shizuku işləmir. Shizuku tətbiqini aç və başlat."
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED)
                return "Shizuku icazəsi verilməyib. \"Shizuku icazəsi ver\" düyməsinə bas."
        } else {
            val id = run("id") ?: return "su tapılmadı (telefon rootlu deyil)"
            if (!id.contains("uid=0")) return "Root icazəsi verilmədi (Magisk/KernelSU-da icazə ver)"
        }
        val txt = run("getevent -p") ?: return "getevent işləmədi"
        val blocks = mutableListOf<Pair<String, MutableList<String>>>()
        for (line in txt.lines()) {
            if (line.startsWith("add device")) blocks.add(line.substringAfter(": ").trim() to mutableListOf())
            else blocks.lastOrNull()?.second?.add(line)
        }
        for ((node, b) in blocks) {
            val x = maxOf(b, "0035", "ABS_MT_POSITION_X") ?: continue
            val y = maxOf(b, "0036", "ABS_MT_POSITION_Y") ?: continue
            val slot = maxOf(b, "002f", "ABS_MT_SLOT") ?: continue
            if (x < 100 || y < 100) continue
            val w = run(": > $node && echo WOK || echo WNO 2>&1") ?: ""
            if (!w.contains("WOK")) return "Bu üsulla toxunma faylına ($node) yazmaq olmur. " +
                "Telefon (SELinux) shell-ə icazə vermir. Bu halda yalnız root işləyir."
            info = Info(node, x, y, slot)
            return null
        }
        return "Toxunma ekranı cihazı tapılmadı"
    }

    fun open(): String? {
        if (ready) return null
        if (info == null) detect()?.let { return it }
        return try {
            val p = spawn("cat > ${info!!.node}")
            proc = p; out = p.outputStream; ready = true; null
        } catch (e: Throwable) { "Proses açılmadı: ${e.message}" }
    }

    fun close() {
        ready = false
        runCatching { out?.close() }; runCatching { proc?.destroy() }
        out = null; proc = null
    }

    private fun ev(b: ByteBuffer, t: Int, c: Int, v: Int) {
        b.putLong(0); b.putLong(0); b.putShort(t.toShort()); b.putShort(c.toShort()); b.putInt(v)
    }

    private fun send(f: (ByteBuffer) -> Unit) {
        val b = ByteBuffer.allocate(24 * 16).order(ByteOrder.LITTLE_ENDIAN)
        f(b)
        out?.let { it.write(b.array(), 0, b.position()); it.flush() }
    }

    /** Ekran koordinatını (x,y) panel koordinatına çevirib bir toxunuş göndərir. done əsas thread-də çağrılır. */
    fun tapScreen(x: Float, y: Float, sw: Int, sh: Int, rotation: Int, durMs: Long, done: () -> Unit) {
        val i = info
        if (i == null || !ready) { main.post(done); return }
        val nx = (x / sw).coerceIn(0f, 1f); val ny = (y / sh).coerceIn(0f, 1f)
        val (px, py) = when (rotation) {
            1 -> (1f - ny) to nx          // ROTATION_90
            2 -> (1f - nx) to (1f - ny)   // ROTATION_180
            3 -> ny to (1f - nx)          // ROTATION_270
            else -> nx to ny
        }
        val rx = (px * i.maxX).toInt(); val ry = (py * i.maxY).toInt()
        val slot = i.maxSlot
        exec.execute {
            try {
                tid = if (tid > 60000) 20000 else tid + 1
                send { b -> ev(b, 3, 0x2f, slot); ev(b, 3, 0x39, tid); ev(b, 3, 0x35, rx); ev(b, 3, 0x36, ry); ev(b, 0, 0, 0) }
                Thread.sleep(durMs.coerceAtLeast(1))
                send { b -> ev(b, 3, 0x2f, slot); ev(b, 3, 0x39, -1); ev(b, 0, 0, 0) }
            } catch (e: Exception) { ready = false }
            main.post(done)
        }
    }
}
