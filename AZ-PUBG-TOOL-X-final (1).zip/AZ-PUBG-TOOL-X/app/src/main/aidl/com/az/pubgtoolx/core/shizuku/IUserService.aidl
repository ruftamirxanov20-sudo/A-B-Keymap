package com.az.pubgtoolx.core.shizuku;

// Shizuku UserService arayüzü: shell yetkisiyle ayrı bir süreçte çalışır.
interface IUserService {
    // Shizuku tarafından tanımlanmış yok etme metodu (sabit kod).
    void destroy() = 16777114;

    // "sh -c" ile komut çalıştırır. Dönüş: ilk satır çıkış kodu, kalanı çıktı.
    String exec(String command) = 1;

    // Dosyayı okur. Hata veya boyut aşımında null döner.
    byte[] readFile(String path, int maxBytes) = 2;

    // Dosyaya yazar (üzerine). Dönüş: "OK" veya hata mesajı.
    String writeFile(String path, in byte[] data) = 3;
}
