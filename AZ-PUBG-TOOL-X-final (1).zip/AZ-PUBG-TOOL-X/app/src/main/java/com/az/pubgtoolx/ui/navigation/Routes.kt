package com.az.pubgtoolx.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

/** Tüm rota adları tek yerde. */
object Routes {
    const val HOME = "home"
    const val TOOLS = "tools"
    const val AIM = "aim_lab"
    const val PROFILES = "profiles"
    const val SETTINGS = "settings"
    const val LOGS = "logs"

    const val MODULE_ARG = "id"
    const val MODULE_PATTERN = "module/{$MODULE_ARG}"

    const val ARG_MODE = "mode"
    const val ARG_DIFFICULTY = "difficulty"
    const val ARG_SECONDS = "seconds"
    const val AIM_PLAY_PATTERN = "aim_play/{$ARG_MODE}/{$ARG_DIFFICULTY}/{$ARG_SECONDS}"

    fun module(id: String) = "module/$id"

    fun aimPlay(mode: String, difficulty: String, seconds: Int) = "aim_play/$mode/$difficulty/$seconds"
}

/** Alt gezinme çubuğu: Home / Tools / Aim Lab / Profiles / Settings. */
enum class BottomTab(val route: String, val label: String, val icon: ImageVector) {
    HOME(Routes.HOME, "Home", Icons.Filled.Home),
    TOOLS(Routes.TOOLS, "Tools", Icons.Filled.Build),
    AIM(Routes.AIM, "Aim Lab", Icons.Filled.GpsFixed),
    PROFILES(Routes.PROFILES, "Profiles", Icons.Filled.Person),
    SETTINGS(Routes.SETTINGS, "Settings", Icons.Filled.Settings),
}
