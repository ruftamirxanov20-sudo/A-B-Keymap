package com.az.pubgtoolx.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.az.pubgtoolx.ui.theme.CyberBackground
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSecondary

/**
 * Statik neon ışıma arka planı. Animasyon yok; yalnızca iki gradyan çizilir,
 * bu yüzden düşük donanımda da maliyeti ihmal edilebilir.
 */
@Composable
fun ScreenBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(CyberPrimary.copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(size.width * 0.85f, 0f),
                        radius = size.width * 0.9f,
                    ),
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(CyberSecondary.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(0f, size.height),
                        radius = size.width,
                    ),
                )
            },
        content = content,
    )
}
