package com.az.pubgtoolx.ui.screens.activesav

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ln

/** Dosyanın içeriği yorumlanmaz veya değiştirilmez; yalnızca ham baytlar okunur, hash'lenir, yedeklenir. */
internal data class SavAnalysis(
    val size: Int,
    val sha256: String,
    val headerHex: String,
    val looksLikeGvas: Boolean,
    val entropy: Double,
    val printablePercent: Int,
)

internal data class ChangeReport(
    val sizeA: Int,
    val sizeB: Int,
    val identical: Boolean,
    val differingBytes: Int,
    val firstDifference: Int?,
    val comparedBytes: Int,
)

internal data class BackupItem(val file: File, val tag: String, val size: Long, val modified: Long)

internal data class LoadedFile(val bytes: ByteArray, val name: String, val modified: Long?)

internal object ActiveSavLogic {

    const val SAF_MAX_BYTES = 8 * 1024 * 1024
    private const val DIR = "activesav_backups"

    fun sha256(bytes: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        val d = md.digest(bytes)
        val sb = StringBuilder(d.size * 2)
        for (b in d) sb.append("%02x".format(b))
        return sb.toString()
    }

    fun analyze(bytes: ByteArray): SavAnalysis {
        val counts = IntArray(256)
        var printable = 0
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            counts[v]++
            if (v in 32..126 || v == 9 || v == 10 || v == 13) printable++
        }
        var entropy = 0.0
        if (bytes.isNotEmpty()) {
            for (c in counts) {
                if (c == 0) continue
                val p = c.toDouble() / bytes.size
                entropy -= p * (ln(p) / ln(2.0))
            }
        }
        val head = bytes.copyOfRange(0, minOf(16, bytes.size))
        val headerHex = head.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
        val gvas = bytes.size >= 4 && bytes[0] == 'G'.code.toByte() && bytes[1] == 'V'.code.toByte() &&
            bytes[2] == 'A'.code.toByte() && bytes[3] == 'S'.code.toByte()
        return SavAnalysis(
            size = bytes.size,
            sha256 = sha256(bytes),
            headerHex = headerHex,
            looksLikeGvas = gvas,
            entropy = entropy,
            printablePercent = if (bytes.isEmpty()) 0 else printable * 100 / bytes.size,
        )
    }

    fun hexDump(bytes: ByteArray, maxBytes: Int = 256): String {
        val n = minOf(bytes.size, maxBytes)
        val sb = StringBuilder()
        var i = 0
        while (i < n) {
            sb.append("%04X: ".format(i))
            val end = minOf(i + 16, n)
            for (j in i until i + 16) {
                if (j < end) sb.append("%02X ".format(bytes[j].toInt() and 0xFF)) else sb.append("   ")
            }
            sb.append(' ')
            for (j in i until end) {
                val v = bytes[j].toInt() and 0xFF
                sb.append(if (v in 32..126) v.toChar() else '.')
            }
            sb.append('\n')
            i += 16
        }
        return sb.toString()
    }

    fun compare(a: ByteArray, b: ByteArray): ChangeReport {
        val n = minOf(a.size, b.size)
        var diff = 0
        var first: Int? = null
        for (i in 0 until n) {
            if (a[i] != b[i]) {
                diff++
                if (first == null) first = i
            }
        }
        if (a.size != b.size && first == null) first = n
        return ChangeReport(
            sizeA = a.size,
            sizeB = b.size,
            identical = a.size == b.size && diff == 0,
            differingBytes = diff,
            firstDifference = first,
            comparedBytes = n,
        )
    }

    // ---------------- Yedekler (uygulamaya özel klasör) ----------------

    private fun dir(context: Context): File {
        val d = File(context.filesDir, DIR)
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun safeTag(raw: String): String = raw.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifEmpty { "dosya" }

    /** Yedeği yazar ve geri okuyup hash'ini doğrular. Hata varsa null + mesaj. */
    fun saveBackup(context: Context, bytes: ByteArray, tag: String): Pair<File?, String?> {
        return try {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(dir(context), "${stamp}__${safeTag(tag)}.sav")
            val tmp = File(dir(context), file.name + ".tmp")
            tmp.writeBytes(bytes)
            if (sha256(tmp.readBytes()) != sha256(bytes)) {
                tmp.delete()
                return Pair(null, "Yedek doğrulanamadı (yazılan veri farklı).")
            }
            if (!tmp.renameTo(file)) {
                tmp.delete()
                return Pair(null, "Yedek dosyası oluşturulamadı.")
            }
            Pair(file, null)
        } catch (e: Exception) {
            Pair(null, "Yedek alınamadı: ${e.message}")
        }
    }

    fun listBackups(context: Context): List<BackupItem> {
        val files = dir(context).listFiles { f -> f.isFile && f.name.endsWith(".sav") } ?: return emptyList()
        return files.map { f ->
            val tag = f.name.removeSuffix(".sav").substringAfter("__", "")
            BackupItem(f, tag, f.length(), f.lastModified())
        }.sortedByDescending { it.modified }
    }

    fun deleteBackup(item: BackupItem): Boolean = try {
        item.file.delete()
    } catch (e: Exception) {
        false
    }

    // ---------------- Dosya seçici (SAF) ----------------

    fun readSaf(context: Context, uri: Uri): Pair<LoadedFile?, String?> {
        return try {
            var name = "seçilen dosya"
            var modified: Long? = null
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    val mi = c.getColumnIndex("last_modified")
                    if (mi >= 0 && !c.isNull(mi)) modified = c.getLong(mi)
                }
            }
            val stream = context.contentResolver.openInputStream(uri)
                ?: return Pair(null, "Dosya açılamadı.")
            val out = java.io.ByteArrayOutputStream()
            var tooBig = false
            stream.use { input ->
                val buf = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > SAF_MAX_BYTES) {
                        tooBig = true
                        break
                    }
                    out.write(buf, 0, n)
                }
            }
            if (tooBig) {
                return Pair(null, "Dosya 8 MB sınırından büyük; bu araç yalnızca küçük kayıt dosyaları içindir.")
            }
            val bytes = out.toByteArray()
            Pair(LoadedFile(bytes, name, modified), null)
        } catch (e: Exception) {
            Pair(null, "Okunamadı: ${e.message}")
        }
    }

    /** Seçilen dosyanın üzerine yazar; sağlayıcı yazmaya izin vermezse hata döner. */
    fun writeSaf(context: Context, uri: Uri, bytes: ByteArray): String? {
        return try {
            val out = context.contentResolver.openOutputStream(uri, "wt")
                ?: return "Dosya yazma için açılamadı."
            out.use { it.write(bytes) }
            null
        } catch (e: Exception) {
            "Yazılamadı: ${e.message ?: "sağlayıcı yazmaya izin vermiyor olabilir"}"
        }
    }

    fun exportTo(context: Context, uri: Uri, bytes: ByteArray): String? {
        return try {
            val out = context.contentResolver.openOutputStream(uri, "wt")
                ?: return "Hedef açılamadı."
            out.use { it.write(bytes) }
            null
        } catch (e: Exception) {
            "Dışa aktarılamadı: ${e.message}"
        }
    }
}
