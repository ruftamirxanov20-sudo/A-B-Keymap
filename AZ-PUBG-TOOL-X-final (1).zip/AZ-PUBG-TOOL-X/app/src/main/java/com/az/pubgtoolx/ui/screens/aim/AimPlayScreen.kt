package com.az.pubgtoolx.ui.screens.aim

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.data.StoreKeys
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.InfoRow
import com.az.pubgtoolx.ui.theme.CyberError
import com.az.pubgtoolx.ui.theme.CyberOutline
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSecondary
import com.az.pubgtoolx.ui.theme.CyberSuccess
import com.az.pubgtoolx.ui.theme.CyberSurface
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.delay
import org.json.JSONObject
import kotlin.math.roundToInt

private const val PHASE_COUNTDOWN = 0
private const val PHASE_PLAY = 1
private const val PHASE_RESULT = 2

@Composable
fun AimPlayScreen(mode: String, difficulty: String, seconds: Int, onExit: () -> Unit) {
    val aimMode = AimMode.parse(mode)
    val aimDifficulty = AimDifficulty.parse(difficulty)
    val duration = if (seconds == 30 || seconds == 60 || seconds == 90) seconds else 60

    val context = LocalContext.current
    val view = LocalView.current
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    var runId by remember { mutableIntStateOf(0) }
    val engine = remember(runId) { AimEngine(aimMode, aimDifficulty, duration) }
    var phase by remember(runId) { mutableIntStateOf(PHASE_COUNTDOWN) }
    var countdown by remember(runId) { mutableIntStateOf(3) }
    var tick by remember(runId) { mutableIntStateOf(0) }
    var result by remember(runId) { mutableStateOf<AimResult?>(null) }

    var hudSec by remember(runId) { mutableIntStateOf(duration) }
    var hudScore by remember(runId) { mutableIntStateOf(0) }
    var hudAcc by remember(runId) { mutableIntStateOf(0) }

    val phaseState = rememberUpdatedState(phase)

    // Güvenli çıkış: sonuç kaydı yapılmadan çıkılır.
    BackHandler { onExit() }

    LaunchedEffect(runId) {
        var i = 3
        while (i >= 1) {
            countdown = i
            delay(1000L)
            i--
        }
        phase = PHASE_PLAY
    }

    LaunchedEffect(runId, phase) {
        if (phase != PHASE_PLAY) return@LaunchedEffect
        var last = 0L
        while (!engine.finished) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (last != 0L) {
                engine.update((now - last) / 1_000_000_000f)
            }
            last = now
            tick++
            val sec = engine.remainingSec.toInt() + 1
            val clamped = if (sec > duration) duration else sec
            if (clamped != hudSec) hudSec = clamped
            if (engine.score != hudScore) hudScore = engine.score
            val acc = engine.accuracyPercent.roundToInt()
            if (acc != hudAcc) hudAcc = acc
        }
        result = engine.result()
        phase = PHASE_RESULT
    }

    // Sonuç ayrı bir efektte kaydedilir (faz değişince üstteki efekt iptal olabilir).
    LaunchedEffect(result) {
        val r = result ?: return@LaunchedEffect
        try {
            val obj = JSONObject()
                .put("id", AppStore.newId())
                .put("name", aimSessionTitle(aimMode, aimDifficulty, duration))
                .put("updated", System.currentTimeMillis())
                .put("mode", aimMode.name)
                .put("difficulty", aimDifficulty.name)
                .put("seconds", duration)
                .put("hits", r.hits)
                .put("misses", r.misses)
                .put("accuracy", r.accuracy)
                .put("avgReactionMs", r.avgReactionMs)
                .put("score", r.score)
            AppStore.upsert(context, StoreKeys.AIM_HISTORY, obj, 200)
        } catch (e: Exception) {
            // Kayıt başarısız olsa bile sonuç ekranı gösterilir.
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (phase != PHASE_RESULT) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = Dimens.ScreenPadding, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text(aimMode.label + " • " + aimDifficulty.label, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        if (phase == PHASE_PLAY) "Süre ${hudSec}s   Puan $hudScore   İsabet %$hudAcc" else "Hazırlan",
                        fontSize = 12.sp,
                        color = CyberTextMuted,
                    )
                }
                CyberButton(text = "Çık", onClick = onExit, secondary = true)
            }

            val shape = RoundedCornerShape(Dimens.CardRadius)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = Dimens.ScreenPadding)
                    .padding(bottom = 12.dp)
                    .clip(shape)
                    .background(CyberSurface.copy(alpha = 0.55f))
                    .border(1.dp, CyberOutline, shape)
                    .onSizeChanged { engine.setArea(it.width.toFloat(), it.height.toFloat()) }
                    .pointerInput(engine) {
                        awaitEachGesture {
                            val down = awaitFirstDown()
                            if (phaseState.value == PHASE_PLAY) {
                                engine.onDown(down.position.x, down.position.y)
                            }
                            down.consume()
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull() ?: break
                                if (!change.pressed) break
                                if (phaseState.value == PHASE_PLAY) {
                                    engine.onMove(change.position.x, change.position.y)
                                }
                                change.consume()
                            }
                            engine.onUp()
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val frame = tick // her karede yeniden çizim için durum okunur
                    if (frame < 0) return@Canvas
                    for (t in engine.targets) {
                        val c = Offset(t.x, t.y)
                        drawCircle(CyberPrimary.copy(alpha = 0.22f), radius = t.radius, center = c)
                        drawCircle(CyberPrimary, radius = t.radius, center = c, style = Stroke(width = 3f))
                        drawCircle(CyberSecondary, radius = t.radius * 0.62f, center = c, style = Stroke(width = 2f))
                        drawCircle(Color.White, radius = t.radius * 0.16f, center = c)
                        if (t.life > 0f) {
                            val frac = (1f - t.age / t.life).coerceIn(0f, 1f)
                            val rr = t.radius * 1.18f
                            drawArc(
                                color = CyberSuccess.copy(alpha = 0.8f),
                                startAngle = -90f,
                                sweepAngle = 360f * frac,
                                useCenter = false,
                                topLeft = Offset(c.x - rr, c.y - rr),
                                size = Size(rr * 2f, rr * 2f),
                                style = Stroke(width = 2f),
                            )
                        }
                    }
                    for (m in engine.markers) {
                        val a = (1f - m.age / 0.3f).coerceIn(0f, 1f)
                        val col = if (m.hit) CyberSuccess else CyberError
                        drawCircle(col.copy(alpha = a), radius = 14f + 30f * m.age, center = Offset(m.x, m.y), style = Stroke(width = 3f))
                    }
                    if (aimMode == AimMode.TRACKING && engine.pointerDown) {
                        val col = if (engine.onTarget) CyberSuccess else CyberError
                        drawCircle(col, radius = 10f, center = Offset(engine.pointerX, engine.pointerY), style = Stroke(width = 3f))
                    }
                }
                if (phase == PHASE_COUNTDOWN) {
                    Text("$countdown", fontSize = 72.sp, fontWeight = FontWeight.ExtraBold, color = CyberPrimary)
                }
            }
        } else {
            val r = result
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(Dimens.ScreenPadding),
                verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
            ) {
                Text("Sonuç", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text(aimSessionTitle(aimMode, aimDifficulty, duration), fontSize = 13.sp, color = CyberTextMuted)
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    if (r != null) {
                        val accLabel = if (aimMode == AimMode.TRACKING) "Hedefte kalma" else "İsabet yüzdesi"
                        InfoRow(accLabel, "%" + "%.1f".format(r.accuracy))
                        InfoRow("Puan", r.score.toString())
                        if (aimMode == AimMode.TRACKING) {
                            InfoRow("Hedef üstünde", "%.1f sn".format(r.onTargetSec))
                            InfoRow("Toplam takip", "%.1f sn".format(r.trackedSec))
                        } else {
                            InfoRow("İsabet", r.hits.toString())
                            InfoRow("Iskalanan atış", r.missShots.toString())
                            InfoRow("Süresi dolan hedef", r.expired.toString())
                            InfoRow(
                                "Ort. tepki süresi",
                                if (r.avgReactionMs > 0) "${r.avgReactionMs} ms" else "—",
                            )
                        }
                    }
                }
                Text(
                    "Sonuç antrenman geçmişine kaydedildi.",
                    fontSize = 12.sp,
                    color = CyberTextMuted,
                    textAlign = TextAlign.Start,
                )
                CyberButton(text = "Tekrar", onClick = { runId += 1 }, modifier = Modifier.fillMaxWidth())
                CyberButton(text = "Menüye dön", onClick = onExit, secondary = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
