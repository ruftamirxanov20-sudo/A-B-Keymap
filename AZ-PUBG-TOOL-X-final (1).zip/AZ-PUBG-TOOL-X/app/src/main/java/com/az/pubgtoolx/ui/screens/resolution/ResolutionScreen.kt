package com.az.pubgtoolx.ui.screens.resolution

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.data.StoreKeys
import com.az.pubgtoolx.core.shizuku.ShizukuState
import com.az.pubgtoolx.core.system.DisplayControl
import com.az.pubgtoolx.core.system.DisplayState
import com.az.pubgtoolx.core.util.copyToClipboard
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.ui.components.ConfirmDialog
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberChipRow
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.InfoRow
import com.az.pubgtoolx.ui.components.SafeRevertDialog
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.components.ShizukuGate
import com.az.pubgtoolx.ui.components.rememberShizuku
import com.az.pubgtoolx.ui.theme.CyberError
import com.az.pubgtoolx.ui.theme.CyberOutline
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.max

private class ResPreset(val label: String, val w: Int, val h: Int)

private fun evenOf(v: Int): Int = if (v % 2 == 0) v else v + 1

private fun buildPresets(shortPx: Int, longPx: Int): List<ResPreset> {
    val list = ArrayList<ResPreset>()
    list.add(ResPreset("Fiziksel", shortPx, longPx))
    val ratios = listOf(
        Triple("iPad 4:3", 4, 3),
        Triple("16:10", 16, 10),
        Triple("3:2", 3, 2),
    )
    for (r in ratios) {
        val h = evenOf(shortPx * r.second / r.third)
        if (h in 320..longPx && h != longPx) {
            list.add(ResPreset(r.first, shortPx, h))
        }
    }
    return list
}

@Composable
fun ResolutionScreen(onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizuku = rememberShizuku()
    val sState by shizuku.state.collectAsStateWithLifecycle()
    val ready = sState == ShizukuState.READY
    val metrics = remember { appMetrics(context) }

    var display by remember { mutableStateOf<DisplayState?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var statusOk by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }

    var pendingRevert by rememberSaveable { mutableStateOf(false) }
    var prevHas by rememberSaveable { mutableStateOf(false) }
    var prevW by rememberSaveable { mutableIntStateOf(0) }
    var prevH by rememberSaveable { mutableIntStateOf(0) }

    var presetIdx by rememberSaveable { mutableIntStateOf(1) }
    var customW by rememberSaveable { mutableStateOf("") }
    var customH by rememberSaveable { mutableStateOf("") }
    var profileName by rememberSaveable { mutableStateOf("") }
    var confirmApply by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }

    LaunchedEffect(ready) {
        display = if (ready) DisplayControl.read(context) else null
    }

    val d = display
    val physShort = d?.physicalWidth ?: metrics.shortPx
    val physLong = d?.physicalHeight ?: metrics.longPx
    val curShort = d?.currentWidth ?: metrics.shortPx
    val curLong = d?.currentHeight ?: metrics.longPx
    val dpi = d?.currentDensity ?: metrics.densityDpi

    val presets = remember(physShort, physLong) { buildPresets(physShort, physLong) }
    val options = presets.map { it.label } + "Özel"
    val safeIdx = presetIdx.coerceIn(0, options.size - 1)
    val isCustom = safeIdx >= presets.size

    val targetW: Int
    val targetH: Int
    if (isCustom) {
        targetW = customW.toIntOrNull() ?: 0
        targetH = customH.toIntOrNull() ?: 0
    } else {
        targetW = presets[safeIdx].w
        targetH = presets[safeIdx].h
    }

    val profilesFlow = remember { AppStore.arrayFlow(context, StoreKeys.RES_PROFILES) }
    val profiles by profilesFlow.collectAsStateWithLifecycle(initialValue = emptyList())

    // Uygulama sırasında geri alma penceresi açıkken ekrandan çıkılamaz.
    BackHandler(enabled = pendingRevert) { }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "Resolution & iPad View", subtitle = "Çözünürlük ve görünüm profilleri", onBack = if (pendingRevert) null else onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Ekran bilgisi")
                Spacer(Modifier.height(6.dp))
                if (d != null) {
                    InfoRow("Fiziksel çözünürlük", "${d.physicalWidth} × ${d.physicalHeight}")
                    InfoRow(
                        "Mevcut çözünürlük",
                        "${d.currentWidth} × ${d.currentHeight}" + if (d.sizeOverridden) " (değiştirilmiş)" else "",
                    )
                    InfoRow("Fiziksel DPI", d.physicalDensity.toString())
                } else {
                    InfoRow("Çözünürlük (uygulamanın gördüğü)", "${metrics.shortPx} × ${metrics.longPx}")
                    Text(
                        "Fiziksel/değiştirilmiş ayrımı için Shizuku gerekir.",
                        fontSize = 11.sp,
                        color = CyberTextMuted,
                    )
                }
                InfoRow("En-boy oranı", aspectText(curShort, curLong))
                InfoRow("DPI", dpi.toString())
                InfoRow("dp boyutu", "${pxToDp(curShort, dpi)} × ${pxToDp(curLong, dpi)} dp")
            }

            SectionTitle("Hedef görünüm")
            CyberChipRow(options = options, selectedIndex = safeIdx, onSelect = { presetIdx = it })

            if (isCustom) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AzTextField(customW, { customW = it }, "Genişlik (px)", Modifier.weight(1f), numeric = true)
                    AzTextField(customH, { customH = it }, "Yükseklik (px)", Modifier.weight(1f), numeric = true)
                }
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                if (targetW > 0 && targetH > 0) {
                    RatioPreview(phoneW = physShort, phoneH = physLong, targetW = targetW, targetH = targetH)
                    InfoRow("Hedef çözünürlük", "$targetW × $targetH")
                    InfoRow("Hedef oran", aspectText(targetW, targetH))
                } else {
                    Text("Geçerli bir genişlik ve yükseklik girin.", fontSize = 13.sp, color = CyberTextMuted)
                }
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Uyumluluk kontrolü")
                Spacer(Modifier.height(6.dp))
                if (targetW <= 0 || targetH <= 0) {
                    CheckLine(CheckLevel.ERROR, "Değerler eksik.")
                } else {
                    if (targetW in 320..8000 && targetH in 320..8000) {
                        CheckLine(CheckLevel.OK, "Değer aralığı geçerli (320–8000).")
                    } else {
                        CheckLine(CheckLevel.ERROR, "Değerler 320–8000 aralığında olmalı.")
                    }
                    if (targetW > physShort || targetH > physLong) {
                        CheckLine(CheckLevel.WARN, "Hedef fiziksel çözünürlükten büyük; görüntü bozulabilir.")
                    } else {
                        CheckLine(CheckLevel.OK, "Hedef fiziksel çözünürlüğü aşmıyor.")
                    }
                    if (targetH * physShort != targetW * physLong) {
                        CheckLine(CheckLevel.WARN, "En-boy oranı ekrandan farklı; kenarlarda boşluk olabilir.")
                    } else {
                        CheckLine(CheckLevel.OK, "En-boy oranı ekranla aynı.")
                    }
                    if (targetW < 540) {
                        CheckLine(CheckLevel.WARN, "Çok düşük genişlik; arayüz bozulabilir.")
                    }
                }
            }

            if (status != null) {
                StatusCard(text = status ?: "", ok = statusOk)
            }

            ShizukuGate(controller = shizuku, featureText = "Çözünürlüğü değiştirmek") {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    SectionTitle("Uygula")
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Değişiklikten sonra 15 saniye içinde onaylamazsan önceki çözünürlüğe otomatik dönülür.",
                        fontSize = 12.sp,
                        color = CyberTextMuted,
                    )
                    Spacer(Modifier.height(10.dp))
                    val valid = targetW in 320..8000 && targetH in 320..8000
                    CyberButton(
                        text = "Uygula (${targetW}x$targetH)",
                        onClick = { confirmApply = true },
                        enabled = valid && !busy,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    CyberButton(
                        text = "Varsayılana dön",
                        onClick = { confirmReset = true },
                        enabled = !busy && (d?.sizeOverridden ?: true),
                        secondary = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Shizuku'suz alternatif (adb)")
                Spacer(Modifier.height(4.dp))
                Text(
                    "Bilgisayardan adb ile aynı işlemi yapabilirsin. Komutu kopyala:",
                    fontSize = 12.sp,
                    color = CyberTextMuted,
                )
                Spacer(Modifier.height(8.dp))
                CyberButton(
                    text = "Uygulama komutunu kopyala",
                    onClick = {
                        if (targetW > 0 && targetH > 0) {
                            copyToClipboard(context, "adb", "adb shell wm size ${targetW}x$targetH")
                            toast(context, "Komut kopyalandı")
                        } else {
                            toast(context, "Önce geçerli bir hedef seçin")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                CyberButton(
                    text = "Sıfırlama komutunu kopyala",
                    onClick = {
                        copyToClipboard(context, "adb", "adb shell wm size reset")
                        toast(context, "Komut kopyalandı")
                    },
                    secondary = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Çözünürlük profilleri")
                Spacer(Modifier.height(6.dp))
                AzTextField(profileName, { profileName = it }, "Profil adı", Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                CyberButton(
                    text = "Hedefi profil olarak kaydet",
                    onClick = {
                        val name = profileName.trim()
                        if (name.isEmpty()) {
                            toast(context, "Profil adı girin")
                        } else if (targetW !in 320..8000 || targetH !in 320..8000) {
                            toast(context, "Geçerli bir hedef seçin")
                        } else {
                            scope.launch {
                                val obj = JSONObject()
                                    .put("id", AppStore.newId())
                                    .put("name", name)
                                    .put("updated", System.currentTimeMillis())
                                    .put("width", targetW)
                                    .put("height", targetH)
                                AppStore.upsert(context, StoreKeys.RES_PROFILES, obj, 50)
                                profileName = ""
                                toast(context, "Profil kaydedildi")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                if (profiles.isEmpty()) {
                    Text("Kayıtlı profil yok.", fontSize = 12.sp, color = CyberTextMuted)
                }
                for (p in profiles) {
                    val pw = p.optInt("width")
                    val ph = p.optInt("height")
                    val pid = p.optString("id")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(p.optString("name"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("$pw × $ph  •  ${aspectText(pw, ph)}", fontSize = 12.sp, color = CyberTextMuted)
                        }
                        CyberButton(
                            text = "Seç",
                            onClick = {
                                customW = pw.toString()
                                customH = ph.toString()
                                presetIdx = presets.size
                            },
                        )
                        IconButton(onClick = {
                            scope.launch { AppStore.deleteById(context, StoreKeys.RES_PROFILES, pid) }
                        }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Sil", tint = CyberError)
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmApply) {
        ConfirmDialog(
            title = "Çözünürlük değiştirilsin mi?",
            text = "Ekran çözünürlüğü ${targetW}x$targetH olarak ayarlanacak. Onaylamazsan 15 sn sonra önceki değere dönülür.",
            confirmLabel = "Uygula",
            onConfirm = {
                confirmApply = false
                scope.launch {
                    busy = true
                    val before = DisplayControl.read(context)
                    if (before == null) {
                        status = "Ekran bilgisi okunamadı; hiçbir değişiklik yapılmadı."
                        statusOk = false
                    } else {
                        prevHas = before.sizeOverridden
                        prevW = before.currentWidth
                        prevH = before.currentHeight
                        val r = DisplayControl.applySize(context, targetW, targetH)
                        display = DisplayControl.read(context)
                        if (r.ok) {
                            status = r.output
                            statusOk = true
                            pendingRevert = true
                        } else {
                            status = r.error ?: "Uygulanamadı"
                            statusOk = false
                        }
                    }
                    busy = false
                }
            },
            onDismiss = { confirmApply = false },
        )
    }

    if (confirmReset) {
        ConfirmDialog(
            title = "Varsayılana dönülsün mü?",
            text = "Çözünürlük fiziksel ekran değerine sıfırlanacak.",
            confirmLabel = "Sıfırla",
            onConfirm = {
                confirmReset = false
                scope.launch {
                    busy = true
                    val r = DisplayControl.resetSize(context)
                    display = DisplayControl.read(context)
                    status = if (r.ok) r.output else (r.error ?: "Sıfırlanamadı")
                    statusOk = r.ok
                    busy = false
                }
            },
            onDismiss = { confirmReset = false },
        )
    }

    if (pendingRevert) {
        SafeRevertDialog(
            message = "Çözünürlük ${targetW}x$targetH olarak ayarlandı.",
            onKeep = {
                pendingRevert = false
                status = "Çözünürlük korundu."
                statusOk = true
            },
            onRevert = {
                pendingRevert = false
                scope.launch {
                    val r = if (prevHas) {
                        DisplayControl.applySize(context, prevW, prevH)
                    } else {
                        DisplayControl.resetSize(context)
                    }
                    display = DisplayControl.read(context)
                    status = if (r.ok) "Önceki çözünürlüğe dönüldü." else "Geri alma başarısız: ${r.error ?: r.output}"
                    statusOk = r.ok
                }
            },
        )
    }
}

/** Telefon oranı (gri) ile hedef oranı (mavi) yan yana şematik gösterir. */
@Composable
private fun RatioPreview(phoneW: Int, phoneH: Int, targetW: Int, targetH: Int) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp),
    ) {
        val maxDim = max(max(phoneH, targetH), 1).toFloat()
        val scale = (size.height - 8f) / maxDim
        val pw = phoneW * scale
        val ph = phoneH * scale
        val tw = targetW * scale
        val th = targetH * scale
        val gap = 56f
        val startX = (size.width - (pw + gap + tw)) / 2f
        drawRoundRect(
            color = CyberOutline,
            topLeft = Offset(startX, (size.height - ph) / 2f),
            size = Size(pw, ph),
            cornerRadius = CornerRadius(12f, 12f),
            style = Stroke(width = 3f),
        )
        drawRoundRect(
            color = CyberPrimary.copy(alpha = 0.22f),
            topLeft = Offset(startX + pw + gap, (size.height - th) / 2f),
            size = Size(tw, th),
            cornerRadius = CornerRadius(12f, 12f),
        )
        drawRoundRect(
            color = CyberPrimary,
            topLeft = Offset(startX + pw + gap, (size.height - th) / 2f),
            size = Size(tw, th),
            cornerRadius = CornerRadius(12f, 12f),
            style = Stroke(width = 3f),
        )
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        Text("Ekran: ${phoneW}×$phoneH", fontSize = 11.sp, color = CyberTextMuted)
        Text("Hedef: ${targetW}×$targetH", fontSize = 11.sp, color = CyberPrimary)
    }
}
