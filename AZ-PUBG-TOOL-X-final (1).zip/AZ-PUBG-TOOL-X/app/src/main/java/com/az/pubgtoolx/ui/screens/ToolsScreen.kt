package com.az.pubgtoolx.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberChipRow
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.StatusBadge
import com.az.pubgtoolx.ui.navigation.ModuleCategory
import com.az.pubgtoolx.ui.navigation.ShizukuUse
import com.az.pubgtoolx.ui.navigation.ToolModule
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning
import com.az.pubgtoolx.ui.theme.Dimens

@Composable
fun ToolsScreen(onOpenModule: (ToolModule) -> Unit) {
    val categories = ModuleCategory.entries
    val labels = listOf("Hepsi") + categories.map { it.label }
    var selected by rememberSaveable { mutableIntStateOf(0) }

    val modules = if (selected == 0) {
        ToolModule.entries
    } else {
        ToolModule.entries.filter { it.category == categories[selected - 1] }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "Tools", subtitle = "Tüm modüller")
        CyberChipRow(
            options = labels,
            selectedIndex = selected,
            onSelect = { selected = it },
            modifier = Modifier.padding(horizontal = Dimens.ScreenPadding),
        )
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = Dimens.ScreenPadding, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(Dimens.ItemSpacing),
        ) {
            items(modules, key = { it.id }) { module ->
                CyberCard(modifier = Modifier.fillMaxWidth(), onClick = { onOpenModule(module) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(module.icon, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(26.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(module.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text(module.description, fontSize = 12.sp, color = CyberTextMuted)
                        }
                        val badge = module.shizuku.badge
                        if (badge != null) {
                            StatusBadge(badge, if (module.shizuku == ShizukuUse.REQUIRED) CyberWarning else CyberPrimary)
                        }
                    }
                }
            }
        }
    }
}
