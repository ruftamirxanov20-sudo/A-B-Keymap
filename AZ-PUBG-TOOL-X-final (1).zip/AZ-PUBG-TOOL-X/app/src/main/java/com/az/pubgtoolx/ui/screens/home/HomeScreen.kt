package com.az.pubgtoolx.ui.screens.home

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.az.pubgtoolx.core.device.DeviceInfo
import com.az.pubgtoolx.core.device.LiveStats
import com.az.pubgtoolx.core.shizuku.SHIZUKU_PACKAGE
import com.az.pubgtoolx.core.shizuku.ShizukuState
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.navigation.ToolModule
import com.az.pubgtoolx.ui.theme.CyberError
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSecondary
import com.az.pubgtoolx.ui.theme.CyberSuccess
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning

private const val SHIZUKU_DOWNLOAD_URL = "https://shizuku.rikka.app/download/"

@Composable
fun HomeScreen(
    onOpenModule: (ToolModule) -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: HomeViewModel = viewModel(),
) {
    val live by viewModel.live.collectAsStateWithLifecycle()
    val shizukuState by viewModel.shizukuState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { HomeHeader(onOpenSettings) }
        item { DeviceCard(viewModel.deviceInfo) }
        item {
            ShizukuCard(
                state = shizukuState,
                onRequestPermission = viewModel::requestShizukuPermission,
                onOpenShizuku = { openShizukuApp(context) },
                onOpenDownload = { openUrl(context, SHIZUKU_DOWNLOAD_URL) },
            )
        }
        item { StatRow(live, viewModel.deviceInfo.refreshRateHz) }
        item { SectionTitle("Hızlı Erişim") }
        items(ToolModule.homeTiles.chunked(3)) { rowModules ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                rowModules.forEach { module ->
                    ToolTile(module = module, modifier = Modifier.weight(1f)) { onOpenModule(module) }
                }
                repeat(3 - rowModules.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun HomeHeader(onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            Text(
                text = "AZ PUBG TOOL X",
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(CyberPrimary, CyberSecondary)),
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontStyle = FontStyle.Italic,
                ),
            )
            Text(
                text = "ULTIMATE GAMING COMPANION",
                fontSize = 10.sp,
                letterSpacing = 1.5.sp,
                color = CyberTextMuted,
            )
        }
        IconButton(onClick = onOpenSettings) {
            Icon(Icons.Filled.Settings, contentDescription = "Ayarlar", tint = CyberPrimary)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun DeviceCard(device: DeviceInfo) {
    CyberCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.PhoneAndroid, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(device.model, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Android ${device.androidVersion} (API ${device.apiLevel})", fontSize = 12.sp, color = CyberTextMuted)
            }
        }
        Spacer(Modifier.height(10.dp))
        InfoRow("İşlemci", device.cpu)
        InfoRow("RAM", formatGb(device.totalRamMb))
        InfoRow("Ekran", "${device.resolution} • ${device.dpi} dpi • ${device.refreshRateHz} Hz")
        InfoRow("ABI", device.abi)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 13.sp, color = CyberTextMuted)
        Spacer(Modifier.width(12.dp))
        Text(value, fontSize = 13.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1f, fill = false))
    }
}

private data class ShizukuUi(
    val title: String,
    val detail: String,
    val color: Color,
    val actionLabel: String? = null,
    val action: (() -> Unit)? = null,
)

@Composable
private fun ShizukuCard(
    state: ShizukuState,
    onRequestPermission: () -> Unit,
    onOpenShizuku: () -> Unit,
    onOpenDownload: () -> Unit,
) {
    val ui = when (state) {
        ShizukuState.NOT_INSTALLED -> ShizukuUi(
            title = "Shizuku yüklü değil",
            detail = "Shizuku olmadan çalışan modüller kullanılabilir. Sistem işlemleri için Shizuku gerekir.",
            color = CyberError,
            actionLabel = "İndirme sayfasını aç",
            action = onOpenDownload,
        )
        ShizukuState.NOT_RUNNING -> ShizukuUi(
            title = "Shizuku çalışmıyor",
            detail = "Shizuku yüklü ama servis başlatılmamış. Shizuku uygulamasını açıp servisi başlatın.",
            color = CyberWarning,
            actionLabel = "Shizuku'yu aç",
            action = onOpenShizuku,
        )
        ShizukuState.NEEDS_PERMISSION -> ShizukuUi(
            title = "İzin gerekli",
            detail = "Shizuku çalışıyor. Bu uygulamaya izin vermeniz gerekir.",
            color = CyberWarning,
            actionLabel = "İzin iste",
            action = onRequestPermission,
        )
        ShizukuState.PERMISSION_BLOCKED -> ShizukuUi(
            title = "İzin reddedilmiş",
            detail = "İzni Shizuku uygulamasından, yetkili uygulamalar listesinden verebilirsiniz.",
            color = CyberError,
            actionLabel = "Shizuku'yu aç",
            action = onOpenShizuku,
        )
        ShizukuState.READY -> ShizukuUi(
            title = "Bağlı ve yetkili",
            detail = "Shizuku hazır. Sistem işlemleri ilgili modüller eklendiğinde kullanılabilecek.",
            color = CyberSuccess,
        )
    }

    CyberCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(ui.color),
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Shizuku", fontSize = 12.sp, color = CyberTextMuted)
                Text(ui.title, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(ui.detail, fontSize = 12.sp, color = CyberTextMuted)
        if (ui.actionLabel != null && ui.action != null) {
            Spacer(Modifier.height(10.dp))
            CyberButton(text = ui.actionLabel, onClick = ui.action)
        }
    }
}

@Composable
private fun StatRow(live: LiveStats, refreshHz: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        StatCard("Ekran", "${refreshHz} Hz", "Yenileme", Icons.Filled.Speed, Modifier.weight(1f))
        StatCard(
            "Sıcaklık",
            live.batteryTempC?.let { "%.1f°C".format(it) } ?: "—",
            "Pil",
            Icons.Filled.Thermostat,
            Modifier.weight(1f),
        )
        StatCard(
            "Pil",
            live.batteryPercent?.let { "$it%" } ?: "—",
            if (live.charging) "Şarjda" else "Pilde",
            Icons.Filled.BatteryFull,
            Modifier.weight(1f),
        )
        StatCard("RAM", formatGb(live.availRamMb), "Boş", Icons.Filled.Memory, Modifier.weight(1f))
    }
}

@Composable
private fun StatCard(label: String, value: String, sub: String, icon: ImageVector, modifier: Modifier) {
    CyberCard(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, fontSize = 11.sp, color = CyberTextMuted, maxLines = 1)
        Text(sub, fontSize = 10.sp, color = CyberTextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ToolTile(module: ToolModule, modifier: Modifier, onClick: () -> Unit) {
    CyberCard(
        modifier = modifier.height(96.dp),
        onClick = onClick,
        contentPadding = PaddingValues(8.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(module.icon, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(6.dp))
        Text(
            module.shortTitle,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
        )
    }
}

private fun formatGb(mb: Long): String = "%.1f GB".format(mb / 1024f)

private fun openShizukuApp(context: Context) {
    try {
        val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
        if (intent != null) {
            context.startActivity(intent)
        } else {
            Toast.makeText(context, "Shizuku uygulaması bulunamadı", Toast.LENGTH_SHORT).show()
        }
    } catch (_: Exception) {
        Toast.makeText(context, "Shizuku açılamadı", Toast.LENGTH_SHORT).show()
    }
}

private fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (_: Exception) {
        Toast.makeText(context, "Bağlantı açılamadı", Toast.LENGTH_SHORT).show()
    }
}
