package com.az.pubgtoolx.ui.screens.hud

import org.json.JSONArray
import org.json.JSONObject

/** Önizlemedeki tek bir HUD düğmesi. x/y: önizleme alanına göre merkez konumu (0–1). */
internal data class HudButton(
    val key: String,
    val label: String,
    val x: Float,
    val y: Float,
    val size: Float = 1f,
    val visible: Boolean = true,
)

internal data class HudProfile(
    val fingers: Int,
    val globalSize: Float,
    val opacity: Float,
    val buttons: List<HudButton>,
)

internal object HudPresets {

    val FINGER_OPTIONS = listOf(2, 3, 4, 5)

    private fun b(key: String, label: String, x: Float, y: Float, size: Float = 1f) =
        HudButton(key, label, x, y, size, true)

    /** Başlangıç önerisi. Oyundaki gerçek düzeni değiştirmez; yalnızca planlama taslağıdır. */
    fun preset(fingers: Int): List<HudButton> {
        val common = listOf(
            b("FIRE", "ATEŞ", 0.88f, 0.55f, 1.3f),
            b("SCOPE", "DÜRBÜN", 0.76f, 0.36f),
            b("JUMP", "ZIPLA", 0.94f, 0.30f),
            b("CROUCH", "EĞİL", 0.94f, 0.82f),
            b("PRONE", "YAT", 0.83f, 0.84f),
            b("RELOAD", "ŞARJ", 0.68f, 0.72f),
        )
        return when (fingers) {
            2 -> common + listOf(
                b("LEAN_L", "SOL YT", 0.30f, 0.16f),
                b("LEAN_R", "SAĞ YT", 0.42f, 0.16f),
            )
            3 -> common + listOf(
                b("FIRE_L", "SOL ATEŞ", 0.12f, 0.50f, 1.15f),
                b("LEAN_L", "SOL YT", 0.30f, 0.16f),
                b("LEAN_R", "SAĞ YT", 0.42f, 0.16f),
            )
            4 -> common + listOf(
                b("FIRE_L", "SOL ATEŞ", 0.12f, 0.50f, 1.15f),
                b("LEAN_L", "SOL YT", 0.20f, 0.18f),
                b("LEAN_R", "SAĞ YT", 0.80f, 0.18f),
                b("SWITCH", "SİLAH", 0.58f, 0.84f, 0.85f),
            )
            else -> common + listOf(
                b("FIRE_L", "SOL ATEŞ", 0.12f, 0.50f, 1.15f),
                b("LEAN_L", "SOL YT", 0.20f, 0.18f),
                b("LEAN_R", "SAĞ YT", 0.80f, 0.18f),
                b("SWITCH", "SİLAH", 0.58f, 0.84f, 0.85f),
                b("GYRO", "NİŞAN", 0.66f, 0.50f, 0.85f),
            )
        }
    }

    fun describe(fingers: Int): String = when (fingers) {
        2 -> "2 parmak: iki başparmakla oynanır; tek ateş düğmesi sağda."
        3 -> "3 parmak: sağ işaret parmağı ek (sol) ateş düğmesi için kullanılır."
        4 -> "4 parmak: iki işaret parmağı ateş ve yatış düğmelerini üstlenir."
        else -> "5 parmak: dört parmak düzenine ek bir düğme daha eklenir."
    }
}

internal object HudCodec {

    fun toJson(id: String, name: String, profile: HudProfile): JSONObject {
        val arr = JSONArray()
        for (b in profile.buttons) {
            arr.put(
                JSONObject()
                    .put("k", b.key)
                    .put("l", b.label)
                    .put("x", b.x.toDouble())
                    .put("y", b.y.toDouble())
                    .put("s", b.size.toDouble())
                    .put("v", b.visible),
            )
        }
        return JSONObject()
            .put("id", id)
            .put("name", name)
            .put("updated", System.currentTimeMillis())
            .put("fingers", profile.fingers)
            .put("globalSize", profile.globalSize.toDouble())
            .put("opacity", profile.opacity.toDouble())
            .put("buttons", arr)
    }

    fun fromJson(o: JSONObject): HudProfile? {
        val arr = o.optJSONArray("buttons") ?: return null
        val list = ArrayList<HudButton>()
        for (i in 0 until arr.length()) {
            val j = arr.optJSONObject(i) ?: continue
            val key = j.optString("k")
            if (key.isEmpty()) continue
            list.add(
                HudButton(
                    key = key,
                    label = j.optString("l", key),
                    x = j.optDouble("x", 0.5).toFloat().coerceIn(0.04f, 0.96f),
                    y = j.optDouble("y", 0.5).toFloat().coerceIn(0.06f, 0.94f),
                    size = j.optDouble("s", 1.0).toFloat().coerceIn(0.5f, 2f),
                    visible = j.optBoolean("v", true),
                ),
            )
        }
        if (list.isEmpty()) return null
        return HudProfile(
            fingers = o.optInt("fingers", 3).coerceIn(2, 5),
            globalSize = o.optDouble("globalSize", 1.0).toFloat().coerceIn(0.6f, 1.6f),
            opacity = o.optDouble("opacity", 0.8).toFloat().coerceIn(0.3f, 1f),
            buttons = list,
        )
    }

    /** Oyunun kontrol düzeni ekranına elle uygulamak için okunabilir özet. */
    fun summary(name: String, p: HudProfile): String {
        val sb = StringBuilder()
        sb.append("HUD planı: ").append(name).append('\n')
        sb.append(p.fingers).append(" parmak • boyut x").append("%.2f".format(p.globalSize))
            .append(" • saydamlık %").append((p.opacity * 100).toInt()).append('\n')
        for (b in p.buttons) {
            sb.append("- ").append(b.label)
            if (!b.visible) {
                sb.append(": gizli\n")
            } else {
                sb.append(": yatay %").append((b.x * 100).toInt())
                    .append(", dikey %").append((b.y * 100).toInt())
                    .append(", boyut x").append("%.2f".format(b.size * p.globalSize)).append('\n')
            }
        }
        return sb.toString()
    }
}
