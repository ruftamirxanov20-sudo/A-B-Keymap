package com.az.pubgtoolx.ui.screens.cleaner

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import com.az.pubgtoolx.core.log.OperationLog
import com.az.pubgtoolx.core.shizuku.ShizukuShell
import com.az.pubgtoolx.core.util.Format
import kotlinx.coroutines.delay
import java.io.File

class StorageStat(val total: Long, val free: Long) {
    val used: Long get() = total - free
    val fraction: Float get() = if (total > 0L) used.toFloat() / total.toFloat() else 0f
}

class LargeFile(
    val id: Long,
    val uri: Uri,
    val name: String,
    val size: Long,
    val dateMillis: Long,
    val path: String,
)

class AppCacheEntry(val packageName: String, val bytes: Long)

class CacheAnalysis(val entries: List<AppCacheEntry>, val error: String?)

class TrimResult(val ok: Boolean, val message: String)

/** Phone Cleaner'ın tüm gerçek işlemleri: ölçüm, listeleme, silme istekleri. */
object CleanerLogic {

    const val MB: Long = 1024L * 1024L

    // ---- Depolama analizi ----

    fun internalStorage(): StorageStat? = statOf(Environment.getDataDirectory())

    @Suppress("DEPRECATION")
    fun sharedStorage(): StorageStat? = statOf(Environment.getExternalStorageDirectory())

    private fun statOf(dir: File): StorageStat? {
        return try {
            val s = StatFs(dir.path)
            StorageStat(s.totalBytes, s.availableBytes)
        } catch (e: Exception) {
            null
        }
    }

    // ---- Uygulamanın kendi önbelleği ----

    fun dirSize(file: File?): Long {
        if (file == null || !file.exists()) return 0L
        if (file.isFile) return file.length()
        val children = file.listFiles() ?: return 0L
        var total = 0L
        for (child in children) total += dirSize(child)
        return total
    }

    fun ownCacheBytes(context: Context): Long {
        return dirSize(context.cacheDir) + dirSize(context.externalCacheDir)
    }

    /** Başarılıysa null, hata varsa mesaj döner. */
    fun clearOwnCache(context: Context): String? {
        return try {
            val dirs = listOfNotNull(context.cacheDir, context.externalCacheDir)
            for (dir in dirs) {
                val children = dir.listFiles() ?: continue
                for (child in children) child.deleteRecursively()
            }
            null
        } catch (e: Exception) {
            e.message ?: "Silme hatası"
        }
    }

    // ---- Medya izinleri ----

    fun mediaPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    fun hasMediaPermission(context: Context): Boolean {
        return mediaPermissions().all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun hasAnyMediaPermission(context: Context): Boolean {
        return mediaPermissions().any {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    // ---- Büyük dosyalar (MediaStore) ----

    fun queryLargeFiles(context: Context, minBytes: Long, limit: Int = 50): List<LargeFile> {
        val filesUri = MediaStore.Files.getContentUri("external")
        val pathColumn = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.MediaColumns.RELATIVE_PATH
        } else {
            MediaStore.Files.FileColumns.DATA
        }
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            pathColumn,
        )
        val out = ArrayList<LargeFile>()
        try {
            val cursor = context.contentResolver.query(
                filesUri,
                projection,
                MediaStore.Files.FileColumns.SIZE + " >= ?",
                arrayOf(minBytes.toString()),
                MediaStore.Files.FileColumns.SIZE + " DESC",
            )
            if (cursor != null) {
                cursor.use { c ->
                    val idIdx = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                    val nameIdx = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                    val sizeIdx = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                    val dateIdx = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                    val typeIdx = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
                    val pathIdx = c.getColumnIndexOrThrow(pathColumn)
                    while (c.moveToNext() && out.size < limit) {
                        val id = c.getLong(idIdx)
                        val type = c.getInt(typeIdx)
                        val base: Uri = when (type) {
                            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                            MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                            else -> filesUri
                        }
                        val rawPath = c.getString(pathIdx) ?: ""
                        val shownPath = if (Build.VERSION.SDK_INT >= 29) {
                            rawPath
                        } else {
                            File(rawPath).parent ?: rawPath
                        }
                        out.add(
                            LargeFile(
                                id = id,
                                uri = ContentUris.withAppendedId(base, id),
                                name = c.getString(nameIdx) ?: "(adsız)",
                                size = c.getLong(sizeIdx),
                                dateMillis = c.getLong(dateIdx) * 1000L,
                                path = shownPath,
                            ),
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // İzin yok veya sorgu desteklenmiyor: toplanan kadarını döndür.
        }
        return out
    }

    /** Android 11+ için sistem silme onayı penceresi. Desteklenmiyorsa null. */
    fun createDeleteIntentSender(context: Context, uris: List<Uri>): IntentSender? {
        if (Build.VERSION.SDK_INT < 30) return null
        return MediaStore.createDeleteRequest(context.contentResolver, uris).intentSender
    }

    // ---- Shizuku ile (isteğe bağlı) ----

    suspend fun analyzeExternalCaches(context: Context): CacheAnalysis {
        val r = ShizukuShell.exec(
            context,
            "du -sk /storage/emulated/0/Android/data/*/cache 2>/dev/null",
        )
        if (r.output.isBlank()) {
            return CacheAnalysis(
                emptyList(),
                r.error ?: "Harici uygulama önbelleği bulunamadı veya okunamadı.",
            )
        }
        val list = ArrayList<AppCacheEntry>()
        for (line in r.output.lines()) {
            val parts = line.trim().split(Regex("\\s+"), 2)
            if (parts.size < 2) continue
            val kb = parts[0].toLongOrNull() ?: continue
            val path = parts[1].trim()
            if (!path.endsWith("/cache")) continue
            val pkg = path.removeSuffix("/cache").substringAfterLast('/')
            list.add(AppCacheEntry(pkg, kb * 1024L))
        }
        val top = list.sortedByDescending { it.bytes }.take(15)
        return CacheAnalysis(top, if (top.isEmpty()) "Çıktı ayrıştırılamadı." else null)
    }

    suspend fun trimAllCaches(context: Context): TrimResult {
        val before = internalStorage()?.free
        val r = ShizukuShell.exec(context, "pm trim-caches 999G")
        delay(1500L)
        val after = internalStorage()?.free
        val freed = if (before != null && after != null) after - before else null

        val success = r.ok
        val message: String = if (!success) {
            "Komut başarısız: " + (r.error ?: r.output).ifBlank { "bilinmeyen hata" }
        } else if (freed == null) {
            "Komut çalıştı ancak boş alan ölçülemedi."
        } else if (freed >= MB) {
            "Komut çalıştı. Ölçülen boş alan artışı: ${Format.bytes(freed)} (arka plan etkinliği ölçümü etkileyebilir)."
        } else {
            "Komut çalıştı ancak ölçülebilir bir fark yok."
        }
        OperationLog.add(context, "Cleaner", "Tüm önbellekleri temizle (pm trim-caches)", success, message)
        return TrimResult(success, message)
    }
}
