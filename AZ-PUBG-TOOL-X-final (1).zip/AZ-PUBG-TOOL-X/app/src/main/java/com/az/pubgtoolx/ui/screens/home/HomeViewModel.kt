package com.az.pubgtoolx.ui.screens.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.az.pubgtoolx.core.device.DeviceInfo
import com.az.pubgtoolx.core.device.DeviceInfoProvider
import com.az.pubgtoolx.core.device.LiveStats
import com.az.pubgtoolx.core.device.LiveStatsReader
import com.az.pubgtoolx.core.shizuku.ShizukuMonitor
import com.az.pubgtoolx.core.shizuku.ShizukuState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn

class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val shizuku = ShizukuMonitor(app)

    val shizukuState: StateFlow<ShizukuState> = shizuku.state

    val deviceInfo: DeviceInfo = DeviceInfoProvider.read(app)

    /**
     * Pil / sıcaklık / RAM her 5 saniyede okunur. Akış yalnızca ekran görünürken
     * (collectAsStateWithLifecycle) çalışır; arka planda hiçbir iş yapılmaz.
     */
    val live: StateFlow<LiveStats> = flow {
        while (true) {
            shizuku.refresh()
            emit(LiveStatsReader.read(app))
            delay(REFRESH_MS)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = LiveStatsReader.read(app),
    )

    init {
        shizuku.start()
    }

    fun requestShizukuPermission() = shizuku.requestPermission()

    override fun onCleared() {
        shizuku.stop()
        super.onCleared()
    }

    private companion object {
        const val REFRESH_MS = 5_000L
    }
}
