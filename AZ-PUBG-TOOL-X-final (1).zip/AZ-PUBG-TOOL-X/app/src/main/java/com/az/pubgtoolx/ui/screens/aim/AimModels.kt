package com.az.pubgtoolx.ui.screens.aim

import org.json.JSONObject

/**
 * Bir modun temel ayarları.
 * radiusFrac: hedef yarıçapı (ekranın kısa kenarına oran), lifeSec: hedef ömrü (0 = süresiz),
 * speedFrac: saniyedeki hız (kısa kenara oran), maxTargets: aynı anda hedef sayısı.
 */
data class AimModeConfig(
    val radiusFrac: Float,
    val lifeSec: Float,
    val moving: Boolean,
    val speedFrac: Float,
    val maxTargets: Int,
    val missPenalty: Int,
    val hitScore: Int,
)

enum class AimDifficulty(
    val label: String,
    val sizeMul: Float,
    val lifeMul: Float,
    val speedMul: Float,
) {
    EASY("Kolay", 1.3f, 1.4f, 0.7f),
    MEDIUM("Orta", 1.0f, 1.0f, 1.0f),
    HARD("Zor", 0.75f, 0.7f, 1.4f);

    companion object {
        fun parse(value: String?): AimDifficulty {
            for (d in values()) {
                if (d.name == value) return d
            }
            return MEDIUM
        }
    }
}

enum class AimMode(
    val label: String,
    val description: String,
    val config: AimModeConfig,
) {
    SNIPER(
        "Sniper",
        "Küçük, sabit ve uzun ömürlü hedefler. Her ıska puan düşürür; sakin ve isabetli ol.",
        AimModeConfig(0.045f, 3.0f, false, 0f, 1, 5, 100),
    ),
    AR(
        "AR",
        "Orta boy, yavaş hareket eden iki hedef. Hedefi takip edip doğru anda dokun.",
        AimModeConfig(0.06f, 2.5f, true, 0.15f, 2, 3, 100),
    ),
    SMG(
        "SMG",
        "Büyük ama hızlı hareket eden üç hedef. Hız ve refleks önemli.",
        AimModeConfig(0.08f, 2.0f, true, 0.30f, 3, 2, 80),
    ),
    FLICK(
        "Flick",
        "Hedef her seferinde uzak bir noktada kısa süre belirir. Hızlı sıçra ve vur.",
        AimModeConfig(0.06f, 1.2f, false, 0f, 1, 3, 100),
    ),
    TRACKING(
        "Tracking",
        "Tek hareketli hedef. Parmağını ekrandan kaldırmadan hedefin üstünde tut; puan hedefte kalma süresinden gelir.",
        AimModeConfig(0.09f, 0f, true, 0.22f, 1, 0, 0),
    ),
    REFLEX(
        "Reflex",
        "Hedef rastgele bir bekleme sonrası aniden belirir. Asıl ölçüt tepki süren; erken basarsan puan düşer.",
        AimModeConfig(0.07f, 1.5f, false, 0f, 1, 2, 100),
    ),
    PRECISION(
        "Precision",
        "Çok küçük sabit hedefler. Merkeze ne kadar yakın vurursan o kadar çok puan.",
        AimModeConfig(0.03f, 3.5f, false, 0f, 2, 5, 100),
    );

    companion object {
        fun parse(value: String?): AimMode {
            for (m in values()) {
                if (m.name == value) return m
            }
            return SNIPER
        }
    }
}

fun aimSessionTitle(mode: AimMode, difficulty: AimDifficulty, seconds: Int): String =
    "${mode.label} • ${difficulty.label} • ${seconds}sn"

/** Geçmişte saklanan bir seans. */
data class AimRecord(
    val id: String,
    val name: String,
    val updated: Long,
    val mode: AimMode,
    val difficulty: AimDifficulty,
    val seconds: Int,
    val hits: Int,
    val misses: Int,
    val accuracy: Double,
    val avgReactionMs: Int,
    val score: Int,
)

fun parseAimRecord(o: JSONObject): AimRecord = AimRecord(
    id = o.optString("id"),
    name = o.optString("name"),
    updated = o.optLong("updated"),
    mode = AimMode.parse(o.optString("mode")),
    difficulty = AimDifficulty.parse(o.optString("difficulty")),
    seconds = o.optInt("seconds"),
    hits = o.optInt("hits"),
    misses = o.optInt("misses"),
    accuracy = o.optDouble("accuracy", 0.0),
    avgReactionMs = o.optInt("avgReactionMs"),
    score = o.optInt("score"),
)
