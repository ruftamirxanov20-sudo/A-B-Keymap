package com.az.pubgtoolx.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.shizuku.SHIZUKU_PACKAGE
import com.az.pubgtoolx.core.shizuku.ShizukuMonitor
import com.az.pubgtoolx.core.shizuku.ShizukuState
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.ui.theme.CyberError
import com.az.pubgtoolx.ui.theme.CyberSuccess
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning
import kotlinx.coroutines.flow.StateFlow

private const val SHIZUKU_DOWNLOAD_URL = "https://shizuku.rikka.app/download/"

/** Ekranın Shizuku durumunu izlemesi için sarmalayıcı. [rememberShizuku] ile oluşturulur. */
class ShizukuController(private val monitor: ShizukuMonitor) {
    val state: StateFlow<ShizukuState> get() = monitor.state
    fun requestPermission() = monitor.requestPermission()
    fun refresh() = monitor.refresh()
}

/** Ekran görünür olduğu sürece Shizuku durumunu izler; ayrılınca dinleyicileri kaldırır. */
@Composable
fun rememberShizuku(): ShizukuController {
    val appContext = LocalContext.current.applicationContext
    val monitor = remember { ShizukuMonitor(appContext) }
    DisposableEffect(monitor) {
        monitor.start()
        onDispose { monitor.stop() }
    }
    return remember(monitor) { ShizukuController(monitor) }
}

/**
 * Shizuku gerektiren bölümler için kapı: Shizuku hazırsa [content] gösterilir,
 * değilse durumu açıklayan bir kart ve çalışan bir eylem düğmesi gösterilir.
 */
@Composable
fun ShizukuGate(
    controller: ShizukuController,
    featureText: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val state by controller.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { controller.refresh() }

    if (state == ShizukuState.READY) {
        content()
    } else {
        val title: String
        val detail: String
        val color: Color
        val actionLabel: String
        val action: () -> Unit
        when (state) {
            ShizukuState.NOT_INSTALLED -> {
                title = "Shizuku yüklü değil"
                detail = "$featureText için Shizuku gerekir."
                color = CyberError
                actionLabel = "İndirme sayfasını aç"
                action = { openUrl(context, SHIZUKU_DOWNLOAD_URL) }
            }
            ShizukuState.NOT_RUNNING -> {
                title = "Shizuku çalışmıyor"
                detail = "$featureText için Shizuku servisini başlatın."
                color = CyberWarning
                actionLabel = "Shizuku'yu aç"
                action = { openShizukuApp(context) }
            }
            ShizukuState.NEEDS_PERMISSION -> {
                title = "Shizuku izni gerekli"
                detail = "$featureText için bu uygulamaya Shizuku izni verin."
                color = CyberWarning
                actionLabel = "İzin iste"
                action = { controller.requestPermission() }
            }
            else -> {
                title = "Shizuku izni reddedilmiş"
                detail = "İzni Shizuku uygulamasındaki yetkili uygulamalar listesinden verin."
                color = CyberError
                actionLabel = "Shizuku'yu aç"
                action = { openShizukuApp(context) }
            }
        }
        CyberCard(modifier = modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(color),
                )
                Spacer(Modifier.width(10.dp))
                Text(title, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(6.dp))
            Text(detail, fontSize = 12.sp, color = CyberTextMuted)
            Spacer(Modifier.height(10.dp))
            CyberButton(text = actionLabel, onClick = action)
        }
    }
}

/** Küçük durum rozeti: Shizuku durumunu tek satırda gösterir (kapı olmadan). */
@Composable
fun ShizukuStatusBadge(controller: ShizukuController, modifier: Modifier = Modifier) {
    val state by controller.state.collectAsStateWithLifecycle()
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { controller.refresh() }
    when (state) {
        ShizukuState.READY -> StatusBadge("Shizuku hazır", CyberSuccess, modifier)
        ShizukuState.NEEDS_PERMISSION -> StatusBadge("Shizuku izni gerekli", CyberWarning, modifier)
        ShizukuState.PERMISSION_BLOCKED -> StatusBadge("Shizuku izni reddedildi", CyberError, modifier)
        ShizukuState.NOT_RUNNING -> StatusBadge("Shizuku çalışmıyor", CyberWarning, modifier)
        ShizukuState.NOT_INSTALLED -> StatusBadge("Shizuku yüklü değil", CyberError, modifier)
    }
}

private fun openShizukuApp(context: Context) {
    try {
        val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
        if (intent != null) {
            context.startActivity(intent)
        } else {
            toast(context, "Shizuku uygulaması bulunamadı")
        }
    } catch (e: Exception) {
        toast(context, "Shizuku açılamadı")
    }
}

private fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: Exception) {
        toast(context, "Bağlantı açılamadı")
    }
}
