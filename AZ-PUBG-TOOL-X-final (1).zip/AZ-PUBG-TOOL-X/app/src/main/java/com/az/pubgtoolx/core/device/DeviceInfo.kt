package com.az.pubgtoolx.core.device

import android.app.ActivityManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import kotlin.math.roundToInt

/** Cihazın değişmeyen (oturum boyunca sabit) bilgileri. */
data class DeviceInfo(
    val model: String,
    val androidVersion: String,
    val apiLevel: Int,
    val cpu: String,
    val abi: String,
    val totalRamMb: Long,
    val resolution: String,
    val dpi: Int,
    val refreshRateHz: Int,
)

object DeviceInfoProvider {

    @Suppress("DEPRECATION")
    fun read(context: Context): DeviceInfo {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo().also { activityManager.getMemoryInfo(it) }

        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display: Display? = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
        val metrics = DisplayMetrics()
        display?.getRealMetrics(metrics)

        val resolution = if (metrics.widthPixels > 0 && metrics.heightPixels > 0) {
            val w = minOf(metrics.widthPixels, metrics.heightPixels)
            val h = maxOf(metrics.widthPixels, metrics.heightPixels)
            "$w × $h"
        } else {
            "Okunamadı"
        }

        val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = if (Build.MODEL.startsWith(Build.MANUFACTURER, ignoreCase = true)) {
            Build.MODEL
        } else {
            "$manufacturer ${Build.MODEL}"
        }

        val cpu = if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            Build.SOC_MODEL.isNotBlank() &&
            Build.SOC_MODEL != Build.UNKNOWN
        ) {
            Build.SOC_MODEL
        } else {
            Build.HARDWARE
        }

        return DeviceInfo(
            model = model,
            androidVersion = Build.VERSION.RELEASE,
            apiLevel = Build.VERSION.SDK_INT,
            cpu = cpu,
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "?",
            totalRamMb = memoryInfo.totalMem / (1024L * 1024L),
            resolution = resolution,
            dpi = metrics.densityDpi,
            refreshRateHz = display?.refreshRate?.roundToInt() ?: 0,
        )
    }
}
