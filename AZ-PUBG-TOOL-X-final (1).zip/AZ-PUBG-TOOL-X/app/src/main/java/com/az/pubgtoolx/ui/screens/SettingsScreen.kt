package com.az.pubgtoolx.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.az.pubgtoolx.BuildConfig
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.ui.components.ConfirmDialog
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(onOpenLogs: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmClear by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "Settings")
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text("Hakkında", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                InfoLine("Uygulama", "AZ PUBG TOOL X")
                InfoLine("Sürüm", BuildConfig.VERSION_NAME)
                InfoLine("Paket", BuildConfig.APPLICATION_ID)
                InfoLine("Tema", "Cyber Blue (sabit)")
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text("İşlem kayıtları", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Sistem ayarı değiştiren işlemlerin (çözünürlük, DPI, temizlik vb.) sonuçları burada tutulur.",
                    fontSize = 12.sp,
                    color = CyberTextMuted,
                )
                Spacer(Modifier.height(10.dp))
                CyberButton(text = "Kayıtları aç", onClick = onOpenLogs)
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text("Yerel veriler", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Profiller, antrenman geçmişi, FPS kayıtları ve işlem kayıtları yalnızca bu cihazda saklanır. İnternete gönderilmez.",
                    fontSize = 12.sp,
                    color = CyberTextMuted,
                )
                Spacer(Modifier.height(10.dp))
                CyberButton(text = "Tüm yerel verileri sil", onClick = { confirmClear = true }, secondary = true)
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "Tüm veriler silinsin mi?",
            text = "Kayıtlı profiller, antrenman geçmişi, FPS kayıtları ve işlem kayıtları kalıcı olarak silinecek. Yedek dosyaları (Active.sav) silinmez.",
            confirmLabel = "Sil",
            onConfirm = {
                confirmClear = false
                scope.launch {
                    try {
                        AppStore.clearAll(context)
                        toast(context, "Yerel veriler silindi")
                    } catch (e: Exception) {
                        toast(context, "Silinemedi: ${e.message}")
                    }
                }
            },
            onDismiss = { confirmClear = false },
        )
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 13.sp, color = CyberTextMuted)
        Text(value, fontSize = 13.sp)
    }
}
