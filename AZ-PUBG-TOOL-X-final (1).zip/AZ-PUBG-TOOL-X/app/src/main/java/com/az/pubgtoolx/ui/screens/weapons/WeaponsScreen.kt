package com.az.pubgtoolx.ui.screens.weapons

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.data.StoreKeys
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberChipRow
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.InfoRow
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.components.StatusBadge
import com.az.pubgtoolx.ui.screens.resolution.AzTextField
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.launch
import org.json.JSONObject

private const val MAX_COMPARE = 3

private fun profileId(weapon: Weapon): String = "weapon_" + weapon.name.lowercase().replace(Regex("[^a-z0-9]"), "")

@Composable
fun WeaponsScreen(onTrain: (mode: String) -> Unit, onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var catIdx by remember { mutableIntStateOf(0) }
    var expanded by remember { mutableStateOf<String?>(null) }
    var compare by remember { mutableStateOf<List<String>>(emptyList()) }

    var editDamage by remember { mutableStateOf("") }
    var editRpm by remember { mutableStateOf("") }
    var editMag by remember { mutableStateOf("") }
    var editNote by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    val flow = remember { AppStore.arrayFlow(context, StoreKeys.WEAPON_PROFILES) }
    val saved by flow.collectAsStateWithLifecycle(initialValue = emptyList())
    val savedById = remember(saved) { saved.associateBy { it.optString("id") } }

    val categories = listOf("Tümü") + WeaponData.CATEGORIES
    val shown = if (catIdx == 0) WeaponData.ALL else WeaponData.ALL.filter { it.category == WeaponData.CATEGORIES[catIdx - 1] }

    fun openEditor(w: Weapon) {
        val p = savedById[profileId(w)]
        editDamage = if (p != null && p.has("damage")) p.optInt("damage").toString() else ""
        editRpm = if (p != null && p.has("rpm")) p.optInt("rpm").toString() else ""
        editMag = if (p != null && p.has("mag")) p.optInt("mag").toString() else ""
        editNote = p?.optString("note") ?: ""
        message = null
        expanded = w.name
    }

    fun dpsText(p: JSONObject?): String {
        if (p == null || !p.has("damage") || !p.has("rpm")) return "Hesaplanamaz (hasar ve atış hızı girilmeli)"
        val d = p.optInt("damage")
        val r = p.optInt("rpm")
        if (d <= 0 || r <= 0) return "Hesaplanamaz"
        return "%.0f (kuramsal, hasar × atış/sn)".format(d * r / 60.0)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "Weapon Database", subtitle = "Silah bilgisi ve Aim Lab bağlantısı", onBack = onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Burada yalnızca genel ve tutarlı bilgiler (kategori, mermi türü, atış modu) gösterilir. Hasar, atış hızı ve şarjör değerleri oyun sürümüne göre değiştiği ve güvenilir kaynaklar birbirini tutmadığı için hazır sayı verilmez; kendi gözlemlediğiniz değerleri girip kaydedebilirsiniz. \"Doğrulanamadı\" bilgi eksik demektir.",
                    fontSize = 12.sp,
                    color = CyberTextMuted,
                )
            }

            CyberChipRow(options = categories, selectedIndex = catIdx, onSelect = { catIdx = it })

            shown.forEach { w ->
                val id = profileId(w)
                val p = savedById[id]
                val isOpen = expanded == w.name
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(w.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        StatusBadge(w.category, CyberPrimary)
                        if (p != null) StatusBadge("Notlu", CyberWarning)
                    }
                    Spacer(Modifier.height(6.dp))
                    InfoRow("Mermi türü", w.ammo ?: "Doğrulanamadı")
                    InfoRow("Atış modu", w.fireMode ?: "Doğrulanamadı")
                    Text(WeaponData.aimReason(w.category), fontSize = 11.sp, color = CyberTextMuted)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CyberButton(text = "Aim'de çalış", onClick = { onTrain(WeaponData.aimMode(w.category)) })
                        CyberButton(
                            text = if (isOpen) "Kapat" else "Değerlerim",
                            onClick = { if (isOpen) expanded = null else openEditor(w) },
                            secondary = true,
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    val inCompare = compare.contains(w.name)
                    CyberButton(
                        text = if (inCompare) "Karşılaştırmadan çıkar" else "Karşılaştırmaya ekle",
                        onClick = {
                            if (inCompare) {
                                compare = compare - w.name
                            } else if (compare.size >= MAX_COMPARE) {
                                toast(context, "En fazla $MAX_COMPARE silah karşılaştırılır")
                            } else {
                                compare = compare + w.name
                            }
                        },
                        secondary = true,
                    )

                    if (isOpen) {
                        Spacer(Modifier.height(10.dp))
                        SectionTitle("Kendi değerlerim")
                        Text(
                            "Boş bırakılan alan \"girilmedi\" sayılır; sayı uydurulmaz.",
                            fontSize = 11.sp,
                            color = CyberTextMuted,
                        )
                        Spacer(Modifier.height(6.dp))
                        AzTextField(editDamage, { editDamage = it }, "Hasar", Modifier.fillMaxWidth(), numeric = true)
                        Spacer(Modifier.height(6.dp))
                        AzTextField(editRpm, { editRpm = it }, "Dakikadaki atış (RPM)", Modifier.fillMaxWidth(), numeric = true)
                        Spacer(Modifier.height(6.dp))
                        AzTextField(editMag, { editMag = it }, "Şarjör kapasitesi", Modifier.fillMaxWidth(), numeric = true)
                        Spacer(Modifier.height(6.dp))
                        AzTextField(editNote, { editNote = it }, "Not (ör. hassasiyet)", Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        CyberButton(
                            text = "Kaydet",
                            onClick = {
                                val o = JSONObject()
                                    .put("id", id)
                                    .put("name", w.name)
                                    .put("updated", System.currentTimeMillis())
                                editDamage.toIntOrNull()?.let { o.put("damage", it) }
                                editRpm.toIntOrNull()?.let { o.put("rpm", it) }
                                editMag.toIntOrNull()?.let { o.put("mag", it) }
                                if (editNote.isNotBlank()) o.put("note", editNote.trim())
                                scope.launch {
                                    try {
                                        AppStore.upsert(context, StoreKeys.WEAPON_PROFILES, o)
                                        message = "${w.name} değerleri kaydedildi."
                                    } catch (e: Exception) {
                                        message = "Kaydedilemedi: ${e.message}"
                                    }
                                }
                            },
                        )
                        if (message != null) {
                            Spacer(Modifier.height(4.dp))
                            Text(message ?: "", fontSize = 12.sp, color = CyberTextMuted)
                        }
                        Spacer(Modifier.height(6.dp))
                        InfoRow("Kuramsal DPS", dpsText(p))
                        if (p != null) {
                            Spacer(Modifier.height(6.dp))
                            CyberButton(
                                text = "Kaydı sil",
                                secondary = true,
                                onClick = {
                                    scope.launch {
                                        AppStore.deleteById(context, StoreKeys.WEAPON_PROFILES, id)
                                        editDamage = ""
                                        editRpm = ""
                                        editMag = ""
                                        editNote = ""
                                        message = "Kayıt silindi."
                                    }
                                },
                            )
                        }
                    }
                }
            }

            if (compare.isNotEmpty()) {
                val picked = compare.mapNotNull { name -> WeaponData.ALL.firstOrNull { it.name == name } }
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    SectionTitle("Karşılaştırma")
                    Spacer(Modifier.height(6.dp))
                    picked.forEach { w ->
                        val p = savedById[profileId(w)]
                        Text(w.name, fontWeight = FontWeight.SemiBold)
                        InfoRow("Kategori", w.category)
                        InfoRow("Mermi", w.ammo ?: "Doğrulanamadı")
                        InfoRow("Atış modu", w.fireMode ?: "Doğrulanamadı")
                        InfoRow("Hasar (benim)", if (p != null && p.has("damage")) p.optInt("damage").toString() else "girilmedi")
                        InfoRow("RPM (benim)", if (p != null && p.has("rpm")) p.optInt("rpm").toString() else "girilmedi")
                        InfoRow("Şarjör (benim)", if (p != null && p.has("mag")) p.optInt("mag").toString() else "girilmedi")
                        InfoRow("Kuramsal DPS", dpsText(p))
                        Spacer(Modifier.width(1.dp))
                        Spacer(Modifier.height(10.dp))
                    }
                    CyberButton(text = "Karşılaştırmayı temizle", onClick = { compare = emptyList() }, secondary = true)
                }
            }
            Spacer(Modifier.height(Dimens.SectionSpacing))
        }
    }
}
