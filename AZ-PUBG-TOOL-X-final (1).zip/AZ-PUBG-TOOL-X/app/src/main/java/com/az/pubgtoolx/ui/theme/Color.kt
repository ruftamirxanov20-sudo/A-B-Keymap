package com.az.pubgtoolx.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBackground = Color(0xFF070B14)
val CyberSurface = Color(0xFF101B2D)
val CyberPrimary = Color(0xFF168BFF)
val CyberSecondary = Color(0xFF8055FF)
val CyberText = Color(0xFFFFFFFF)
val CyberTextMuted = Color(0xFF8FA3BF)
val CyberOutline = Color(0xFF1E3A5F)
val CyberSuccess = Color(0xFF2ECC71)
val CyberWarning = Color(0xFFFFB020)
val CyberError = Color(0xFFFF4D5E)
