package com.az.pubgtoolx.core.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Format {

    fun bytes(value: Long): String {
        if (value < 1024L) return "$value B"
        val kb = value / 1024.0
        if (kb < 1024.0) return "%.1f KB".format(kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return "%.1f MB".format(mb)
        return "%.2f GB".format(mb / 1024.0)
    }

    fun dateTime(millis: Long): String {
        val f = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.forLanguageTag("tr-TR"))
        return f.format(Date(millis))
    }

    fun time(millis: Long): String {
        val f = SimpleDateFormat("HH:mm:ss", Locale.forLanguageTag("tr-TR"))
        return f.format(Date(millis))
    }
}
