package com.az.pubgtoolx.ui.screens.dpi

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.data.StoreKeys
import com.az.pubgtoolx.core.shizuku.ShizukuState
import com.az.pubgtoolx.core.system.DisplayControl
import com.az.pubgtoolx.core.system.DisplayState
import com.az.pubgtoolx.core.util.copyToClipboard
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.ui.components.ConfirmDialog
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberSlider
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.InfoRow
import com.az.pubgtoolx.ui.components.SafeRevertDialog
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.components.ShizukuGate
import com.az.pubgtoolx.ui.components.rememberShizuku
import com.az.pubgtoolx.ui.screens.resolution.AzTextField
import com.az.pubgtoolx.ui.screens.resolution.CheckLevel
import com.az.pubgtoolx.ui.screens.resolution.CheckLine
import com.az.pubgtoolx.ui.screens.resolution.StatusCard
import com.az.pubgtoolx.ui.screens.resolution.appMetrics
import com.az.pubgtoolx.ui.screens.resolution.pxToDp
import com.az.pubgtoolx.ui.theme.CyberError
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.roundToInt

@Composable
fun DpiScreen(onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizuku = rememberShizuku()
    val sState by shizuku.state.collectAsStateWithLifecycle()
    val ready = sState == ShizukuState.READY
    val metrics = remember { appMetrics(context) }

    var display by remember { mutableStateOf<DisplayState?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var statusOk by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }

    var pendingRevert by rememberSaveable { mutableStateOf(false) }
    var prevHas by rememberSaveable { mutableStateOf(false) }
    var prevDpi by rememberSaveable { mutableIntStateOf(0) }

    var targetDpi by rememberSaveable { mutableIntStateOf(0) }
    var dpiText by rememberSaveable { mutableStateOf("") }
    var profileName by rememberSaveable { mutableStateOf("") }
    var confirmApply by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }

    LaunchedEffect(ready) {
        display = if (ready) DisplayControl.read(context) else null
    }

    val d = display
    val currentDpi = d?.currentDensity ?: metrics.densityDpi
    val curShort = d?.currentWidth ?: metrics.shortPx
    val curLong = d?.currentHeight ?: metrics.longPx

    // İlk açılışta hedef = mevcut DPI.
    LaunchedEffect(currentDpi) {
        if (targetDpi == 0) {
            targetDpi = currentDpi
            dpiText = currentDpi.toString()
        }
    }
    val target = if (targetDpi in 120..960) targetDpi else 0

    val profilesFlow = remember { AppStore.arrayFlow(context, StoreKeys.DPI_PROFILES) }
    val profiles by profilesFlow.collectAsStateWithLifecycle(initialValue = emptyList())

    BackHandler(enabled = pendingRevert) { }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "DP/DPI Controller", subtitle = "DPI profilleri ve dp hesabı", onBack = if (pendingRevert) null else onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Mevcut durum")
                Spacer(Modifier.height(6.dp))
                InfoRow("Mevcut DPI", currentDpi.toString())
                if (d != null) {
                    InfoRow("Fiziksel DPI", d.physicalDensity.toString())
                    InfoRow("Durum", if (d.densityOverridden) "Değiştirilmiş" else "Varsayılan")
                } else {
                    Text("Fiziksel/değiştirilmiş ayrımı için Shizuku gerekir.", fontSize = 11.sp, color = CyberTextMuted)
                }
                InfoRow("Çözünürlük", "$curShort × $curLong")
                InfoRow("dp genişlik (smallest width)", "${pxToDp(curShort, currentDpi)} dp")
                InfoRow("dp yükseklik", "${pxToDp(curLong, currentDpi)} dp")
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Özel DPI")
                Spacer(Modifier.height(6.dp))
                val sliderValue = (if (target > 0) target else currentDpi).coerceIn(120, 960).toFloat()
                CyberSlider(
                    label = "DPI",
                    value = sliderValue,
                    onValueChange = {
                        targetDpi = it.roundToInt()
                        dpiText = targetDpi.toString()
                    },
                    valueRange = 120f..960f,
                    valueText = "${sliderValue.roundToInt()}",
                )
                AzTextField(
                    value = dpiText,
                    onValueChange = {
                        dpiText = it
                        targetDpi = it.toIntOrNull() ?: 0
                    },
                    label = "DPI değeri (120–960)",
                    modifier = Modifier.fillMaxWidth(),
                    numeric = true,
                )
                Spacer(Modifier.height(8.dp))
                if (target > 0) {
                    val sw = pxToDp(curShort, target)
                    InfoRow("Önizleme: dp genişlik", "$sw dp")
                    InfoRow("Önizleme: dp yükseklik", "${pxToDp(curLong, target)} dp")
                    Spacer(Modifier.height(4.dp))
                    if (sw < 320) {
                        CheckLine(CheckLevel.ERROR, "Genişlik 320 dp altında; arayüz bozulabilir veya kullanılamaz hale gelebilir.")
                    } else if (sw < 360) {
                        CheckLine(CheckLevel.WARN, "Genişlik düşük; bazı arayüzler sıkışık görünebilir.")
                    } else {
                        CheckLine(CheckLevel.OK, "Genişlik normal aralıkta.")
                    }
                } else {
                    CheckLine(CheckLevel.ERROR, "Geçerli bir DPI girin (120–960).")
                }
            }

            if (status != null) {
                StatusCard(text = status ?: "", ok = statusOk)
            }

            ShizukuGate(controller = shizuku, featureText = "DPI değiştirmek") {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    SectionTitle("Uygula")
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Değişiklikten sonra 15 saniye içinde onaylamazsan önceki DPI'a otomatik dönülür. Uygulamadan önce mevcut değer yedeklenir.",
                        fontSize = 12.sp,
                        color = CyberTextMuted,
                    )
                    Spacer(Modifier.height(10.dp))
                    CyberButton(
                        text = "Uygula ($target DPI)",
                        onClick = { confirmApply = true },
                        enabled = target > 0 && !busy,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    CyberButton(
                        text = "Varsayılana dön",
                        onClick = { confirmReset = true },
                        enabled = !busy && (d?.densityOverridden ?: true),
                        secondary = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Shizuku'suz alternatif (adb)")
                Spacer(Modifier.height(8.dp))
                CyberButton(
                    text = "Uygulama komutunu kopyala",
                    onClick = {
                        if (target > 0) {
                            copyToClipboard(context, "adb", "adb shell wm density $target")
                            toast(context, "Komut kopyalandı")
                        } else {
                            toast(context, "Önce geçerli bir DPI girin")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                CyberButton(
                    text = "Sıfırlama komutunu kopyala",
                    onClick = {
                        copyToClipboard(context, "adb", "adb shell wm density reset")
                        toast(context, "Komut kopyalandı")
                    },
                    secondary = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("DPI profilleri")
                Spacer(Modifier.height(6.dp))
                AzTextField(profileName, { profileName = it }, "Profil adı", Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                CyberButton(
                    text = "Hedefi profil olarak kaydet",
                    onClick = {
                        val name = profileName.trim()
                        if (name.isEmpty()) {
                            toast(context, "Profil adı girin")
                        } else if (target <= 0) {
                            toast(context, "Geçerli bir DPI girin")
                        } else {
                            scope.launch {
                                val obj = JSONObject()
                                    .put("id", AppStore.newId())
                                    .put("name", name)
                                    .put("updated", System.currentTimeMillis())
                                    .put("dpi", target)
                                AppStore.upsert(context, StoreKeys.DPI_PROFILES, obj, 50)
                                profileName = ""
                                toast(context, "Profil kaydedildi")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                if (profiles.isEmpty()) {
                    Text("Kayıtlı profil yok.", fontSize = 12.sp, color = CyberTextMuted)
                }
                for (p in profiles) {
                    val pd = p.optInt("dpi")
                    val pid = p.optString("id")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(p.optString("name"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("$pd DPI  •  ${pxToDp(curShort, pd)} dp genişlik", fontSize = 12.sp, color = CyberTextMuted)
                        }
                        CyberButton(
                            text = "Seç",
                            onClick = {
                                targetDpi = pd
                                dpiText = pd.toString()
                            },
                        )
                        IconButton(onClick = {
                            scope.launch { AppStore.deleteById(context, StoreKeys.DPI_PROFILES, pid) }
                        }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Sil", tint = CyberError)
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmApply) {
        ConfirmDialog(
            title = "DPI değiştirilsin mi?",
            text = "DPI $target olarak ayarlanacak. Onaylamazsan 15 sn sonra önceki değere dönülür.",
            confirmLabel = "Uygula",
            onConfirm = {
                confirmApply = false
                scope.launch {
                    busy = true
                    val before = DisplayControl.read(context)
                    if (before == null) {
                        status = "Ekran bilgisi okunamadı; hiçbir değişiklik yapılmadı."
                        statusOk = false
                    } else {
                        prevHas = before.densityOverridden
                        prevDpi = before.currentDensity
                        val r = DisplayControl.applyDensity(context, target)
                        display = DisplayControl.read(context)
                        if (r.ok) {
                            status = r.output
                            statusOk = true
                            pendingRevert = true
                        } else {
                            status = r.error ?: "Uygulanamadı"
                            statusOk = false
                        }
                    }
                    busy = false
                }
            },
            onDismiss = { confirmApply = false },
        )
    }

    if (confirmReset) {
        ConfirmDialog(
            title = "Varsayılana dönülsün mü?",
            text = "DPI fiziksel ekran değerine sıfırlanacak.",
            confirmLabel = "Sıfırla",
            onConfirm = {
                confirmReset = false
                scope.launch {
                    busy = true
                    val r = DisplayControl.resetDensity(context)
                    display = DisplayControl.read(context)
                    status = if (r.ok) r.output else (r.error ?: "Sıfırlanamadı")
                    statusOk = r.ok
                    busy = false
                }
            },
            onDismiss = { confirmReset = false },
        )
    }

    if (pendingRevert) {
        SafeRevertDialog(
            message = "DPI $target olarak ayarlandı.",
            onKeep = {
                pendingRevert = false
                status = "DPI korundu."
                statusOk = true
            },
            onRevert = {
                pendingRevert = false
                scope.launch {
                    val r = if (prevHas) {
                        DisplayControl.applyDensity(context, prevDpi)
                    } else {
                        DisplayControl.resetDensity(context)
                    }
                    display = DisplayControl.read(context)
                    status = if (r.ok) "Önceki DPI'a dönüldü." else "Geri alma başarısız: ${r.error ?: r.output}"
                    statusOk = r.ok
                }
            },
        )
    }
}
