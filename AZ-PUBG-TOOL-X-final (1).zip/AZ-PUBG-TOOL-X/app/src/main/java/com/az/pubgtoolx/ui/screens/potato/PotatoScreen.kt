package com.az.pubgtoolx.ui.screens.potato

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.az.pubgtoolx.core.device.DeviceInfoProvider
import com.az.pubgtoolx.core.log.OperationLog
import com.az.pubgtoolx.ui.components.ConfirmDialog
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.InfoRow
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.components.ShizukuGate
import com.az.pubgtoolx.ui.components.StatusBadge
import com.az.pubgtoolx.ui.components.rememberShizuku
import com.az.pubgtoolx.ui.screens.resolution.StatusCard
import com.az.pubgtoolx.ui.theme.CyberSuccess
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.launch

private data class PotatoProfile(
    val title: String,
    val summary: String,
    val animValue: String,
    val animText: String,
    val gameTips: List<String>,
)

private val PROFILES = listOf(
    PotatoProfile(
        title = "Dengeli",
        summary = "Görüntü kalitesini koruyarak akıcılık.",
        animValue = "1.0",
        animText = "Animasyon ölçeği: 1x (sistem varsayılanı)",
        gameTips = listOf("Grafik: Dengeli veya HD", "Kare hızı: Yüksek", "Gölge: Açık", "Anti-aliasing: Açık"),
    ),
    PotatoProfile(
        title = "Hızlı",
        summary = "Orta seviye cihazlarda daha az takılma ve ısınma.",
        animValue = "0.5",
        animText = "Animasyon ölçeği: 0.5x",
        gameTips = listOf("Grafik: Düzgün", "Kare hızı: Yüksek", "Gölge: Kapalı", "Anti-aliasing: Kapalı"),
    ),
    PotatoProfile(
        title = "Potato",
        summary = "Düşük RAM'li cihazlar için en hafif ayarlar.",
        animValue = "0",
        animText = "Animasyon ölçeği: kapalı",
        gameTips = listOf("Grafik: Düzgün", "Kare hızı: Orta veya Yüksek (cihaz kaldırıyorsa)", "Gölge: Kapalı", "Anti-aliasing: Kapalı", "Arka plan uygulamalarını kapatın"),
    ),
)

@Composable
fun PotatoScreen(onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizuku = rememberShizuku()

    val info = remember { DeviceInfoProvider.read(context) }
    val recommended = when {
        info.totalRamMb in 1L..3500L -> 2
        info.totalRamMb in 3501L..6500L -> 1
        else -> 0
    }

    var scales by remember { mutableStateOf<PotatoLogic.Scales?>(null) }
    var hasBackup by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf<String?>(null) }
    var statusOk by remember { mutableStateOf(true) }
    var reloadKey by remember { mutableIntStateOf(0) }
    var pendingApply by remember { mutableStateOf<PotatoProfile?>(null) }
    var confirmRestore by remember { mutableStateOf(false) }

    LaunchedEffect(reloadKey) {
        hasBackup = PotatoLogic.hasBackup(context)
    }

    suspend fun refreshScales() {
        when (val r = PotatoLogic.read(context)) {
            is PotatoLogic.Result.Ok -> scales = r.scales
            is PotatoLogic.Result.Fail -> {
                statusText = r.reason
                statusOk = false
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "Potato Graphics", subtitle = "Düşük cihaz rehberi ve animasyon ayarı", onBack = onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Cihazınız")
                Spacer(Modifier.height(6.dp))
                InfoRow("Model", info.model)
                InfoRow("RAM", "${info.totalRamMb} MB")
                InfoRow("Önerilen profil", PROFILES[recommended].title)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Oyun içi grafik ayarları oyunun kendi menüsünden elle yapılır; bu uygulama oyun dosyalarını veya ayarlarını değiştirmez. Seçenek adları oyun sürümüne göre farklı olabilir.",
                    fontSize = 11.sp,
                    color = CyberTextMuted,
                )
            }

            PROFILES.forEachIndexed { index, p ->
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(p.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        if (index == recommended) StatusBadge("Önerilen", CyberSuccess)
                    }
                    Text(p.summary, fontSize = 12.sp, color = CyberTextMuted)
                    Spacer(Modifier.height(6.dp))
                    p.gameTips.forEach { Text("• $it", fontSize = 12.sp) }
                    Text("• ${p.animText}", fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    CyberButton(
                        text = "Animasyonu uygula",
                        onClick = { pendingApply = p },
                        enabled = !busy,
                        secondary = true,
                    )
                }
            }

            SectionTitle("Sistem animasyon ölçekleri")
            ShizukuGate(controller = shizuku, featureText = "Sistem animasyon ayarlarını değiştirmek") {
                LaunchedEffect(reloadKey) { refreshScales() }
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    val s = scales
                    if (s == null) {
                        Text("Okunuyor…", fontSize = 13.sp, color = CyberTextMuted)
                    } else {
                        InfoRow("Pencere animasyonu", s.values["window_animation_scale"] ?: "tanımsız (varsayılan 1)")
                        InfoRow("Geçiş animasyonu", s.values["transition_animation_scale"] ?: "tanımsız (varsayılan 1)")
                        InfoRow("Animatör süresi", s.values["animator_duration_scale"] ?: "tanımsız (varsayılan 1)")
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (hasBackup) "Önceki değerler yedeklendi; \"Önceki ayara dön\" ile geri yükleyebilirsiniz." else "Henüz değişiklik yapılmadı (yedek yok).",
                        fontSize = 11.sp,
                        color = CyberTextMuted,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CyberButton(text = "Yenile", onClick = { reloadKey += 1 }, enabled = !busy, secondary = true)
                        CyberButton(
                            text = "Önceki ayara dön",
                            onClick = { confirmRestore = true },
                            enabled = hasBackup && !busy,
                        )
                    }
                }
            }

            if (statusText != null) {
                StatusCard(text = statusText ?: "", ok = statusOk)
            }
            Spacer(Modifier.height(Dimens.SectionSpacing))
        }
    }

    val target = pendingApply
    if (target != null) {
        ConfirmDialog(
            title = "${target.title}: animasyon ayarı uygulansın mı?",
            text = "Üç sistem animasyon ölçeği ${target.animValue} değerine ayarlanacak. Önceki değerler yedeklenir ve istediğiniz zaman geri yüklenebilir. Uygulanınca değerler geri okunarak doğrulanır.",
            confirmLabel = "Uygula",
            onConfirm = {
                pendingApply = null
                busy = true
                scope.launch {
                    val r = PotatoLogic.apply(context, target.animValue)
                    when (r) {
                        is PotatoLogic.Result.Ok -> {
                            scales = r.scales
                            statusText = "Uygulandı ve doğrulandı: animasyon ölçeği ${target.animValue}."
                            statusOk = true
                            OperationLog.add(context, "Potato", "Animasyon ölçeği ${target.animValue}", true, "Doğrulandı")
                        }
                        is PotatoLogic.Result.Fail -> {
                            statusText = r.reason
                            statusOk = false
                            OperationLog.add(context, "Potato", "Animasyon ölçeği ${target.animValue}", false, r.reason)
                        }
                    }
                    reloadKey += 1
                    busy = false
                }
            },
            onDismiss = { pendingApply = null },
        )
    }
    if (confirmRestore) {
        ConfirmDialog(
            title = "Önceki ayara dönülsün mü?",
            text = "Animasyon ölçekleri bu uygulamayı kullanmadan önceki değerlere döndürülecek.",
            confirmLabel = "Geri yükle",
            onConfirm = {
                confirmRestore = false
                busy = true
                scope.launch {
                    when (val r = PotatoLogic.restore(context)) {
                        is PotatoLogic.Result.Ok -> {
                            scales = r.scales
                            statusText = "Önceki değerler geri yüklendi ve doğrulandı."
                            statusOk = true
                            OperationLog.add(context, "Potato", "Animasyon ayarını geri alma", true, "Doğrulandı")
                        }
                        is PotatoLogic.Result.Fail -> {
                            statusText = r.reason
                            statusOk = false
                            OperationLog.add(context, "Potato", "Animasyon ayarını geri alma", false, r.reason)
                        }
                    }
                    reloadKey += 1
                    busy = false
                }
            },
            onDismiss = { confirmRestore = false },
        )
    }
}
