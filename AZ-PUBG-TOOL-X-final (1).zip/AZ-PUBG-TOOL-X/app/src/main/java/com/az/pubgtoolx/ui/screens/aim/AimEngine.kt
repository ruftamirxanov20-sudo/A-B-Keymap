package com.az.pubgtoolx.ui.screens.aim

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class AimTarget(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val radius: Float,
    val life: Float,
) {
    var age: Float = 0f
}

/** Vuruş / ıska geri bildirim halkası (kısa ömürlü). */
class AimMarker(val x: Float, val y: Float, val hit: Boolean) {
    var age: Float = 0f
}

data class AimResult(
    val hits: Int,
    val misses: Int,
    val missShots: Int,
    val expired: Int,
    val accuracy: Double,
    val avgReactionMs: Int,
    val score: Int,
    val onTargetSec: Float,
    val trackedSec: Float,
)

/**
 * Compose'tan bağımsız antrenman mantığı. Tüm çağrılar ana iş parçacığından yapılır.
 * Koordinatlar çizim alanının piksel koordinatlarıdır.
 */
class AimEngine(
    val mode: AimMode,
    val difficulty: AimDifficulty,
    val durationSec: Int,
) {
    private val cfg: AimModeConfig = mode.config
    private val random = Random(System.nanoTime())

    val targets = ArrayList<AimTarget>()
    val markers = ArrayList<AimMarker>()

    var width: Float = 0f
        private set
    var height: Float = 0f
        private set
    private var minDim: Float = 0f

    var elapsed: Float = 0f
        private set
    var hits: Int = 0
        private set
    var missShots: Int = 0
        private set
    var expired: Int = 0
        private set
    var score: Int = 0
        private set

    var pointerDown: Boolean = false
        private set
    var pointerX: Float = 0f
        private set
    var pointerY: Float = 0f
        private set
    var onTarget: Boolean = false
        private set

    private var reactionSumMs: Float = 0f
    private var reactionCount: Int = 0
    private var onTargetSec: Float = 0f
    private var trackedSec: Float = 0f
    private var turnTimer: Float = 0f
    private var reflexWait: Float = -1f
    private var lastX: Float = 0f
    private var lastY: Float = 0f

    val finished: Boolean get() = elapsed >= durationSec
    val remainingSec: Float get() = max(0f, durationSec - elapsed)
    val misses: Int get() = missShots + expired

    val accuracyPercent: Double
        get() {
            return if (mode == AimMode.TRACKING) {
                if (trackedSec > 0f) onTargetSec.toDouble() / trackedSec.toDouble() * 100.0 else 0.0
            } else {
                val total = hits + misses
                if (total > 0) hits * 100.0 / total else 0.0
            }
        }

    fun setArea(w: Float, h: Float) {
        if (w == width && h == height) return
        width = w
        height = h
        minDim = min(w, h)
        targets.clear()
        lastX = w / 2f
        lastY = h / 2f
    }

    private fun radius(): Float = cfg.radiusFrac * difficulty.sizeMul * minDim
    private fun life(): Float = cfg.lifeSec * difficulty.lifeMul
    private fun speed(): Float = cfg.speedFrac * difficulty.speedMul * minDim

    private fun dist(ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = ax - bx
        val dy = ay - by
        return sqrt(dx * dx + dy * dy)
    }

    private fun spawn() {
        val r = radius()
        val margin = r + 6f
        if (width <= margin * 2f || height <= margin * 2f) return

        var bestX = width / 2f
        var bestY = height / 2f
        var bestQuality = -1f
        for (i in 0 until 14) {
            val cx = margin + random.nextFloat() * (width - 2f * margin)
            val cy = margin + random.nextFloat() * (height - 2f * margin)
            var minD = Float.MAX_VALUE
            for (t in targets) {
                val d = dist(cx, cy, t.x, t.y)
                if (d < minD) minD = d
            }
            val quality = if (mode == AimMode.FLICK) dist(cx, cy, lastX, lastY) else minD
            if (quality > bestQuality) {
                bestQuality = quality
                bestX = cx
                bestY = cy
            }
            if (mode != AimMode.FLICK && minD >= r * 2.4f) {
                bestX = cx
                bestY = cy
                break
            }
        }

        var vx = 0f
        var vy = 0f
        if (cfg.moving) {
            val angle = random.nextFloat() * 2f * PI.toFloat()
            val s = speed()
            vx = cos(angle) * s
            vy = sin(angle) * s
        }
        targets.add(AimTarget(bestX, bestY, vx, vy, r, life()))
        lastX = bestX
        lastY = bestY
    }

    private fun move(t: AimTarget, dt: Float) {
        t.x += t.vx * dt
        t.y += t.vy * dt
        val r = t.radius
        if (t.x < r) {
            t.x = r
            t.vx = abs(t.vx)
        } else if (t.x > width - r) {
            t.x = width - r
            t.vx = -abs(t.vx)
        }
        if (t.y < r) {
            t.y = r
            t.vy = abs(t.vy)
        } else if (t.y > height - r) {
            t.y = height - r
            t.vy = -abs(t.vy)
        }
    }

    /** dtRaw saniye cinsindendir; en çok 0.05 sn işlenir. */
    fun update(dtRaw: Float) {
        if (finished || width <= 0f || height <= 0f) return
        val dt = if (dtRaw < 0f) 0f else if (dtRaw > 0.05f) 0.05f else dtRaw
        elapsed += dt
        ageMarkers(dt)
        if (mode == AimMode.TRACKING) {
            updateTracking(dt)
        } else {
            updateDiscrete(dt)
        }
        if (elapsed >= durationSec) {
            elapsed = durationSec.toFloat()
            targets.clear()
            onTarget = false
        }
    }

    private fun ageMarkers(dt: Float) {
        var i = markers.size - 1
        while (i >= 0) {
            val m = markers[i]
            m.age += dt
            if (m.age > 0.3f) markers.removeAt(i)
            i--
        }
    }

    private fun addMarker(x: Float, y: Float, hit: Boolean) {
        markers.add(AimMarker(x, y, hit))
        if (markers.size > 8) markers.removeAt(0)
    }

    private fun updateDiscrete(dt: Float) {
        var i = targets.size - 1
        while (i >= 0) {
            val t = targets[i]
            t.age += dt
            if (cfg.moving) move(t, dt)
            if (t.life > 0f && t.age >= t.life) {
                expired++
                score = max(0, score - cfg.missPenalty)
                targets.removeAt(i)
            }
            i--
        }

        if (mode == AimMode.REFLEX) {
            if (targets.isEmpty()) {
                if (reflexWait < 0f) {
                    reflexWait = 0.6f + random.nextFloat() * 1.4f
                } else {
                    reflexWait -= dt
                    if (reflexWait <= 0f) {
                        spawn()
                        reflexWait = -1f
                    }
                }
            }
        } else {
            while (targets.size < cfg.maxTargets) {
                val before = targets.size
                spawn()
                if (targets.size == before) break
            }
        }
    }

    private fun updateTracking(dt: Float) {
        if (targets.isEmpty()) {
            spawn()
            turnTimer = 1f
        }
        val t = targets.firstOrNull() ?: return
        turnTimer -= dt
        if (turnTimer <= 0f) {
            val angle = random.nextFloat() * 2f * PI.toFloat()
            val s = speed()
            t.vx = cos(angle) * s
            t.vy = sin(angle) * s
            turnTimer = 0.8f + random.nextFloat() * 1.2f
        }
        move(t, dt)
        trackedSec += dt
        onTarget = pointerDown && dist(pointerX, pointerY, t.x, t.y) <= t.radius
        if (onTarget) {
            onTargetSec += dt
            score = (onTargetSec * 100f).toInt()
        }
    }

    fun onDown(x: Float, y: Float) {
        pointerDown = true
        pointerX = x
        pointerY = y
        if (finished || mode == AimMode.TRACKING) return

        var best: AimTarget? = null
        var bestD = Float.MAX_VALUE
        for (t in targets) {
            val d = dist(x, y, t.x, t.y)
            if (d <= t.radius && d < bestD) {
                best = t
                bestD = d
            }
        }
        if (best != null) {
            registerHit(best, bestD)
        } else {
            missShots++
            score = max(0, score - cfg.missPenalty)
            addMarker(x, y, false)
        }
    }

    fun onMove(x: Float, y: Float) {
        pointerX = x
        pointerY = y
    }

    fun onUp() {
        pointerDown = false
        onTarget = false
    }

    private fun registerHit(t: AimTarget, distance: Float) {
        hits++
        reactionSumMs += t.age * 1000f
        reactionCount++
        val gained: Int = if (mode == AimMode.PRECISION) {
            val closeness = 1f - min(1f, distance / t.radius)
            (cfg.hitScore * (0.5f + 0.5f * closeness)).toInt()
        } else {
            val speedBonus = 50f * (1f - min(t.age, 1.5f) / 1.5f)
            cfg.hitScore + speedBonus.toInt()
        }
        score += gained
        addMarker(t.x, t.y, true)
        targets.remove(t)
    }

    fun result(): AimResult {
        val avg = if (reactionCount > 0) (reactionSumMs / reactionCount).toInt() else 0
        return AimResult(
            hits = hits,
            misses = misses,
            missShots = missShots,
            expired = expired,
            accuracy = accuracyPercent,
            avgReactionMs = avg,
            score = score,
            onTargetSec = onTargetSec,
            trackedSec = trackedSec,
        )
    }
}
