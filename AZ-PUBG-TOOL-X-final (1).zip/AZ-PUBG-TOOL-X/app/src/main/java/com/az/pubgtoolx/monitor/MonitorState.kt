package com.az.pubgtoolx.monitor

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * MonitorService durumunun süreç içi paylaşımı (UI okur, servis yazar).
 * Servis ile UI aynı süreçte çalışır.
 */
object MonitorState {

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val _overlayVisible = MutableStateFlow(false)
    val overlayVisible: StateFlow<Boolean> = _overlayVisible.asStateFlow()

    private val _recording = MutableStateFlow(false)
    val recording: StateFlow<Boolean> = _recording.asStateFlow()

    private val _recordLabel = MutableStateFlow("")
    val recordLabel: StateFlow<String> = _recordLabel.asStateFlow()

    private val _currentFps = MutableStateFlow<Int?>(null)
    val currentFps: StateFlow<Int?> = _currentFps.asStateFlow()

    private val _gamePackage = MutableStateFlow<String?>(null)
    val gamePackage: StateFlow<String?> = _gamePackage.asStateFlow()

    /** "GAME" = gerçek oyun FPS'i, "DISPLAY" = yalnızca ekran yenileme hızı. */
    private val _source = MutableStateFlow("DISPLAY")
    val source: StateFlow<String> = _source.asStateFlow()

    private val _samples = MutableStateFlow(0)
    val samples: StateFlow<Int> = _samples.asStateFlow()

    private val _message = MutableStateFlow("")
    val message: StateFlow<String> = _message.asStateFlow()

    /** Kullanıcıya gösterilecek tek seferlik bildirim (kayıt sonucu, hata vb.). */
    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()

    fun setRunning(value: Boolean) {
        _running.value = value
        if (!value) {
            _overlayVisible.value = false
            _recording.value = false
            _recordLabel.value = ""
            _currentFps.value = null
            _gamePackage.value = null
            _source.value = "DISPLAY"
            _samples.value = 0
        }
    }

    fun setOverlayVisible(value: Boolean) {
        _overlayVisible.value = value
    }

    fun setRecording(value: Boolean, label: String) {
        _recording.value = value
        _recordLabel.value = if (value) label else ""
        if (!value) _samples.value = 0
    }

    fun setSample(fps: Int?, packageName: String?, source: String) {
        _currentFps.value = fps
        _gamePackage.value = packageName
        _source.value = source
    }

    fun setSamples(count: Int) {
        _samples.value = count
    }

    fun setMessage(text: String) {
        _message.value = text
    }

    fun postNotice(text: String) {
        _notice.value = text
    }

    fun clearNotice() {
        _notice.value = null
    }
}
