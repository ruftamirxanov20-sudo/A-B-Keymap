package com.az.pubgtoolx.core.system

import android.content.Context
import com.az.pubgtoolx.core.log.OperationLog
import com.az.pubgtoolx.core.shizuku.ShellResult
import com.az.pubgtoolx.core.shizuku.ShizukuShell

/** `wm size` / `wm density` çıktısından okunan gerçek ekran durumu. */
data class DisplayState(
    val physicalWidth: Int,
    val physicalHeight: Int,
    val overrideWidth: Int?,
    val overrideHeight: Int?,
    val physicalDensity: Int,
    val overrideDensity: Int?,
) {
    val currentWidth: Int get() = overrideWidth ?: physicalWidth
    val currentHeight: Int get() = overrideHeight ?: physicalHeight
    val currentDensity: Int get() = overrideDensity ?: physicalDensity
    val sizeOverridden: Boolean get() = overrideWidth != null
    val densityOverridden: Boolean get() = overrideDensity != null
}

/**
 * Çözünürlük ve DPI değişikliği (yalnızca Shizuku ile). Her değişiklik:
 *  1) uygulanır, 2) tekrar okunarak doğrulanır, 3) işlem kaydına yazılır.
 * Doğrulanamayan değişiklik asla başarılı gösterilmez.
 */
object DisplayControl {

    private const val MODULE = "Ekran"
    private val sizeRegex = Regex("(Physical|Override) size:\\s*(\\d+)x(\\d+)")
    private val densityRegex = Regex("(Physical|Override) density:\\s*(\\d+)")

    /** Shizuku hazır değilse veya çıktı okunamazsa null. */
    suspend fun read(context: Context): DisplayState? {
        val r = ShizukuShell.exec(context, "wm size; wm density")
        if (r.output.isBlank()) return null

        var pw = 0
        var ph = 0
        var ow: Int? = null
        var oh: Int? = null
        for (m in sizeRegex.findAll(r.output)) {
            val w = m.groupValues[2].toIntOrNull() ?: continue
            val h = m.groupValues[3].toIntOrNull() ?: continue
            if (m.groupValues[1] == "Physical") {
                pw = w
                ph = h
            } else {
                ow = w
                oh = h
            }
        }

        var pd = 0
        var od: Int? = null
        for (m in densityRegex.findAll(r.output)) {
            val d = m.groupValues[2].toIntOrNull() ?: continue
            if (m.groupValues[1] == "Physical") pd = d else od = d
        }

        if (pw == 0 || ph == 0 || pd == 0) return null
        return DisplayState(pw, ph, ow, oh, pd, od)
    }

    suspend fun applySize(context: Context, width: Int, height: Int): ShellResult {
        if (width !in 320..8000 || height !in 320..8000) {
            return log(context, "Çözünürlük uygula", ShellResult(false, "", "Geçersiz değer: ${width}x$height"))
        }
        val r = ShizukuShell.exec(context, "wm size ${width}x$height")
        val after = read(context)
        val verified = r.ok && after != null && after.currentWidth == width && after.currentHeight == height
        val result = if (verified) {
            ShellResult(true, "Çözünürlük ${width}x$height olarak ayarlandı")
        } else {
            ShellResult(false, r.output, r.error ?: "Değişiklik doğrulanamadı")
        }
        return log(context, "Çözünürlük ${width}x$height", result)
    }

    suspend fun resetSize(context: Context): ShellResult {
        val r = ShizukuShell.exec(context, "wm size reset")
        val after = read(context)
        val verified = r.ok && after != null && !after.sizeOverridden
        val result = if (verified) {
            ShellResult(true, "Çözünürlük varsayılana döndü")
        } else {
            ShellResult(false, r.output, r.error ?: "Sıfırlama doğrulanamadı")
        }
        return log(context, "Çözünürlük sıfırla", result)
    }

    suspend fun applyDensity(context: Context, dpi: Int): ShellResult {
        if (dpi !in 120..960) {
            return log(context, "DPI uygula", ShellResult(false, "", "Geçersiz DPI: $dpi (120–960)"))
        }
        val r = ShizukuShell.exec(context, "wm density $dpi")
        val after = read(context)
        val verified = r.ok && after != null && after.currentDensity == dpi
        val result = if (verified) {
            ShellResult(true, "DPI $dpi olarak ayarlandı")
        } else {
            ShellResult(false, r.output, r.error ?: "Değişiklik doğrulanamadı")
        }
        return log(context, "DPI $dpi", result)
    }

    suspend fun resetDensity(context: Context): ShellResult {
        val r = ShizukuShell.exec(context, "wm density reset")
        val after = read(context)
        val verified = r.ok && after != null && !after.densityOverridden
        val result = if (verified) {
            ShellResult(true, "DPI varsayılana döndü")
        } else {
            ShellResult(false, r.output, r.error ?: "Sıfırlama doğrulanamadı")
        }
        return log(context, "DPI sıfırla", result)
    }

    private suspend fun log(context: Context, action: String, result: ShellResult): ShellResult {
        val detail = if (result.ok) result.output else (result.error ?: result.output)
        OperationLog.add(context, MODULE, action, result.ok, detail)
        return result
    }
}
