package com.az.pubgtoolx.ui.screens.sensitivity

import com.az.pubgtoolx.core.data.AppStore
import org.json.JSONObject
import kotlin.math.roundToInt

data class SensField(val key: String, val label: String)

/** Hassasiyet alanları: genel, jiroskop ve dürbün bazlı değerler (hepsi 0–300). */
object SensSpec {
    const val MAX = 300
    const val DEFAULT = 100

    val scopes: List<Pair<String, String>> = listOf(
        "reddot" to "Red Dot / Holo",
        "x2" to "2x",
        "x3" to "3x",
        "x4" to "4x",
        "x6" to "6x",
        "x8" to "8x",
    )

    fun scopeCamKey(id: String): String = "scopeCam_$id"
    fun scopeGyroKey(id: String): String = "scopeGyro_$id"

    val fields: List<SensField> = run {
        val list = ArrayList<SensField>()
        list.add(SensField("camera", "Kamera hassasiyeti"))
        list.add(SensField("ads", "ADS hassasiyeti"))
        list.add(SensField("gyroCamera", "Jiroskop (kamera)"))
        list.add(SensField("gyroAds", "Jiroskop (ADS)"))
        for (s in scopes) {
            list.add(SensField(scopeCamKey(s.first), "${s.second} — Kamera/ADS"))
            list.add(SensField(scopeGyroKey(s.first), "${s.second} — Jiroskop ADS"))
        }
        list
    }

    val keys: List<String> = fields.map { it.key }
}

class ImportResult(val profile: JSONObject?, val error: String?)

object SensJson {

    fun build(id: String, name: String, values: Map<String, Float>): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("name", name)
        o.put("updated", System.currentTimeMillis())
        o.put("type", "azx_sens")
        for (k in SensSpec.keys) {
            val v = (values[k] ?: SensSpec.DEFAULT.toFloat()).roundToInt().coerceIn(0, SensSpec.MAX)
            o.put(k, v)
        }
        return o
    }

    /** Profili düzenleyici değerlerine çevirir. */
    fun valuesOf(o: JSONObject): Map<String, Float> {
        val map = LinkedHashMap<String, Float>()
        for (k in SensSpec.keys) {
            map[k] = o.optInt(k, SensSpec.DEFAULT).coerceIn(0, SensSpec.MAX).toFloat()
        }
        return map
    }

    /** Dışa aktarılan JSON metnini doğrular. Hatalıysa açık bir Türkçe hata döner. */
    fun parseImport(text: String): ImportResult {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return ImportResult(null, "Metin boş.")

        val src: JSONObject = try {
            JSONObject(trimmed)
        } catch (e: Exception) {
            return ImportResult(null, "Geçerli bir JSON değil: ${e.message}")
        }

        var known = 0
        for (k in SensSpec.keys) {
            if (src.has(k)) {
                val v = src.opt(k)
                if (v !is Number) {
                    return ImportResult(null, "\"$k\" alanı sayı olmalı.")
                }
                val d = v.toDouble()
                if (d.isNaN() || d < 0.0 || d > SensSpec.MAX.toDouble()) {
                    return ImportResult(null, "\"$k\" değeri 0–${SensSpec.MAX} aralığında olmalı (gelen: $d).")
                }
                known++
            }
        }
        if (known == 0) {
            return ImportResult(null, "Tanınan hassasiyet alanı bulunamadı (camera, ads, gyroCamera ...).")
        }

        val name = src.optString("name").trim().ifBlank { "İçe aktarılan profil" }.take(40)
        val values = LinkedHashMap<String, Float>()
        for (k in SensSpec.keys) {
            values[k] = if (src.has(k)) src.optDouble(k, SensSpec.DEFAULT.toDouble()).toFloat() else SensSpec.DEFAULT.toFloat()
        }
        return ImportResult(build(AppStore.newId(), name, values), null)
    }
}
