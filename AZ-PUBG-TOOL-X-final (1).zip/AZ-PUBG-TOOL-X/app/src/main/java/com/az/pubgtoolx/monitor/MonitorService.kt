package com.az.pubgtoolx.monitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.data.StoreKeys
import com.az.pubgtoolx.core.device.LiveStatsReader
import com.az.pubgtoolx.core.game.GamePackages
import com.az.pubgtoolx.core.log.OperationLog
import com.az.pubgtoolx.core.shizuku.ShizukuShell
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Yalnızca kullanıcı başlatınca çalışan foreground servis:
 *  - isteğe bağlı kayan panel (overlay),
 *  - oyun FPS kaydı (yalnızca Shizuku ile okunabilen gerçek örnekler).
 * Overlay ve kayıt kapalıysa servis kendini durdurur.
 */
class MonitorService : Service() {

    companion object {
        const val ACTION_START_OVERLAY = "com.az.pubgtoolx.action.START_OVERLAY"
        const val ACTION_STOP_OVERLAY = "com.az.pubgtoolx.action.STOP_OVERLAY"
        const val ACTION_START_RECORD = "com.az.pubgtoolx.action.START_RECORD"
        const val ACTION_STOP_RECORD = "com.az.pubgtoolx.action.STOP_RECORD"
        const val ACTION_STOP_ALL = "com.az.pubgtoolx.action.STOP_ALL"
        const val EXTRA_LABEL = "label"

        private const val CHANNEL_ID = "az_monitor"
        private const val NOTIFICATION_ID = 4201

        // Kayıt sonuçları servis kapanınca da kaydedilebilsin diye servisten bağımsız kapsam.
        private val saveScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        fun send(context: Context, action: String, label: String? = null) {
            val intent = Intent(context, MonitorService::class.java).setAction(action)
            if (label != null) intent.putExtra(EXTRA_LABEL, label)
            val isStart = action == ACTION_START_OVERLAY || action == ACTION_START_RECORD
            if (isStart) {
                ContextCompat.startForegroundService(context, intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var loopJob: Job? = null
    private var prefsJob: Job? = null

    private var foregroundStarted = false
    private var overlayWanted = false
    private var recording = false
    private var recordLabel = ""
    private var recordStart = 0L
    private var recordPackage: String? = null
    private val samples = ArrayList<Int>()

    private var overlayRoot: LinearLayout? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var fpsView: TextView? = null
    private var infoView: TextView? = null
    private var currentPrefs = OverlayPrefs()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        val isStop = action == ACTION_STOP_OVERLAY || action == ACTION_STOP_RECORD || action == ACTION_STOP_ALL
        if (isStop && !foregroundStarted) {
            stopSelf()
            return START_NOT_STICKY
        }
        ensureForeground()

        when (action) {
            ACTION_START_OVERLAY -> {
                overlayWanted = true
                showOverlay()
            }
            ACTION_STOP_OVERLAY -> {
                overlayWanted = false
                hideOverlay()
            }
            ACTION_START_RECORD -> startRecording(intent?.getStringExtra(EXTRA_LABEL) ?: "Kayıt")
            ACTION_STOP_RECORD -> stopRecording()
            ACTION_STOP_ALL -> {
                stopRecording()
                overlayWanted = false
                hideOverlay()
            }
            else -> {
                // Bilinmeyen/boş intent: hiçbir şey başlatma.
            }
        }

        if (!overlayWanted && !recording) {
            finishIfIdle()
        } else {
            updateNotification()
            startLoopIfNeeded()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        loopJob?.cancel()
        prefsJob?.cancel()
        hideOverlay()
        MonitorState.setRunning(false)
        scope.cancel()
        super.onDestroy()
    }

    // ---------------- Foreground / bildirim ----------------

    private fun ensureForeground() {
        if (foregroundStarted) return
        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        foregroundStarted = true
        MonitorState.setRunning(true)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(CHANNEL_ID, "İzleme ve overlay", NotificationManager.IMPORTANCE_LOW)
        nm.createNotificationChannel(channel)
    }

    private fun servicePendingIntent(requestCode: Int, action: String): PendingIntent {
        val intent = Intent(this, MonitorService::class.java).setAction(action)
        return PendingIntent.getService(this, requestCode, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun buildNotification(): Notification {
        val text = when {
            recording && overlayWanted -> "Overlay açık • Kayıt: $recordLabel"
            recording -> "FPS kaydı: $recordLabel (${samples.size} örnek)"
            overlayWanted -> "Overlay açık"
            else -> "Hazırlanıyor"
        }
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("AZ PUBG TOOL X")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Durdur", servicePendingIntent(1, ACTION_STOP_ALL))
        if (recording) {
            builder.addAction(0, "Kaydı durdur", servicePendingIntent(2, ACTION_STOP_RECORD))
        }
        return builder.build()
    }

    private fun updateNotification() {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, buildNotification())
        } catch (e: Exception) {
            // Bildirim güncellenemese de servis çalışmaya devam eder.
        }
    }

    private fun finishIfIdle() {
        if (overlayWanted || recording) return
        loopJob?.cancel()
        prefsJob?.cancel()
        hideOverlay()
        MonitorState.setRunning(false)
        if (foregroundStarted) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            foregroundStarted = false
        }
        stopSelf()
    }

    // ---------------- Örnekleme döngüsü ----------------

    private fun displayHz(): Int {
        return try {
            val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
            val d: Display? = dm.getDisplay(Display.DEFAULT_DISPLAY)
            d?.refreshRate?.roundToInt() ?: 0
        } catch (e: Exception) {
            0
        }
    }

    private fun startLoopIfNeeded() {
        if (loopJob?.isActive == true) return
        loopJob = scope.launch {
            val sampler = GameFpsSampler(applicationContext)
            while (isActive && (overlayWanted || recording)) {
                var fps: Int? = null
                var pkg: String? = null
                var source = "DISPLAY"
                var message: String

                if (ShizukuShell.isReady()) {
                    val s = sampler.sample()
                    message = s.message
                    if (s.fps != null) {
                        fps = s.fps
                        pkg = s.packageName
                        source = "GAME"
                    }
                } else {
                    message = "Shizuku hazır değil: yalnızca ekran yenileme hızı gösterilir"
                }
                if (fps == null) {
                    val hz = displayHz()
                    fps = if (hz > 0) hz else null
                    source = "DISPLAY"
                }

                MonitorState.setSample(fps, pkg, source)
                MonitorState.setMessage(message)

                if (recording && source == "GAME" && fps != null) {
                    samples.add(fps)
                    if (pkg != null) recordPackage = pkg
                    MonitorState.setSamples(samples.size)
                }
                updateOverlayTexts(fps, source)
                if (recording && samples.size % 10 == 1) updateNotification()
                delay(1000L)
            }
        }
    }

    // ---------------- Kayıt ----------------

    private fun startRecording(label: String) {
        if (recording) return
        recording = true
        recordLabel = if (label.isBlank()) "Kayıt" else label.take(40)
        recordStart = System.currentTimeMillis()
        recordPackage = null
        samples.clear()
        MonitorState.setRecording(true, recordLabel)
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        val list = ArrayList<Int>(samples)
        val label = recordLabel
        val pkg = recordPackage
        val durationSec = ((System.currentTimeMillis() - recordStart) / 1000L).toInt()
        samples.clear()
        MonitorState.setRecording(false, "")
        val appContext = applicationContext
        saveScope.launch {
            if (list.isEmpty()) {
                val msg = "Kayıt kaydedilmedi: oyun FPS'i hiç okunamadı (Shizuku hazır ve oyun ön planda olmalı; cihaz desteklemiyor olabilir)."
                OperationLog.add(appContext, "FPS Lab", "FPS kaydı: $label", false, msg)
                MonitorState.postNotice(msg)
            } else {
                val sorted = list.sorted()
                val worstCount = max(1, sorted.size / 100)
                var worstSum = 0L
                for (i in 0 until worstCount) worstSum += sorted[i]
                val avg = list.sum().toDouble() / list.size
                val obj = JSONObject()
                    .put("id", AppStore.newId())
                    .put("name", label)
                    .put("updated", System.currentTimeMillis())
                    .put("avg", avg)
                    .put("min", sorted.first())
                    .put("max", sorted.last())
                    .put("low1", worstSum.toDouble() / worstCount)
                    .put("samples", list.size)
                    .put("durationSec", durationSec)
                    .put("package", pkg ?: "")
                AppStore.upsert(appContext, StoreKeys.FPS_RECORDS, obj, 100)
                val msg = "Kayıt kaydedildi: $label • ort. ${avg.roundToInt()} FPS • ${list.size} örnek"
                OperationLog.add(appContext, "FPS Lab", "FPS kaydı: $label", true, msg)
                MonitorState.postNotice(msg)
            }
        }
    }

    // ---------------- Overlay ----------------

    private fun px(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()

    private fun showOverlay() {
        if (overlayRoot != null) return
        if (!Settings.canDrawOverlays(this)) {
            MonitorState.postNotice("Overlay açılamadı: 'Diğer uygulamaların üzerinde göster' izni verilmemiş.")
            overlayWanted = false
            return
        }
        scope.launch {
            currentPrefs = OverlayPrefsStore.load(applicationContext)
            if (overlayWanted && overlayRoot == null) buildOverlay(currentPrefs)
        }
        if (prefsJob?.isActive != true) {
            prefsJob = scope.launch {
                OverlayPrefsStore.flow(applicationContext).collect { p ->
                    val old = currentPrefs
                    currentPrefs = p
                    if (overlayRoot != null && overlayWanted) {
                        if (!old.sameContent(p)) {
                            hideOverlay()
                            buildOverlay(p)
                        } else if (p.posX < 0 || p.posY < 0) {
                            resetOverlayPosition()
                        }
                    }
                }
            }
        }
    }

    private fun resetOverlayPosition() {
        val lp = overlayParams ?: return
        val root = overlayRoot ?: return
        lp.x = px(16)
        lp.y = px(80)
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).updateViewLayout(root, lp)
        } catch (e: Exception) {
            // görünüm kaldırılmış olabilir
        }
    }

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 12f
        tv.setPadding(px(8), px(4), px(8), px(4))
        val bg = GradientDrawable()
        bg.setColor(Color.rgb(22, 139, 255))
        bg.cornerRadius = px(8).toFloat()
        tv.background = bg
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun launchPackage(pkg: String?) {
        if (pkg == null) return
        try {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        } catch (e: Exception) {
            MonitorState.postNotice("Uygulama açılamadı")
        }
    }

    private fun buildOverlay(prefs: OverlayPrefs) {
        if (overlayRoot != null) return
        if (!Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(10), px(6), px(10), px(6))
        val bg = GradientDrawable()
        bg.setColor(Color.argb(204, 16, 27, 45))
        bg.cornerRadius = px(14).toFloat()
        bg.setStroke(px(1), Color.rgb(22, 139, 255))
        root.background = bg

        val fps = TextView(this)
        fps.setTextColor(Color.WHITE)
        fps.textSize = 16f
        fps.typeface = Typeface.DEFAULT_BOLD
        fps.text = "—"
        fps.visibility = if (prefs.showFps) View.VISIBLE else View.GONE
        root.addView(fps)

        val info = TextView(this)
        info.setTextColor(Color.rgb(143, 163, 191))
        info.textSize = 11f
        root.addView(info)

        if (prefs.showShortcuts) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(0, px(4), 0, 0)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = px(6)
            row.addView(chip("Uygulama") { launchPackage(packageName) }, lp)
            val game = GamePackages.installed(this).firstOrNull()
            if (game != null) {
                row.addView(chip("PUBG") { launchPackage(game.packageName) }, lp)
            }
            row.addView(chip("Kapat") {
                overlayWanted = false
                hideOverlay()
                finishIfIdle()
            }, lp)
            root.addView(row)
        }

        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = if (prefs.posX >= 0) prefs.posX else px(16)
        lp.y = if (prefs.posY >= 0) prefs.posY else px(80)

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - touchX).toInt()
                    lp.y = startY + (event.rawY - touchY).toInt()
                    try {
                        wm.updateViewLayout(root, lp)
                    } catch (e: Exception) {
                        // görünüm kaldırılmış olabilir
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val x = lp.x
                    val y = lp.y
                    saveScope.launch {
                        OverlayPrefsStore.save(applicationContext, currentPrefs.copy(posX = x, posY = y))
                    }
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            MonitorState.postNotice("Overlay eklenemedi: ${e.message}")
            overlayWanted = false
            return
        }
        overlayRoot = root
        overlayParams = lp
        fpsView = fps
        infoView = info
        MonitorState.setOverlayVisible(true)
        updateOverlayTexts(MonitorState.currentFps.value, MonitorState.source.value)
    }

    private fun hideOverlay() {
        val root = overlayRoot
        if (root != null) {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(root)
            } catch (e: Exception) {
                // zaten kaldırılmış
            }
        }
        overlayRoot = null
        overlayParams = null
        fpsView = null
        infoView = null
        MonitorState.setOverlayVisible(false)
    }

    private fun updateOverlayTexts(fps: Int?, source: String) {
        val fv = fpsView ?: return
        val iv = infoView ?: return
        fv.text = when {
            fps == null -> "—"
            source == "GAME" -> "$fps FPS"
            else -> "$fps Hz (ekran)"
        }
        val parts = ArrayList<String>()
        if (currentPrefs.showClock) {
            parts.add(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
        }
        if (currentPrefs.showBattery || currentPrefs.showRam) {
            val stats = LiveStatsReader.read(this)
            if (currentPrefs.showBattery) {
                val p = stats.batteryPercent
                val t = stats.batteryTempC
                val battery = if (p != null) "Pil %$p" else "Pil —"
                parts.add(if (t != null) "$battery ${"%.0f".format(t)}°C" else battery)
            }
            if (currentPrefs.showRam) {
                parts.add("RAM %.1f GB boş".format(stats.availRamMb / 1024f))
            }
        }
        iv.text = parts.joinToString("  •  ")
        iv.visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE
    }
}
