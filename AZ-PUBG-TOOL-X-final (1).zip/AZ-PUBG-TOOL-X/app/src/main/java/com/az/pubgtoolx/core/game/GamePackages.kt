package com.az.pubgtoolx.core.game

import android.content.Context

data class GamePackage(val packageName: String, val label: String)

/** Bilinen PUBG Mobile paketleri (manifest <queries> bölümünde de tanımlı). */
object GamePackages {

    val ALL: List<GamePackage> = listOf(
        GamePackage("com.tencent.ig", "PUBG MOBILE (Global)"),
        GamePackage("com.pubg.krmobile", "PUBG MOBILE (KR)"),
        GamePackage("com.vng.pubgmobile", "PUBG MOBILE (VN)"),
        GamePackage("com.rekoo.pubgm", "PUBG MOBILE (TW)"),
        GamePackage("com.pubg.imobile", "Battlegrounds Mobile India"),
        GamePackage("com.tencent.tmgp.pubgmhd", "Game for Peace"),
    )

    fun isInstalled(context: Context, packageName: String): Boolean {
        return try {
            context.packageManager.getLaunchIntentForPackage(packageName) != null
        } catch (e: Exception) {
            false
        }
    }

    fun installed(context: Context): List<GamePackage> = ALL.filter { isInstalled(context, it.packageName) }

    /** Active.sav dosyasının bilinen konumu (varlığı çalışma anında doğrulanmalı). */
    fun activeSavPath(packageName: String): String =
        "/storage/emulated/0/Android/data/$packageName/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Active.sav"
}
