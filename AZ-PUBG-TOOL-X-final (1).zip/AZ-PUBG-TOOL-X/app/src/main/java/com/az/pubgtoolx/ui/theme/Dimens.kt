package com.az.pubgtoolx.ui.theme

import androidx.compose.ui.unit.dp

/** Uygulama genelinde ortak ölçüler. Değerleri tek yerden değiştirmek için. */
object Dimens {
    val ScreenPadding = 16.dp
    val CardRadius = 18.dp
    val CardPadding = 14.dp
    val ButtonRadius = 14.dp
    val ChipRadius = 20.dp
    val ItemSpacing = 10.dp
    val SectionSpacing = 14.dp
}
