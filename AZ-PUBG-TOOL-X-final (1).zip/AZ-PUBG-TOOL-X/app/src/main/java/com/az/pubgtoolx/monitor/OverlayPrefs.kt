package com.az.pubgtoolx.monitor

import android.content.Context
import com.az.pubgtoolx.core.data.AppStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import org.json.JSONObject

/** Overlay'de gösterilecek öğeler ve konum (posX/posY = -1 → varsayılan konum). */
data class OverlayPrefs(
    val showFps: Boolean = true,
    val showClock: Boolean = true,
    val showBattery: Boolean = true,
    val showRam: Boolean = true,
    val showShortcuts: Boolean = true,
    val posX: Int = -1,
    val posY: Int = -1,
) {
    /** Konum hariç görünen içerik aynı mı? */
    fun sameContent(other: OverlayPrefs): Boolean {
        return showFps == other.showFps &&
            showClock == other.showClock &&
            showBattery == other.showBattery &&
            showRam == other.showRam &&
            showShortcuts == other.showShortcuts
    }
}

object OverlayPrefsStore {

    private const val KEY = "overlay_prefs"

    fun parse(raw: String?): OverlayPrefs {
        if (raw.isNullOrBlank()) return OverlayPrefs()
        return try {
            val o = JSONObject(raw)
            OverlayPrefs(
                showFps = o.optBoolean("showFps", true),
                showClock = o.optBoolean("showClock", true),
                showBattery = o.optBoolean("showBattery", true),
                showRam = o.optBoolean("showRam", true),
                showShortcuts = o.optBoolean("showShortcuts", true),
                posX = o.optInt("posX", -1),
                posY = o.optInt("posY", -1),
            )
        } catch (e: Exception) {
            OverlayPrefs()
        }
    }

    fun flow(context: Context): Flow<OverlayPrefs> =
        AppStore.stringFlow(context, KEY).map { parse(it) }.distinctUntilChanged()

    suspend fun load(context: Context): OverlayPrefs = parse(AppStore.getString(context, KEY))

    suspend fun save(context: Context, prefs: OverlayPrefs) {
        val o = JSONObject()
            .put("showFps", prefs.showFps)
            .put("showClock", prefs.showClock)
            .put("showBattery", prefs.showBattery)
            .put("showRam", prefs.showRam)
            .put("showShortcuts", prefs.showShortcuts)
            .put("posX", prefs.posX)
            .put("posY", prefs.posY)
        AppStore.putString(context, KEY, o.toString())
    }
}
