package com.az.pubgtoolx.ui.screens.sensitivity

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.az.pubgtoolx.ui.theme.CyberOutline
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberText
import com.az.pubgtoolx.ui.theme.CyberTextMuted

/** Cyber temalı metin alanı (profil adı, içe aktarma metni). HUD ekranı da kullanır. */
@Composable
fun ProfileTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    minLines: Int = 1,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = singleLine,
        minLines = minLines,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = CyberText,
            unfocusedTextColor = CyberText,
            focusedBorderColor = CyberPrimary,
            unfocusedBorderColor = CyberOutline,
            focusedLabelColor = CyberPrimary,
            unfocusedLabelColor = CyberTextMuted,
            cursorColor = CyberPrimary,
        ),
    )
}
