package com.az.pubgtoolx.core.shizuku

import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

/**
 * Shizuku tarafından shell kimliğiyle ayrı bir süreçte başlatılır.
 * Burada Android/Compose sınıfı kullanılmaz; yalnızca saf Java/Kotlin.
 */
class ShellUserService : IUserService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String?): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command ?: "")
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().use { it.readText() }
            val finished = process.waitFor(20, TimeUnit.SECONDS)
            val code = if (finished) {
                process.exitValue()
            } else {
                process.destroyForcibly()
                -1
            }
            "$code\n$output"
        } catch (t: Throwable) {
            "-1\n${t.message}"
        }
    }

    override fun readFile(path: String?, maxBytes: Int): ByteArray? {
        return try {
            if (path == null) return null
            val file = File(path)
            if (!file.isFile) return null
            if (file.length() > maxBytes) return null
            file.readBytes()
        } catch (t: Throwable) {
            null
        }
    }

    override fun writeFile(path: String?, data: ByteArray?): String {
        return try {
            if (path == null || data == null) return "Geçersiz argüman"
            val file = File(path)
            file.writeBytes(data)
            "OK"
        } catch (t: Throwable) {
            t.message ?: "Yazma hatası"
        }
    }
}
