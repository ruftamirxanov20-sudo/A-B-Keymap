package com.az.pubgtoolx.ui.screens.profiles

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.data.StoreKeys
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.navigation.ToolModule
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.Dimens

private class StoreSpec(val title: String, val key: String, val module: ToolModule, val emptyText: String)

private val SPECS = listOf(
    StoreSpec("Hassasiyet profilleri", StoreKeys.SENS_PROFILES, ToolModule.SENSITIVITY, "Henüz hassasiyet profili yok."),
    StoreSpec("HUD profilleri", StoreKeys.HUD_PROFILES, ToolModule.HUD, "Henüz HUD profili yok."),
    StoreSpec("DPI profilleri", StoreKeys.DPI_PROFILES, ToolModule.DPI, "Henüz DPI profili yok."),
    StoreSpec("Çözünürlük profilleri", StoreKeys.RES_PROFILES, ToolModule.RESOLUTION, "Henüz çözünürlük profili yok."),
    StoreSpec("Silah notlarım", StoreKeys.WEAPON_PROFILES, ToolModule.WEAPONS, "Henüz silah notu yok."),
    StoreSpec("FPS kayıtları", StoreKeys.FPS_RECORDS, ToolModule.FPS_LAB, "Henüz FPS kaydı yok."),
)

@Composable
fun ProfilesScreen(onOpenModule: (ToolModule) -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "Profiles", subtitle = "Kayıtlı profiller ve kayıtlar")
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            Text(
                "Tüm profiller yalnızca bu cihazda saklanır. Düzenlemek veya silmek için ilgili modülü açın.",
                fontSize = 12.sp,
                color = CyberTextMuted,
            )
            SPECS.forEach { spec -> ProfileGroup(spec, onOpenModule) }
            Spacer(Modifier.height(Dimens.SectionSpacing))
        }
    }
}

@Composable
private fun ProfileGroup(spec: StoreSpec, onOpenModule: (ToolModule) -> Unit) {
    val context = LocalContext.current
    val flow = remember(spec.key) { AppStore.arrayFlow(context, spec.key) }
    val items by flow.collectAsStateWithLifecycle(initialValue = emptyList())
    val latest = items.sortedByDescending { it.optLong("updated") }.take(4)

    CyberCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(spec.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text("${items.size} kayıt", fontSize = 12.sp, color = CyberPrimary)
        }
        Spacer(Modifier.height(6.dp))
        if (latest.isEmpty()) {
            Text(spec.emptyText, fontSize = 12.sp, color = CyberTextMuted)
        } else {
            latest.forEach { o ->
                val name = o.optString("name").ifBlank { "Adsız" }
                Text("• $name", fontSize = 13.sp, maxLines = 1)
            }
            if (items.size > latest.size) {
                Text("… ve ${items.size - latest.size} kayıt daha", fontSize = 11.sp, color = CyberTextMuted)
            }
        }
        Spacer(Modifier.height(8.dp))
        CyberButton(text = "${spec.module.shortTitle} modülünü aç", onClick = { onOpenModule(spec.module) }, secondary = true)
    }
}
