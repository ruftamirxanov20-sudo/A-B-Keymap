package com.az.pubgtoolx.ui.screens.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.data.StoreKeys
import com.az.pubgtoolx.core.log.OperationLog
import com.az.pubgtoolx.core.util.Format
import com.az.pubgtoolx.core.util.copyToClipboard
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.ui.components.ConfirmDialog
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberChipRow
import com.az.pubgtoolx.ui.components.CyberSlider
import com.az.pubgtoolx.ui.components.CyberSwitchRow
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.screens.resolution.AzTextField
import com.az.pubgtoolx.ui.theme.CyberOutline
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSecondary
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.roundToInt

private const val BASE_BUTTON_DP = 44

@Composable
fun HudDesignerScreen(onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var fingers by remember { mutableStateOf(3) }
    var globalSize by remember { mutableStateOf(1f) }
    var opacity by remember { mutableStateOf(0.8f) }
    val buttons = remember { mutableStateListOf<HudButton>().apply { addAll(HudPresets.preset(3)) } }
    var selectedKey by remember { mutableStateOf<String?>(null) }
    var profileName by remember { mutableStateOf("") }
    var currentId by remember { mutableStateOf<String?>(null) }
    var confirmPreset by remember { mutableStateOf<Int?>(null) }
    var deleteTarget by remember { mutableStateOf<JSONObject?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    val profilesFlow = remember { AppStore.arrayFlow(context, StoreKeys.HUD_PROFILES) }
    val profiles by profilesFlow.collectAsStateWithLifecycle(initialValue = emptyList())

    fun applyPreset(count: Int) {
        fingers = count
        buttons.clear()
        buttons.addAll(HudPresets.preset(count))
        globalSize = 1f
        opacity = 0.8f
        selectedKey = null
        currentId = null
    }

    fun currentProfile() = HudProfile(fingers, globalSize, opacity, buttons.toList())

    fun moveButton(key: String, dx: Float, dy: Float) {
        val i = buttons.indexOfFirst { it.key == key }
        if (i < 0) return
        val b = buttons[i]
        buttons[i] = b.copy(
            x = (b.x + dx).coerceIn(0.04f, 0.96f),
            y = (b.y + dy).coerceIn(0.06f, 0.94f),
        )
    }

    fun updateSelected(transform: (HudButton) -> HudButton) {
        val key = selectedKey ?: return
        val i = buttons.indexOfFirst { it.key == key }
        if (i >= 0) buttons[i] = transform(buttons[i])
    }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "HUD Designer", subtitle = "Düzen planlama taslağı", onBack = onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Bu araç oyunun HUD ayarını değiştirmez ve oyun dosyalarına dokunmaz. Burada planladığınız düzeni, oyunun \"Ayarlar › Kontrol › Düzeni Özelleştir\" ekranına elle uygulamanız gerekir. Koordinatlar yaklaşık yüzdelerdir.",
                    fontSize = 12.sp,
                    color = CyberWarning,
                )
            }

            SectionTitle("Parmak profili")
            CyberChipRow(
                options = HudPresets.FINGER_OPTIONS.map { "$it parmak" },
                selectedIndex = HudPresets.FINGER_OPTIONS.indexOf(fingers).coerceAtLeast(0),
                onSelect = { idx ->
                    val count = HudPresets.FINGER_OPTIONS[idx]
                    if (count != fingers) confirmPreset = count
                },
            )
            Text(HudPresets.describe(fingers), fontSize = 12.sp, color = CyberTextMuted)

            // --- 20:9 önizleme ---
            CyberCard(modifier = Modifier.fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp)) {
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(20f / 9f)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                        .background(Color(0xFF0A1220))
                        .border(1.dp, CyberOutline, androidx.compose.foundation.shape.RoundedCornerShape(12.dp)),
                ) {
                    val density = LocalDensity.current
                    val wPx = with(density) { maxWidth.toPx() }
                    val hPx = with(density) { maxHeight.toPx() }

                    // Sabit hareket joystick'i (taşınamaz, yalnızca referans)
                    val joyPx = with(density) { 84.dp.toPx() }
                    Box(
                        modifier = Modifier
                            .offset { IntOffset((0.14f * wPx - joyPx / 2).roundToInt(), (0.74f * hPx - joyPx / 2).roundToInt()) }
                            .size(84.dp)
                            .clip(CircleShape)
                            .border(1.dp, CyberTextMuted.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("HAREKET", fontSize = 8.sp, color = CyberTextMuted)
                    }

                    buttons.forEach { btn ->
                        if (btn.visible) {
                            val sizeDp = BASE_BUTTON_DP * btn.size * globalSize
                            val sizePx = with(density) { sizeDp.dp.toPx() }
                            val selected = btn.key == selectedKey
                            Box(
                                modifier = Modifier
                                    .offset {
                                        IntOffset(
                                            (btn.x * wPx - sizePx / 2).roundToInt(),
                                            (btn.y * hPx - sizePx / 2).roundToInt(),
                                        )
                                    }
                                    .size(sizeDp.dp)
                                    .clip(CircleShape)
                                    .background(CyberPrimary.copy(alpha = opacity * 0.6f))
                                    .border(
                                        if (selected) 2.dp else 1.dp,
                                        if (selected) CyberSecondary else CyberPrimary,
                                        CircleShape,
                                    )
                                    .clickable { selectedKey = btn.key }
                                    .pointerInput(btn.key) {
                                        detectDragGestures(
                                            onDragStart = { selectedKey = btn.key },
                                        ) { change, drag ->
                                            change.consume()
                                            moveButton(btn.key, drag.x / wPx, drag.y / hPx)
                                        }
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    btn.label,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Düğmeyi sürükleyerek taşıyın; seçmek için dokunun.",
                    fontSize = 11.sp,
                    color = CyberTextMuted,
                )
            }

            // --- Genel ayarlar ---
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Genel")
                Spacer(Modifier.height(4.dp))
                CyberSlider(
                    label = "Düğme boyutu",
                    value = globalSize,
                    onValueChange = { globalSize = it },
                    valueRange = 0.6f..1.6f,
                    valueText = "x%.2f".format(globalSize),
                )
                CyberSlider(
                    label = "Saydamlık",
                    value = opacity,
                    onValueChange = { opacity = it },
                    valueRange = 0.3f..1f,
                    valueText = "%" + (opacity * 100).roundToInt(),
                )
            }

            // --- Seçili düğme ---
            val sel = buttons.firstOrNull { it.key == selectedKey }
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle(if (sel != null) "Seçili: ${sel.label}" else "Düğme seçilmedi")
                Spacer(Modifier.height(4.dp))
                if (sel == null) {
                    Text("Ayarlamak için önizlemede bir düğmeye dokunun veya aşağıdan seçin.", fontSize = 12.sp, color = CyberTextMuted)
                } else {
                    CyberSlider(
                        label = "Bu düğmenin boyutu",
                        value = sel.size,
                        onValueChange = { v -> updateSelected { it.copy(size = v) } },
                        valueRange = 0.5f..2f,
                        valueText = "x%.2f".format(sel.size),
                    )
                    CyberSwitchRow(
                        title = "Görünür",
                        checked = sel.visible,
                        onCheckedChange = { v -> updateSelected { it.copy(visible = v) } },
                        subtitle = "Kapalıysa planda gizli olarak işaretlenir",
                    )
                }
                Spacer(Modifier.height(6.dp))
                CyberChipRow(
                    options = buttons.map { it.label },
                    selectedIndex = buttons.indexOfFirst { it.key == selectedKey },
                    onSelect = { selectedKey = buttons[it].key },
                )
            }

            // --- Profil kaydet ---
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Profil kaydet")
                Spacer(Modifier.height(6.dp))
                AzTextField(
                    value = profileName,
                    onValueChange = { profileName = it },
                    label = "Profil adı",
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CyberButton(
                        text = "Kaydet",
                        onClick = {
                            val name = profileName.trim()
                            if (name.isEmpty()) {
                                message = "Önce bir profil adı yazın."
                            } else {
                                val id = currentId ?: AppStore.newId()
                                val json = HudCodec.toJson(id, name, currentProfile())
                                scope.launch {
                                    try {
                                        AppStore.upsert(context, StoreKeys.HUD_PROFILES, json)
                                        currentId = id
                                        message = "\"$name\" kaydedildi."
                                        OperationLog.add(context, "HUD", "Profil kaydı: $name", true, "${fingers} parmak")
                                    } catch (e: Exception) {
                                        message = "Kaydedilemedi: ${e.message}"
                                        OperationLog.add(context, "HUD", "Profil kaydı: $name", false, e.message ?: "Hata")
                                    }
                                }
                            }
                        },
                    )
                    CyberButton(
                        text = "Planı kopyala",
                        secondary = true,
                        onClick = {
                            val name = profileName.trim().ifEmpty { "Adsız plan" }
                            copyToClipboard(context, "HUD planı", HudCodec.summary(name, currentProfile()))
                            toast(context, "Plan panoya kopyalandı")
                        },
                    )
                }
                if (message != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(message ?: "", fontSize = 12.sp, color = CyberTextMuted)
                }
                Spacer(Modifier.height(8.dp))
                CyberButton(
                    text = "Önerilene sıfırla",
                    secondary = true,
                    onClick = { confirmPreset = fingers },
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            // --- Kayıtlı profiller ---
            SectionTitle("Kayıtlı profiller")
            if (profiles.isEmpty()) {
                Text("Henüz kayıtlı HUD profili yok.", fontSize = 13.sp, color = CyberTextMuted)
            }
            profiles.sortedByDescending { it.optLong("updated") }.forEach { p ->
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Text(p.optString("name"), fontWeight = FontWeight.SemiBold)
                    Text(
                        "${p.optInt("fingers", 3)} parmak • ${Format.dateTime(p.optLong("updated"))}",
                        fontSize = 11.sp,
                        color = CyberTextMuted,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CyberButton(
                            text = "Yükle",
                            onClick = {
                                val loaded = HudCodec.fromJson(p)
                                if (loaded == null) {
                                    message = "Profil okunamadı (bozuk veri)."
                                } else {
                                    fingers = loaded.fingers
                                    globalSize = loaded.globalSize
                                    opacity = loaded.opacity
                                    buttons.clear()
                                    buttons.addAll(loaded.buttons)
                                    profileName = p.optString("name")
                                    currentId = p.optString("id")
                                    selectedKey = null
                                    message = "\"${p.optString("name")}\" yüklendi."
                                }
                            },
                        )
                        CyberButton(text = "Sil", secondary = true, onClick = { deleteTarget = p })
                    }
                }
            }
            Spacer(Modifier.height(Dimens.SectionSpacing))
        }
    }

    val presetTarget = confirmPreset
    if (presetTarget != null) {
        ConfirmDialog(
            title = "$presetTarget parmak önerisi yüklensin mi?",
            text = "Önizlemedeki mevcut yerleşim, kaydetmediyseniz kaybolur. Kayıtlı profilleriniz etkilenmez.",
            confirmLabel = "Yükle",
            onConfirm = {
                confirmPreset = null
                applyPreset(presetTarget)
            },
            onDismiss = { confirmPreset = null },
        )
    }
    val del = deleteTarget
    if (del != null) {
        ConfirmDialog(
            title = "Profil silinsin mi?",
            text = "\"${del.optString("name")}\" kalıcı olarak silinecek.",
            confirmLabel = "Sil",
            onConfirm = {
                val id = del.optString("id")
                deleteTarget = null
                if (id == currentId) currentId = null
                scope.launch { AppStore.deleteById(context, StoreKeys.HUD_PROFILES, id) }
            },
            onDismiss = { deleteTarget = null },
        )
    }
}
