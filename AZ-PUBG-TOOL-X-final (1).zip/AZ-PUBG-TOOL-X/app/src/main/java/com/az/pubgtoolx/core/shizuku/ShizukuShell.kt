package com.az.pubgtoolx.core.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.az.pubgtoolx.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku
import kotlin.coroutines.resume

data class ShellResult(
    val ok: Boolean,
    val output: String,
    val error: String? = null,
)

class BytesResult(
    val bytes: ByteArray?,
    val error: String?,
)

/**
 * Shizuku üzerinden shell yetkisiyle komut çalıştırma / dosya okuma-yazma.
 * Shizuku hazır değilse (çalışmıyor / izin yok) hiçbir işlem yapılmaz ve açık bir hata döner.
 * Root gerekmez; Shizuku internet bağlantısı için kullanılmaz.
 */
object ShizukuShell {

    private const val NOT_READY = "Shizuku hazır değil (çalışmıyor veya izin verilmemiş)."
    private const val MAX_FILE_BYTES = 512 * 1024

    private val mutex = Mutex()

    @Volatile
    private var service: IUserService? = null

    @Volatile
    private var connection: ServiceConnection? = null

    fun isReady(): Boolean {
        return try {
            Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (t: Throwable) {
            false
        }
    }

    private suspend fun obtain(context: Context): IUserService? {
        return mutex.withLock {
            val current = service
            if (current != null && current.asBinder().pingBinder()) {
                return@withLock current
            }
            if (!isReady()) {
                return@withLock null
            }
            val packageName = context.packageName
            withTimeoutOrNull(8000L) {
                suspendCancellableCoroutine<IUserService?> { cont ->
                    val conn = object : ServiceConnection {
                        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                            val s = if (binder != null && binder.pingBinder()) {
                                IUserService.Stub.asInterface(binder)
                            } else {
                                null
                            }
                            service = s
                            if (cont.isActive) cont.resume(s)
                        }

                        override fun onServiceDisconnected(name: ComponentName?) {
                            service = null
                        }
                    }
                    connection = conn
                    try {
                        val args = Shizuku.UserServiceArgs(
                            ComponentName(packageName, ShellUserService::class.java.name),
                        )
                            .daemon(false)
                            .processNameSuffix("shell")
                            .debuggable(BuildConfig.DEBUG)
                            .version(BuildConfig.VERSION_CODE)
                        Shizuku.bindUserService(args, conn)
                    } catch (t: Throwable) {
                        if (cont.isActive) cont.resume(null)
                    }
                }
            }
        }
    }

    /** Komut çalıştırır. ok = çıkış kodu 0. */
    suspend fun exec(context: Context, command: String): ShellResult = withContext(Dispatchers.IO) {
        val s = obtain(context.applicationContext)
            ?: return@withContext ShellResult(false, "", NOT_READY)
        try {
            val raw = s.exec(command) ?: ""
            val nl = raw.indexOf('\n')
            val codeText = if (nl >= 0) raw.substring(0, nl) else raw
            val out = if (nl >= 0) raw.substring(nl + 1) else ""
            val code = codeText.trim().toIntOrNull() ?: -1
            if (code == 0) {
                ShellResult(true, out.trim())
            } else {
                ShellResult(false, out.trim(), "Komut hata kodu $code ile bitti")
            }
        } catch (t: Throwable) {
            service = null
            ShellResult(false, "", t.message ?: "Shizuku servis hatası")
        }
    }

    /** Dosyayı shell yetkisiyle okur (en fazla 512 KB). */
    suspend fun readFile(context: Context, path: String): BytesResult = withContext(Dispatchers.IO) {
        val s = obtain(context.applicationContext)
            ?: return@withContext BytesResult(null, NOT_READY)
        try {
            val bytes = s.readFile(path, MAX_FILE_BYTES)
            if (bytes == null) {
                BytesResult(null, "Dosya okunamadı (yok, klasör, 512 KB'tan büyük veya erişim yok).")
            } else {
                BytesResult(bytes, null)
            }
        } catch (t: Throwable) {
            service = null
            BytesResult(null, t.message ?: "Shizuku servis hatası")
        }
    }

    /** Dosyanın üzerine yazar. ok = yazma başarılı. */
    suspend fun writeFile(context: Context, path: String, data: ByteArray): ShellResult =
        withContext(Dispatchers.IO) {
            if (data.size > MAX_FILE_BYTES) {
                return@withContext ShellResult(false, "", "Dosya 512 KB sınırını aşıyor.")
            }
            val s = obtain(context.applicationContext)
                ?: return@withContext ShellResult(false, "", NOT_READY)
            try {
                val result = s.writeFile(path, data) ?: "Bilinmeyen hata"
                if (result == "OK") ShellResult(true, "OK") else ShellResult(false, "", result)
            } catch (t: Throwable) {
                service = null
                ShellResult(false, "", t.message ?: "Shizuku servis hatası")
            }
        }
}
