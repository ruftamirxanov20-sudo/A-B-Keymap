package com.az.pubgtoolx.ui.screens.potato

import android.content.Context
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.shizuku.ShizukuShell
import org.json.JSONObject

/** Sistem animasyon ölçekleri (Geliştirici seçenekleri'ndeki üç ayar). */
internal object PotatoLogic {

    val KEYS = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
    private const val BACKUP_KEY = "potato_backup"

    /** Okunan değer: null = ayar tanımlı değil (sistem varsayılanı 1.0). */
    data class Scales(val values: Map<String, String?>)

    sealed class Result {
        data class Ok(val scales: Scales) : Result()
        data class Fail(val reason: String) : Result()
    }

    suspend fun read(context: Context): Result {
        val map = LinkedHashMap<String, String?>()
        for (k in KEYS) {
            val r = ShizukuShell.exec(context, "settings get global $k")
            if (!r.ok) return Result.Fail("Okunamadı ($k): ${(r.error ?: "").ifBlank { "bilinmeyen hata" }}")
            val v = r.output.trim()
            map[k] = if (v.isEmpty() || v == "null") null else v
        }
        return Result.Ok(Scales(map))
    }

    private fun same(a: String?, b: String?): Boolean {
        val x = a?.toDoubleOrNull()
        val y = b?.toDoubleOrNull()
        if (a == null || b == null) return a == b
        return if (x != null && y != null) kotlin.math.abs(x - y) < 0.001 else a == b
    }

    private suspend fun writeValue(context: Context, key: String, value: String?): String? {
        val cmd = if (value == null) "settings delete global $key" else "settings put global $key $value"
        val r = ShizukuShell.exec(context, cmd)
        return if (r.ok) null else "Yazılamadı ($key): ${(r.error ?: "").ifBlank { r.output.ifBlank { "bilinmeyen hata" } }}"
    }

    suspend fun hasBackup(context: Context): Boolean = AppStore.getString(context, BACKUP_KEY) != null

    private suspend fun saveBackup(context: Context, scales: Scales) {
        val o = JSONObject()
        for ((k, v) in scales.values) o.put(k, v ?: JSONObject.NULL)
        AppStore.putString(context, BACKUP_KEY, o.toString())
    }

    private suspend fun loadBackup(context: Context): Scales? {
        val raw = AppStore.getString(context, BACKUP_KEY) ?: return null
        return try {
            val o = JSONObject(raw)
            val map = LinkedHashMap<String, String?>()
            for (k in KEYS) map[k] = if (o.isNull(k)) null else o.optString(k)
            Scales(map)
        } catch (e: Exception) {
            null
        }
    }

    /** Uygular, sonra geri okuyarak doğrular. İlk uygulamada önceki değerler yedeklenir. */
    suspend fun apply(context: Context, value: String): Result {
        val before = when (val r = read(context)) {
            is Result.Ok -> r.scales
            is Result.Fail -> return r
        }
        if (!hasBackup(context)) saveBackup(context, before)
        for (k in KEYS) {
            val err = writeValue(context, k, value)
            if (err != null) return Result.Fail(err)
        }
        val after = when (val r = read(context)) {
            is Result.Ok -> r.scales
            is Result.Fail -> return r
        }
        for (k in KEYS) {
            if (!same(after.values[k], value)) {
                return Result.Fail("Doğrulama başarısız: $k = ${after.values[k] ?: "tanımsız"} (beklenen $value)")
            }
        }
        return Result.Ok(after)
    }

    /** Yedeği geri yükler; doğruladıktan sonra yedeği siler. */
    suspend fun restore(context: Context): Result {
        val backup = loadBackup(context) ?: return Result.Fail("Geri yüklenecek yedek yok.")
        for (k in KEYS) {
            val err = writeValue(context, k, backup.values[k])
            if (err != null) return Result.Fail(err)
        }
        val after = when (val r = read(context)) {
            is Result.Ok -> r.scales
            is Result.Fail -> return r
        }
        for (k in KEYS) {
            if (!same(after.values[k], backup.values[k])) {
                return Result.Fail("Doğrulama başarısız: $k = ${after.values[k] ?: "tanımsız"}")
            }
        }
        AppStore.remove(context, BACKUP_KEY)
        return Result.Ok(after)
    }
}
