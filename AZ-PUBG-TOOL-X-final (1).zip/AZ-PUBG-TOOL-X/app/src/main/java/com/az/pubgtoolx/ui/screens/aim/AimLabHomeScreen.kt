package com.az.pubgtoolx.ui.screens.aim

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.data.StoreKeys
import com.az.pubgtoolx.core.util.Format
import com.az.pubgtoolx.ui.components.ConfirmDialog
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberChipRow
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.InfoRow
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.theme.CyberError
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val SECONDS_OPTIONS = listOf(30, 60, 90)

@Composable
fun AimLabHomeScreen(
    onStart: (mode: String, difficulty: String, seconds: Int) -> Unit,
    onBack: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val modes = AimMode.values().toList()
    val difficulties = AimDifficulty.values().toList()

    var modeIdx by rememberSaveable { mutableIntStateOf(0) }
    var diffIdx by rememberSaveable { mutableIntStateOf(1) }
    var secIdx by rememberSaveable { mutableIntStateOf(1) }
    var filterIdx by rememberSaveable { mutableIntStateOf(0) }
    var confirmClear by remember { mutableStateOf(false) }

    val historyFlow = remember { AppStore.arrayFlow(context, StoreKeys.AIM_HISTORY) }
    val rawHistory by historyFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    val history = remember(rawHistory) { rawHistory.map { parseAimRecord(it) } }

    val selectedMode = modes[modeIdx.coerceIn(0, modes.size - 1)]
    val selectedDiff = difficulties[diffIdx.coerceIn(0, difficulties.size - 1)]
    val selectedSec = SECONDS_OPTIONS[secIdx.coerceIn(0, SECONDS_OPTIONS.size - 1)]

    val filtered = if (filterIdx == 0) {
        history
    } else {
        val fm = modes[(filterIdx - 1).coerceIn(0, modes.size - 1)]
        history.filter { it.mode == fm }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "Aim Training Lab", subtitle = "Nişan yeteneğini geliştir", onBack = onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            SectionTitle("Mod")
            CyberChipRow(
                options = modes.map { it.label },
                selectedIndex = modeIdx,
                onSelect = { modeIdx = it },
            )
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(selectedMode.label, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(selectedMode.description, fontSize = 12.sp, color = CyberTextMuted)
            }

            SectionTitle("Zorluk")
            CyberChipRow(
                options = difficulties.map { it.label },
                selectedIndex = diffIdx,
                onSelect = { diffIdx = it },
            )

            SectionTitle("Süre")
            CyberChipRow(
                options = SECONDS_OPTIONS.map { "$it sn" },
                selectedIndex = secIdx,
                onSelect = { secIdx = it },
            )

            CyberButton(
                text = "Başlat",
                onClick = { onStart(selectedMode.name, selectedDiff.name, selectedSec) },
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Bu sürümde 2D antrenman vardır. 3D mod sonraki sürümde, cihaz uygunsa eklenecek.",
                fontSize = 12.sp,
                color = CyberTextMuted,
            )

            SectionTitle("Gelişim")
            CyberChipRow(
                options = listOf("Hepsi") + modes.map { it.label },
                selectedIndex = filterIdx,
                onSelect = { filterIdx = it },
            )
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                if (filtered.isEmpty()) {
                    Text("Henüz kayıtlı antrenman yok.", fontSize = 13.sp, color = CyberTextMuted)
                } else {
                    val avgAcc = filtered.map { it.accuracy }.average()
                    val best = filtered.maxOf { it.score }
                    InfoRow("Toplam seans", filtered.size.toString())
                    InfoRow("Ortalama isabet", "%" + "%.1f".format(avgAcc))
                    InfoRow("En iyi puan", best.toString())
                    Spacer(Modifier.height(8.dp))
                    if (filtered.size >= 2) {
                        // Liste en yeni başta; grafik için son 20 seans eski → yeni sıralanır.
                        val series = filtered.take(20).reversed().map { it.accuracy.toFloat() }
                        Text("Son ${series.size} seans • isabet %", fontSize = 11.sp, color = CyberTextMuted)
                        AimLineChart(values = series)
                    } else {
                        Text("Grafik için en az 2 seans gerekir.", fontSize = 12.sp, color = CyberTextMuted)
                    }
                }
            }

            SectionTitle("Antrenman geçmişi")
            if (filtered.isEmpty()) {
                Text("Gösterilecek kayıt yok.", fontSize = 13.sp, color = CyberTextMuted)
            } else {
                for (rec in filtered.take(10)) {
                    CyberCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(rec.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(Format.dateTime(rec.updated), fontSize = 11.sp, color = CyberTextMuted)
                                val reaction = if (rec.avgReactionMs > 0) "  •  ${rec.avgReactionMs} ms" else ""
                                Text(
                                    "İsabet %" + rec.accuracy.roundToInt() + "  •  Puan " + rec.score + reaction,
                                    fontSize = 12.sp,
                                )
                            }
                            IconButton(onClick = {
                                scope.launch { AppStore.deleteById(context, StoreKeys.AIM_HISTORY, rec.id) }
                            }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Sil", tint = CyberError)
                            }
                        }
                    }
                }
                CyberButton(
                    text = "Tüm geçmişi temizle",
                    onClick = { confirmClear = true },
                    secondary = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "Geçmiş silinsin mi?",
            text = "Tüm antrenman kayıtları kalıcı olarak silinecek.",
            confirmLabel = "Sil",
            onConfirm = {
                confirmClear = false
                scope.launch { AppStore.remove(context, StoreKeys.AIM_HISTORY) }
            },
            onDismiss = { confirmClear = false },
        )
    }
}
