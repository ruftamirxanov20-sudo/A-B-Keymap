package com.az.pubgtoolx.ui.components

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import com.az.pubgtoolx.ui.theme.CyberError
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSurface
import com.az.pubgtoolx.ui.theme.CyberText
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import kotlinx.coroutines.delay

/** Onay penceresi. Sistem ayarı değiştiren her işlemden önce kullanılır. */
@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    dismissLabel: String = "Vazgeç",
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberSurface,
        titleContentColor = CyberText,
        textContentColor = CyberTextMuted,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirmLabel, color = CyberPrimary) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(dismissLabel, color = CyberTextMuted) }
        },
    )
}

/** Tek düğmeli bilgi penceresi. */
@Composable
fun InfoDialog(
    title: String,
    text: String,
    onDismiss: () -> Unit,
    okLabel: String = "Tamam",
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberSurface,
        titleContentColor = CyberText,
        textContentColor = CyberTextMuted,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(okLabel, color = CyberPrimary) }
        },
    )
}

/**
 * Güvenli geri alma penceresi: değişiklik uygulandıktan sonra gösterilir.
 * [seconds] içinde "Koru" seçilmezse [onRevert] otomatik çağrılır (ekran okunamaz hale gelirse bile).
 */
@Composable
fun SafeRevertDialog(
    message: String,
    onKeep: () -> Unit,
    onRevert: () -> Unit,
    seconds: Int = 15,
) {
    var remaining by remember { mutableIntStateOf(seconds) }
    val latestRevert by rememberUpdatedState(onRevert)

    LaunchedEffect(Unit) {
        while (remaining > 0) {
            delay(1000L)
            remaining -= 1
        }
        latestRevert()
    }

    AlertDialog(
        onDismissRequest = {},
        containerColor = CyberSurface,
        titleContentColor = CyberText,
        textContentColor = CyberTextMuted,
        title = { Text("Ayar korunsun mu?") },
        text = { Text("$message\n\n$remaining sn içinde onaylamazsan otomatik geri alınır.") },
        confirmButton = {
            TextButton(onClick = onKeep) { Text("Koru", color = CyberPrimary) }
        },
        dismissButton = {
            TextButton(onClick = onRevert) { Text("Geri al", color = CyberError) }
        },
    )
}
