package com.az.pubgtoolx.ui.screens.sensitivity

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.data.StoreKeys
import com.az.pubgtoolx.core.util.Format
import com.az.pubgtoolx.core.util.copyToClipboard
import com.az.pubgtoolx.core.util.readClipboardText
import com.az.pubgtoolx.core.util.shareText
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.ui.components.ConfirmDialog
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberChipRow
import com.az.pubgtoolx.ui.components.CyberSlider
import com.az.pubgtoolx.ui.components.CyberSwitchRow
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.components.StatusBadge
import com.az.pubgtoolx.ui.theme.CyberError
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSuccess
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.roundToInt

private val TAB_LABELS = listOf("Genel", "Jiroskop", "Dürbün", "Profiller")

@Composable
fun SensitivityScreen(onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val profilesFlow = remember { AppStore.arrayFlow(context.applicationContext, StoreKeys.SENS_PROFILES) }
    val profiles by profilesFlow.collectAsStateWithLifecycle(initialValue = emptyList<JSONObject>())

    val values = remember {
        mutableStateMapOf<String, Float>().also { m ->
            for (k in SensSpec.keys) m[k] = SensSpec.DEFAULT.toFloat()
        }
    }
    var profileName by remember { mutableStateOf("") }
    var editingId by remember { mutableStateOf<String?>(null) }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    val hasGyro = remember {
        try {
            val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null
        } catch (e: Exception) {
            false
        }
    }

    fun save(asNew: Boolean) {
        val name = profileName.trim()
        if (name.isEmpty()) {
            toast(context, "Önce bir profil adı girin")
            return
        }
        val current = editingId
        val id = if (asNew || current == null) AppStore.newId() else current
        val obj = SensJson.build(id, name.take(40), values)
        scope.launch {
            try {
                AppStore.upsert(context, StoreKeys.SENS_PROFILES, obj)
                editingId = id
                toast(context, "Profil kaydedildi")
            } catch (e: Exception) {
                toast(context, "Kaydedilemedi: ${e.message}")
            }
        }
    }

    fun load(o: JSONObject) {
        val loaded = SensJson.valuesOf(o)
        for (k in SensSpec.keys) values[k] = loaded[k] ?: SensSpec.DEFAULT.toFloat()
        profileName = o.optString("name")
        editingId = o.optString("id")
        tab = 0
        toast(context, "Profil düzenleyiciye yüklendi")
    }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(
            title = "Sensitivity Studio",
            subtitle = "Profesyonel hassasiyet profilleri",
            onBack = onBack,
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.ItemSpacing),
        ) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Bu bir profil/referans aracıdır: değerleri oyundaki ayar ekranına elle girmek için " +
                        "kaydeder ve karşılaştırır. Uygulama oyunun ayarlarını değiştirmez. " +
                        "Oyundaki yüzde aralığı sürüme göre değişebilir; kaydırıcılar en fazla 300 verir.",
                    fontSize = 12.sp,
                    color = CyberTextMuted,
                )
            }

            CyberChipRow(
                options = TAB_LABELS,
                selectedIndex = tab,
                onSelect = { tab = it },
            )

            when (tab) {
                0 -> {
                    CyberCard(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionTitle("Kamera ve ADS")
                        SensSlider("Kamera hassasiyeti", "camera", values)
                        SensSlider("ADS hassasiyeti", "ads", values)
                    }
                    SaveCard(
                        name = profileName,
                        onNameChange = { profileName = it.take(40) },
                        editing = editingId != null,
                        onSave = { save(false) },
                        onSaveNew = { save(true) },
                    )
                }
                1 -> {
                    CyberCard(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            SectionTitle("Jiroskop")
                            if (hasGyro) {
                                StatusBadge("Sensör bulundu", CyberSuccess)
                            } else {
                                StatusBadge("Sensör yok", CyberError)
                            }
                        }
                        if (!hasGyro) {
                            Text(
                                "Bu cihazda jiroskop sensörü bulunamadı; jiroskop ayarları oyunda çalışmaz. " +
                                    "Yine de değerleri profil olarak saklayabilirsiniz.",
                                fontSize = 12.sp,
                                color = CyberWarning,
                            )
                        }
                        SensSlider("Jiroskop (kamera)", "gyroCamera", values)
                        SensSlider("Jiroskop (ADS)", "gyroAds", values)
                    }
                    SaveCard(
                        name = profileName,
                        onNameChange = { profileName = it.take(40) },
                        editing = editingId != null,
                        onSave = { save(false) },
                        onSaveNew = { save(true) },
                    )
                }
                2 -> {
                    for (s in SensSpec.scopes) {
                        CyberCard(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            SectionTitle(s.second)
                            SensSlider("Kamera/ADS", SensSpec.scopeCamKey(s.first), values)
                            SensSlider("Jiroskop ADS", SensSpec.scopeGyroKey(s.first), values)
                        }
                    }
                    SaveCard(
                        name = profileName,
                        onNameChange = { profileName = it.take(40) },
                        editing = editingId != null,
                        onSave = { save(false) },
                        onSaveNew = { save(true) },
                    )
                }
                else -> {
                    ProfilesTab(
                        profiles = profiles,
                        editingId = editingId,
                        onLoad = { load(it) },
                        onDeleted = { id ->
                            if (editingId == id) editingId = null
                        },
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SensSlider(label: String, key: String, values: MutableMap<String, Float>) {
    val v = values[key] ?: SensSpec.DEFAULT.toFloat()
    CyberSlider(
        label = label,
        value = v,
        onValueChange = { values[key] = it.roundToInt().toFloat() },
        valueRange = 0f..SensSpec.MAX.toFloat(),
        valueText = "${v.roundToInt()}%",
    )
}

@Composable
private fun SaveCard(
    name: String,
    onNameChange: (String) -> Unit,
    editing: Boolean,
    onSave: () -> Unit,
    onSaveNew: () -> Unit,
) {
    CyberCard(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("Profili kaydet")
        ProfileTextField(value = name, onValueChange = onNameChange, label = "Profil adı")
        if (editing) {
            Text("Kayıtlı bir profili düzenliyorsun.", fontSize = 12.sp, color = CyberTextMuted)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            CyberButton(
                text = if (editing) "Güncelle" else "Kaydet",
                onClick = onSave,
                modifier = Modifier.weight(1f),
            )
            if (editing) {
                CyberButton(
                    text = "Yeni olarak kaydet",
                    onClick = onSaveNew,
                    modifier = Modifier.weight(1f),
                    secondary = true,
                )
            }
        }
    }
}

@Composable
private fun ProfilesTab(
    profiles: List<JSONObject>,
    editingId: String?,
    onLoad: (JSONObject) -> Unit,
    onDeleted: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var deleteTarget by remember { mutableStateOf<JSONObject?>(null) }
    var cmpA by remember { mutableIntStateOf(0) }
    var cmpB by remember { mutableIntStateOf(1) }
    var onlyDiff by remember { mutableStateOf(false) }
    var importText by remember { mutableStateOf("") }
    var importError by remember { mutableStateOf<String?>(null) }
    var pendingImport by remember { mutableStateOf<JSONObject?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(Dimens.ItemSpacing)) {
        if (profiles.isEmpty()) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Henüz kayıtlı profil yok. Genel, Jiroskop veya Dürbün sekmesinde değerleri ayarlayıp kaydedin.",
                    fontSize = 13.sp,
                    color = CyberTextMuted,
                )
            }
        }

        for (p in profiles) {
            val json = p.toString(2)
            CyberCard(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        p.optString("name").ifBlank { "(adsız)" },
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f),
                    )
                    if (p.optString("id") == editingId) {
                        StatusBadge("Düzenleniyor", CyberPrimary)
                    }
                }
                Text(
                    "Kamera ${p.optInt("camera", -1)} • ADS ${p.optInt("ads", -1)} • " +
                        "Jiroskop ${p.optInt("gyroCamera", -1)}/${p.optInt("gyroAds", -1)}",
                    fontSize = 12.sp,
                    color = CyberTextMuted,
                )
                Text(
                    "Güncelleme: ${Format.dateTime(p.optLong("updated"))}",
                    fontSize = 11.sp,
                    color = CyberTextMuted,
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CyberButton(text = "Yükle", onClick = { onLoad(p) }, modifier = Modifier.weight(1f))
                    CyberButton(
                        text = "Çoğalt",
                        onClick = {
                            val copy = JSONObject(p.toString())
                            copy.put("id", AppStore.newId())
                            copy.put("name", (p.optString("name") + " (kopya)").take(40))
                            copy.put("updated", System.currentTimeMillis())
                            scope.launch {
                                try {
                                    AppStore.upsert(context, StoreKeys.SENS_PROFILES, copy)
                                    toast(context, "Profil çoğaltıldı")
                                } catch (e: Exception) {
                                    toast(context, "Çoğaltılamadı: ${e.message}")
                                }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        secondary = true,
                    )
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CyberButton(
                        text = "Paylaş",
                        onClick = { shareText(context, "Hassasiyet profili", json) },
                        modifier = Modifier.weight(1f),
                    )
                    CyberButton(
                        text = "Kopyala",
                        onClick = {
                            copyToClipboard(context, "Hassasiyet profili", json)
                            toast(context, "Profil JSON'u panoya kopyalandı")
                        },
                        modifier = Modifier.weight(1f),
                    )
                    CyberButton(
                        text = "Sil",
                        onClick = { deleteTarget = p },
                        modifier = Modifier.weight(1f),
                        secondary = true,
                    )
                }
            }
        }

        if (profiles.size >= 2) {
            val names = profiles.map { it.optString("name").ifBlank { "(adsız)" } }
            val ia = cmpA.coerceIn(0, profiles.size - 1)
            val ib = cmpB.coerceIn(0, profiles.size - 1)
            val pa = profiles[ia]
            val pb = profiles[ib]

            CyberCard(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionTitle("Karşılaştır")
                Text("Profil A", fontSize = 12.sp, color = CyberTextMuted)
                CyberChipRow(options = names, selectedIndex = ia, onSelect = { cmpA = it })
                Text("Profil B", fontSize = 12.sp, color = CyberTextMuted)
                CyberChipRow(options = names, selectedIndex = ib, onSelect = { cmpB = it })

                var diffCount = 0
                for (f in SensSpec.fields) {
                    if (pa.optInt(f.key, -1) != pb.optInt(f.key, -1)) diffCount++
                }
                Text(
                    if (diffCount == 0) "Seçilen iki profil aynı değerlere sahip." else "$diffCount alanda fark var.",
                    fontSize = 12.sp,
                    color = if (diffCount == 0) CyberSuccess else CyberWarning,
                )
                CyberSwitchRow(
                    title = "Sadece farkları göster",
                    checked = onlyDiff,
                    onCheckedChange = { onlyDiff = it },
                )

                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Alan", fontSize = 12.sp, color = CyberTextMuted, modifier = Modifier.weight(1.6f))
                    Text("A", fontSize = 12.sp, color = CyberTextMuted, textAlign = TextAlign.End, modifier = Modifier.weight(0.6f))
                    Text("B", fontSize = 12.sp, color = CyberTextMuted, textAlign = TextAlign.End, modifier = Modifier.weight(0.6f))
                }
                for (f in SensSpec.fields) {
                    val va = pa.optInt(f.key, -1)
                    val vb = pb.optInt(f.key, -1)
                    val differs = va != vb
                    if (onlyDiff && !differs) continue
                    val color = if (differs) CyberWarning else CyberTextMuted
                    val weight = if (differs) FontWeight.Bold else FontWeight.Normal
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(f.label, fontSize = 12.sp, color = color, fontWeight = weight, modifier = Modifier.weight(1.6f))
                        Text(
                            if (va < 0) "—" else va.toString(),
                            fontSize = 12.sp, color = color, fontWeight = weight,
                            textAlign = TextAlign.End, modifier = Modifier.weight(0.6f),
                        )
                        Text(
                            if (vb < 0) "—" else vb.toString(),
                            fontSize = 12.sp, color = color, fontWeight = weight,
                            textAlign = TextAlign.End, modifier = Modifier.weight(0.6f),
                        )
                    }
                }
            }
        }

        CyberCard(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitle("İçe aktar")
            Text(
                "Dışa aktarılmış bir profil JSON'unu yapıştırın. Değerler doğrulanır; hatalıysa eklenmez.",
                fontSize = 12.sp,
                color = CyberTextMuted,
            )
            ProfileTextField(
                value = importText,
                onValueChange = {
                    importText = it
                    importError = null
                },
                label = "Profil JSON",
                singleLine = false,
                minLines = 4,
            )
            val err = importError
            if (err != null) {
                Text(err, fontSize = 12.sp, color = CyberError)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberButton(
                    text = "Panodan yapıştır",
                    onClick = {
                        val t = readClipboardText(context)
                        if (t.isNullOrBlank()) {
                            toast(context, "Panoda metin yok")
                        } else {
                            importText = t
                            importError = null
                        }
                    },
                    modifier = Modifier.weight(1f),
                    secondary = true,
                )
                CyberButton(
                    text = "İçe aktar",
                    onClick = {
                        val r = SensJson.parseImport(importText)
                        val prof = r.profile
                        if (prof == null) {
                            importError = r.error ?: "Bilinmeyen hata"
                        } else {
                            importError = null
                            pendingImport = prof
                        }
                    },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }

    val del = deleteTarget
    if (del != null) {
        ConfirmDialog(
            title = "Profil silinsin mi?",
            text = "\"${del.optString("name")}\" kalıcı olarak silinecek.",
            confirmLabel = "Sil",
            onConfirm = {
                val id = del.optString("id")
                deleteTarget = null
                scope.launch {
                    try {
                        AppStore.deleteById(context, StoreKeys.SENS_PROFILES, id)
                        onDeleted(id)
                        toast(context, "Profil silindi")
                    } catch (e: Exception) {
                        toast(context, "Silinemedi: ${e.message}")
                    }
                }
            },
            onDismiss = { deleteTarget = null },
        )
    }

    val imp = pendingImport
    if (imp != null) {
        ConfirmDialog(
            title = "Profil eklensin mi?",
            text = "\"${imp.optString("name")}\" yeni bir profil olarak eklenecek.",
            confirmLabel = "Ekle",
            onConfirm = {
                pendingImport = null
                scope.launch {
                    try {
                        AppStore.upsert(context, StoreKeys.SENS_PROFILES, imp)
                        importText = ""
                        toast(context, "Profil içe aktarıldı")
                    } catch (e: Exception) {
                        toast(context, "İçe aktarılamadı: ${e.message}")
                    }
                }
            },
            onDismiss = { pendingImport = null },
        )
    }
}
