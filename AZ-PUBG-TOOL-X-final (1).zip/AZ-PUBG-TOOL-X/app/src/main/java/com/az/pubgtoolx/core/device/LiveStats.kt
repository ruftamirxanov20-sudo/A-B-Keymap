package com.az.pubgtoolx.core.device

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

/** Sık değişen değerler (pil, sıcaklık, boş RAM). İzin gerektirmez. */
data class LiveStats(
    val batteryPercent: Int?,
    val batteryTempC: Float?,
    val charging: Boolean,
    val availRamMb: Long,
    val totalRamMb: Long,
)

object LiveStatsReader {

    fun read(context: Context): LiveStats {
        val battery: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else null

        val tempTenths = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val tempC = if (tempTenths != Int.MIN_VALUE) tempTenths / 10f else null

        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo().also { activityManager.getMemoryInfo(it) }

        return LiveStats(
            batteryPercent = percent,
            batteryTempC = tempC,
            charging = charging,
            availRamMb = memoryInfo.availMem / (1024L * 1024L),
            totalRamMb = memoryInfo.totalMem / (1024L * 1024L),
        )
    }
}
