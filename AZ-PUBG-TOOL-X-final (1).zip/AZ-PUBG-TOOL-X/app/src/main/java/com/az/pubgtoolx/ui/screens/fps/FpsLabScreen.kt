package com.az.pubgtoolx.ui.screens.fps

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.data.StoreKeys
import com.az.pubgtoolx.core.device.LiveStats
import com.az.pubgtoolx.core.device.LiveStatsReader
import com.az.pubgtoolx.core.util.Format
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.monitor.MonitorService
import com.az.pubgtoolx.monitor.MonitorState
import com.az.pubgtoolx.monitor.needsNotificationPermission
import com.az.pubgtoolx.ui.components.ConfirmDialog
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.InfoRow
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.components.ShizukuGate
import com.az.pubgtoolx.ui.components.StatusBadge
import com.az.pubgtoolx.ui.components.rememberShizuku
import com.az.pubgtoolx.ui.screens.resolution.AzTextField
import com.az.pubgtoolx.ui.theme.CyberOutline
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSecondary
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.math.roundToInt

private const val TEST_SECONDS = 10

private fun supportedRefreshRates(context: Context): List<Int> {
    return try {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display: Display = dm.getDisplay(Display.DEFAULT_DISPLAY) ?: return emptyList()
        display.supportedModes.map { it.refreshRate.roundToInt() }.distinct().sortedDescending()
    } catch (e: Exception) {
        emptyList()
    }
}

@Composable
fun FpsLabScreen(onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizuku = rememberShizuku()

    // --- Canlı sistem değerleri (2 sn'de bir, yalnızca bu ekran açıkken) ---
    var live by remember { mutableStateOf<LiveStats?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            live = withContext(Dispatchers.IO) { LiveStatsReader.read(context) }
            delay(2000L)
        }
    }

    val refreshRates = remember { supportedRefreshRates(context) }

    // --- Ekran kare hızı testi ---
    var testing by remember { mutableStateOf(false) }
    val frameSamples = remember { mutableStateListOf<Float>() }
    LaunchedEffect(testing) {
        if (testing) {
            frameSamples.clear()
            var count = 0
            var windowStart = 0L
            var seconds = 0
            while (seconds < TEST_SECONDS) {
                val t = androidx.compose.runtime.withFrameNanos { it }
                if (windowStart == 0L) {
                    windowStart = t
                    continue
                }
                count++
                val span = t - windowStart
                if (span >= 1_000_000_000L) {
                    frameSamples.add(count * 1_000_000_000f / span)
                    count = 0
                    windowStart = t
                    seconds++
                }
            }
            testing = false
        }
    }

    // --- Kayıt / servis durumu ---
    val running by MonitorState.running.collectAsStateWithLifecycle()
    val recording by MonitorState.recording.collectAsStateWithLifecycle()
    val recordLabel by MonitorState.recordLabel.collectAsStateWithLifecycle()
    val recSamples by MonitorState.samples.collectAsStateWithLifecycle()
    val notice by MonitorState.notice.collectAsStateWithLifecycle()

    var label by remember { mutableStateOf("") }

    fun startRecordNow() {
        try {
            MonitorService.send(
                context,
                MonitorService.ACTION_START_RECORD,
                label.ifBlank { "Kayıt " + Format.time(System.currentTimeMillis()) },
            )
        } catch (e: Exception) {
            toast(context, "Kayıt başlatılamadı: ${e.message}")
        }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        // İzin verilmese de servis çalışır; yalnızca bildirim görünmeyebilir.
        startRecordNow()
    }

    // --- Geçmiş ---
    val recordsFlow = remember { AppStore.arrayFlow(context, StoreKeys.FPS_RECORDS) }
    val records by recordsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    val sorted = remember(records) { records.sortedByDescending { it.optLong("updated") } }
    var deleteTarget by remember { mutableStateOf<JSONObject?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "FPS & Graphics Lab", subtitle = "Ölçüm, kayıt ve grafik rehberi", onBack = onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            if (notice != null) {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Text(notice ?: "", fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    CyberButton(text = "Tamam", onClick = { MonitorState.clearNotice() })
                }
            }

            // --- Sistem durumu ---
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Cihaz durumu")
                Spacer(Modifier.height(6.dp))
                val l = live
                if (l == null) {
                    Text("Okunuyor…", fontSize = 13.sp, color = CyberTextMuted)
                } else {
                    InfoRow("Boş RAM", "${l.availRamMb} MB / ${l.totalRamMb} MB")
                    InfoRow(
                        "Pil",
                        (l.batteryPercent?.let { "%$it" } ?: "Okunamadı") + if (l.charging) " (şarjda)" else "",
                    )
                    InfoRow("Pil sıcaklığı", l.batteryTempC?.let { "%.1f °C".format(it) } ?: "Okunamadı")
                }
                InfoRow(
                    "Desteklenen yenileme hızları",
                    if (refreshRates.isEmpty()) "Okunamadı" else refreshRates.joinToString(" / ") { "$it Hz" },
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Yenileme hızını bu uygulama değiştirmez; Ayarlar › Ekran bölümünden seçebilirsiniz.",
                    fontSize = 11.sp,
                    color = CyberTextMuted,
                )
            }

            // --- Ekran kare hızı testi ---
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Ekran kare hızı testi")
                Spacer(Modifier.height(4.dp))
                StatusBadge("Oyun FPS'i değildir", CyberWarning)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Bu uygulamanın penceresinin $TEST_SECONDS saniyede kaç kare çizebildiğini ölçer. Ekranın ve sistemin kare çıkışı hakkında fikir verir; PUBG Mobile'ın FPS değeri değildir.",
                    fontSize = 12.sp,
                    color = CyberTextMuted,
                )
                Spacer(Modifier.height(8.dp))
                if (frameSamples.isNotEmpty()) {
                    FrameBars(frameSamples.toList())
                    Spacer(Modifier.height(8.dp))
                    val avg = frameSamples.average()
                    val min = frameSamples.minOrNull() ?: 0f
                    InfoRow("Ortalama", "${avg.roundToInt()} kare/sn")
                    InfoRow("En düşük", "${min.roundToInt()} kare/sn")
                    InfoRow("Örnek", "${frameSamples.size} / $TEST_SECONDS sn")
                    Spacer(Modifier.height(8.dp))
                }
                CyberButton(
                    text = if (testing) "Ölçülüyor…" else "Testi başlat",
                    onClick = { testing = true },
                    enabled = !testing,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            // --- Oyun FPS kaydı (Shizuku) ---
            SectionTitle("Oyun FPS kaydı")
            ShizukuGate(controller = shizuku, featureText = "Oyunun gerçek FPS değerini okumak") {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Kaydı başlatın, PUBG Mobile'a geçin ve oynayın. Dönünce bildirimdeki \"Kaydı durdur\" ile bitirin. Her saniye oyunun sunduğu kare sayısı SurfaceFlinger'dan okunur. Okunamazsa kayıt kaydedilmez ve nedeni bildirilir; değer uydurulmaz.",
                        fontSize = 12.sp,
                        color = CyberTextMuted,
                    )
                    Spacer(Modifier.height(8.dp))
                    if (recording) {
                        InfoRow("Kayıt", recordLabel)
                        InfoRow("Okunan örnek", "$recSamples")
                        Spacer(Modifier.height(8.dp))
                        CyberButton(
                            text = "Kaydı durdur",
                            onClick = {
                                try {
                                    MonitorService.send(context, MonitorService.ACTION_STOP_RECORD)
                                } catch (e: Exception) {
                                    toast(context, "Durdurulamadı: ${e.message}")
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    } else {
                        AzTextField(
                            value = label,
                            onValueChange = { label = it },
                            label = "Kayıt adı (ör. Düşük grafik 60 FPS)",
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(8.dp))
                        CyberButton(
                            text = "Kaydı başlat",
                            onClick = {
                                if (needsNotificationPermission(context)) {
                                    notifLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    startRecordNow()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        if (running) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "İzleme servisi zaten çalışıyor (overlay açık olabilir).",
                                fontSize = 11.sp,
                                color = CyberTextMuted,
                            )
                        }
                    }
                }
            }

            // --- Geçmiş ve karşılaştırma ---
            SectionTitle("Kayıtlar")
            if (sorted.isEmpty()) {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Henüz kayıt yok. Gerçek oyun FPS'i yalnızca Shizuku ile okunabildiğinde kayıt oluşur.",
                        fontSize = 13.sp,
                        color = CyberTextMuted,
                    )
                }
            } else {
                val shown = sorted.take(8)
                val maxAvg = shown.maxOf { it.optDouble("avg", 0.0) }.coerceAtLeast(1.0)
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Ortalama FPS karşılaştırması (son ${shown.size})", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    shown.forEach { rec ->
                        val avg = rec.optDouble("avg", 0.0)
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
                            Text(
                                rec.optString("name"),
                                fontSize = 11.sp,
                                color = CyberTextMuted,
                                maxLines = 1,
                                modifier = Modifier.width(96.dp),
                            )
                            Box(modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth((avg / maxAvg).toFloat().coerceIn(0.03f, 1f))
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(5.dp))
                                        .background(CyberPrimary),
                                )
                            }
                            Text(
                                "${avg.roundToInt()}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(start = 8.dp),
                            )
                        }
                    }
                }
                sorted.forEach { rec ->
                    CyberCard(modifier = Modifier.fillMaxWidth()) {
                        Text(rec.optString("name"), fontWeight = FontWeight.SemiBold)
                        Text(Format.dateTime(rec.optLong("updated")), fontSize = 11.sp, color = CyberTextMuted)
                        Spacer(Modifier.height(6.dp))
                        InfoRow("Ortalama", "${rec.optDouble("avg", 0.0).roundToInt()} FPS")
                        InfoRow("En düşük / en yüksek", "${rec.optInt("min")} / ${rec.optInt("max")} FPS")
                        InfoRow("%1 düşük", "${rec.optDouble("low1", 0.0).roundToInt()} FPS")
                        InfoRow("Süre / örnek", "${rec.optInt("durationSec")} sn / ${rec.optInt("samples")}")
                        Spacer(Modifier.height(8.dp))
                        CyberButton(text = "Sil", onClick = { deleteTarget = rec }, secondary = true)
                    }
                }
                CyberButton(
                    text = "Tüm kayıtları sil",
                    onClick = { confirmClear = true },
                    secondary = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            // --- Grafik rehberi ---
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Grafik rehberi")
                Spacer(Modifier.height(6.dp))
                val ram = live?.totalRamMb ?: 0L
                val tip = when {
                    ram in 1L..3500L -> "Cihazın RAM'i sınırlı: Düzgün veya Dengeli grafik, 30–40 FPS, gölge ve yansımayı kapalı tutmak daha akıcı sonuç verir."
                    ram in 3501L..6500L -> "Orta seviye cihaz: Dengeli/HD grafik ve 40–60 FPS genelde uygundur; gölgeleri kapatmak ısınmayı azaltır."
                    ram > 6500L -> "Güçlü cihaz: Yüksek FPS seçenekleri denenebilir; ısınma artarsa FPS'i veya grafiği bir kademe düşürün."
                    else -> "RAM okunamadı."
                }
                Text(tip, fontSize = 12.sp, color = CyberTextMuted)
                Spacer(Modifier.height(6.dp))
                Text(
                    "• Sabit düşük FPS yerine sabit akıcı FPS tercih edilir; %1 düşük değeri takılmaları gösterir.\n• Pil sıcaklığı yükseldikçe cihaz kendini yavaşlatabilir.\n• Oyun içi grafik ayarları oyunun kendi menüsünden yapılır; bu uygulama oyun dosyalarını değiştirmez.",
                    fontSize = 12.sp,
                    color = CyberTextMuted,
                )
            }
            Spacer(Modifier.height(Dimens.SectionSpacing))
        }
    }

    val target = deleteTarget
    if (target != null) {
        ConfirmDialog(
            title = "Kaydı sil",
            text = "\"${target.optString("name")}\" kaydı silinecek.",
            confirmLabel = "Sil",
            onConfirm = {
                val id = target.optString("id")
                deleteTarget = null
                scope.launch { AppStore.deleteById(context, StoreKeys.FPS_RECORDS, id) }
            },
            onDismiss = { deleteTarget = null },
        )
    }
    if (confirmClear) {
        ConfirmDialog(
            title = "Tüm kayıtlar silinsin mi?",
            text = "Tüm FPS kayıtları kalıcı olarak silinecek.",
            confirmLabel = "Hepsini sil",
            onConfirm = {
                confirmClear = false
                scope.launch { AppStore.remove(context, StoreKeys.FPS_RECORDS) }
            },
            onDismiss = { confirmClear = false },
        )
    }
}

@Composable
private fun FrameBars(values: List<Float>) {
    val maxV = (values.maxOrNull() ?: 1f).coerceAtLeast(1f)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(90.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        values.forEachIndexed { i, v ->
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("${v.roundToInt()}", fontSize = 9.sp, color = CyberTextMuted)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight((v / maxV).coerceIn(0.05f, 1f) * 0.8f)
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (i % 2 == 0) CyberPrimary else CyberSecondary),
                )
            }
        }
    }
    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(CyberOutline))
}
