package com.az.pubgtoolx.ui.screens.overlay

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.az.pubgtoolx.core.log.OperationLog
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.monitor.MonitorService
import com.az.pubgtoolx.monitor.MonitorState
import com.az.pubgtoolx.monitor.OverlayPrefs
import com.az.pubgtoolx.monitor.OverlayPrefsStore
import com.az.pubgtoolx.monitor.needsNotificationPermission
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberSwitchRow
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.InfoRow
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.components.ShizukuStatusBadge
import com.az.pubgtoolx.ui.components.StatusBadge
import com.az.pubgtoolx.ui.components.rememberShizuku
import com.az.pubgtoolx.ui.theme.CyberSuccess
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.launch

@Composable
fun OverlayScreen(onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizuku = rememberShizuku()

    var canDraw by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        canDraw = Settings.canDrawOverlays(context)
    }

    val prefsFlow = remember { OverlayPrefsStore.flow(context) }
    val prefs by prefsFlow.collectAsStateWithLifecycle(initialValue = OverlayPrefs())

    val visible by MonitorState.overlayVisible.collectAsStateWithLifecycle()
    val running by MonitorState.running.collectAsStateWithLifecycle()
    val fps by MonitorState.currentFps.collectAsStateWithLifecycle()
    val source by MonitorState.source.collectAsStateWithLifecycle()
    val message by MonitorState.message.collectAsStateWithLifecycle()
    val notice by MonitorState.notice.collectAsStateWithLifecycle()

    fun startOverlayNow() {
        try {
            MonitorService.send(context, MonitorService.ACTION_START_OVERLAY)
            scope.launch { OperationLog.add(context, "Overlay", "Overlay başlatma isteği", true, "Servis başlatıldı") }
        } catch (e: Exception) {
            toast(context, "Overlay başlatılamadı: ${e.message}")
            scope.launch { OperationLog.add(context, "Overlay", "Overlay başlatma", false, e.message ?: "Hata") }
        }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        startOverlayNow()
    }

    fun update(transform: (OverlayPrefs) -> OverlayPrefs) {
        val next = transform(prefs)
        scope.launch { OverlayPrefsStore.save(context, next) }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "Gaming Overlay", subtitle = "İsteğe bağlı kayan bilgi paneli", onBack = onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            if (notice != null) {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Text(notice ?: "", fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    CyberButton(text = "Tamam", onClick = { MonitorState.clearNotice() })
                }
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle("Durum")
                    if (visible) StatusBadge("Overlay açık", CyberSuccess) else StatusBadge("Kapalı", CyberTextMuted)
                }
                Spacer(Modifier.height(6.dp))
                InfoRow("Servis", if (running) "Çalışıyor" else "Durdu")
                InfoRow(
                    "Gösterilen değer",
                    when {
                        !visible -> "—"
                        fps == null -> "Okunamadı"
                        source == "GAME" -> "$fps FPS (oyun)"
                        else -> "$fps Hz (ekran yenileme hızı, oyun FPS'i değil)"
                    },
                )
                if (visible && message.isNotBlank()) {
                    Text(message, fontSize = 11.sp, color = CyberTextMuted)
                }
                Spacer(Modifier.height(6.dp))
                ShizukuStatusBadge(shizuku)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Overlay yalnızca siz açınca çalışır ve kapatınca servis tamamen durur. Oyun FPS'i yalnızca Shizuku hazırken okunabilir; aksi halde ekran yenileme hızı gösterilir ve bu açıkça belirtilir.",
                    fontSize = 11.sp,
                    color = CyberTextMuted,
                )
            }

            if (!canDraw) {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionTitle("İzin gerekli")
                        StatusBadge("Verilmedi", CyberWarning)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Paneli oyunun üstünde göstermek için \"Diğer uygulamaların üzerinde göster\" izni gerekir. Sistem ayarında bu uygulamayı açın, sonra geri dönün.",
                        fontSize = 12.sp,
                        color = CyberTextMuted,
                    )
                    Spacer(Modifier.height(8.dp))
                    CyberButton(
                        text = "İzin ayarını aç",
                        onClick = {
                            try {
                                context.startActivity(
                                    Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:" + context.packageName),
                                    ),
                                )
                            } catch (e: Exception) {
                                toast(context, "Ayar ekranı açılamadı")
                            }
                        },
                    )
                }
            } else {
                CyberButton(
                    text = if (visible) "Overlay'i kapat" else "Overlay'i aç",
                    onClick = {
                        if (visible) {
                            try {
                                MonitorService.send(context, MonitorService.ACTION_STOP_OVERLAY)
                            } catch (e: Exception) {
                                toast(context, "Kapatılamadı: ${e.message}")
                            }
                        } else if (needsNotificationPermission(context)) {
                            notifLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            startOverlayNow()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Panelde gösterilecekler")
                Spacer(Modifier.height(4.dp))
                CyberSwitchRow("FPS / yenileme hızı", prefs.showFps, { v -> update { it.copy(showFps = v) } })
                CyberSwitchRow("Saat", prefs.showClock, { v -> update { it.copy(showClock = v) } })
                CyberSwitchRow("Pil ve sıcaklık", prefs.showBattery, { v -> update { it.copy(showBattery = v) } })
                CyberSwitchRow("Boş RAM", prefs.showRam, { v -> update { it.copy(showRam = v) } })
                CyberSwitchRow(
                    "Kısayollar",
                    prefs.showShortcuts,
                    { v -> update { it.copy(showShortcuts = v) } },
                    subtitle = "Uygulama, PUBG ve Kapat düğmeleri",
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Paneli sürükleyerek taşıyabilirsiniz. Değişiklikler açık panele anında uygulanır.",
                    fontSize = 11.sp,
                    color = CyberTextMuted,
                )
                Spacer(Modifier.height(8.dp))
                CyberButton(
                    text = "Konumu sıfırla",
                    onClick = { update { it.copy(posX = -1, posY = -1) } },
                    secondary = true,
                )
            }
            Spacer(Modifier.height(Dimens.SectionSpacing))
        }
    }
}
