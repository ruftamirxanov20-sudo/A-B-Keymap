package com.az.pubgtoolx.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.graphics.vector.ImageVector

/** Tools ekranındaki filtre grupları. */
enum class ModuleCategory(val label: String) {
    GAME("Oyun"),
    SYSTEM("Sistem"),
    UTILITY("Araçlar"),
}

/** Modülün Shizuku'ya bağımlılığı. */
enum class ShizukuUse(val badge: String?) {
    NONE(null),
    OPTIONAL("Shizuku opsiyonel"),
    REQUIRED("Shizuku gerekli"),
}

/** Uygulamadaki tüm modüller. */
enum class ToolModule(
    val id: String,
    val title: String,
    val shortTitle: String,
    val description: String,
    val category: ModuleCategory,
    val shizuku: ShizukuUse,
    val icon: ImageVector,
) {
    AIM_TRAINING("aim", "Aim Training Lab", "Aim Training", "Nişan antrenman simülatörü", ModuleCategory.GAME, ShizukuUse.NONE, Icons.Filled.GpsFixed),
    SENSITIVITY("sensitivity", "Sensitivity Studio", "Sensitivity", "Hassasiyet profilleri", ModuleCategory.GAME, ShizukuUse.NONE, Icons.Filled.Tune),
    HUD("hud", "HUD Designer", "HUD Designer", "Parmak düzeni editörü", ModuleCategory.GAME, ShizukuUse.NONE, Icons.Filled.Dashboard),
    WEAPONS("weapons", "Weapon Database", "Weapons", "Silah verileri ve karşılaştırma", ModuleCategory.GAME, ShizukuUse.NONE, Icons.Filled.Storage),
    FPS_LAB("fps", "FPS & Graphics Lab", "FPS & Graphics", "FPS ve performans izleme", ModuleCategory.SYSTEM, ShizukuUse.OPTIONAL, Icons.Filled.BarChart),
    COMPAT("compat", "Device Compatibility", "Compatibility", "Cihaz uyumluluk motoru", ModuleCategory.SYSTEM, ShizukuUse.NONE, Icons.Filled.PhoneAndroid),
    POTATO("potato", "Potato Graphics", "Potato Graphics", "Düşük grafik rehberi", ModuleCategory.SYSTEM, ShizukuUse.OPTIONAL, Icons.Filled.Speed),
    ACTIVE_SAV("activesav", "Active.sav Manager", "Active.sav", "Dosya analizi ve yedekleme", ModuleCategory.SYSTEM, ShizukuUse.OPTIONAL, Icons.Filled.Save),
    RESOLUTION("resolution", "Resolution & iPad View", "Resolution", "Çözünürlük ve iPad görünümü", ModuleCategory.SYSTEM, ShizukuUse.REQUIRED, Icons.Filled.AspectRatio),
    DPI("dpi", "DP/DPI Controller", "DP/DPI", "DPI profilleri", ModuleCategory.SYSTEM, ShizukuUse.REQUIRED, Icons.Filled.Straighten),
    CLEANER("cleaner", "Phone Cleaner", "Cleaner", "Önbellek ve depolama analizi", ModuleCategory.UTILITY, ShizukuUse.OPTIONAL, Icons.Filled.CleaningServices),
    OVERLAY("overlay", "Gaming Overlay", "Overlay", "İsteğe bağlı kayan panel", ModuleCategory.UTILITY, ShizukuUse.OPTIONAL, Icons.Filled.Layers);

    companion object {
        /** Ana ekrandaki hızlı erişim kutucukları. */
        val homeTiles: List<ToolModule> = listOf(
            AIM_TRAINING, SENSITIVITY, HUD, FPS_LAB, RESOLUTION, CLEANER,
        )

        fun fromId(id: String?): ToolModule? = entries.firstOrNull { it.id == id }
    }
}
