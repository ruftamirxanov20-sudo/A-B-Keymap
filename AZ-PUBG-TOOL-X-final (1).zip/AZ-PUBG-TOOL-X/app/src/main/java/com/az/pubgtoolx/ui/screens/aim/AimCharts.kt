package com.az.pubgtoolx.ui.screens.aim

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.az.pubgtoolx.ui.theme.CyberOutline
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSecondary
import com.az.pubgtoolx.ui.theme.CyberTextMuted

/**
 * Basit çizgi grafik (0–100 aralığı, soldan sağa eski → yeni).
 * Harici kütüphane yok; yalnızca Canvas.
 */
@Composable
fun AimLineChart(values: List<Float>, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(130.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(end = 6.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("100", fontSize = 10.sp, color = CyberTextMuted)
            Text("50", fontSize = 10.sp, color = CyberTextMuted)
            Text("0", fontSize = 10.sp, color = CyberTextMuted)
        }
        Canvas(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
        ) {
            val w = size.width
            val h = size.height
            val pad = 8f
            val usableH = h - 2f * pad
            val usableW = w - 2f * pad

            for (g in 0..4) {
                val y = pad + usableH * g / 4f
                drawLine(
                    color = CyberOutline.copy(alpha = 0.6f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1f,
                )
            }

            val n = values.size
            if (n == 0) return@Canvas

            val path = Path()
            for (i in 0 until n) {
                val v = values[i].coerceIn(0f, 100f)
                val x = if (n == 1) w / 2f else pad + usableW * i / (n - 1).toFloat()
                val y = pad + usableH * (1f - v / 100f)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            if (n > 1) {
                drawPath(
                    path = path,
                    color = CyberPrimary,
                    style = Stroke(width = 4f, cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
            }
            for (i in 0 until n) {
                val v = values[i].coerceIn(0f, 100f)
                val x = if (n == 1) w / 2f else pad + usableW * i / (n - 1).toFloat()
                val y = pad + usableH * (1f - v / 100f)
                drawCircle(color = CyberSecondary, radius = 5f, center = Offset(x, y))
            }
        }
    }
}
