package com.az.pubgtoolx.ui.screens.logs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.log.OperationLog
import com.az.pubgtoolx.core.util.Format
import com.az.pubgtoolx.ui.components.ConfirmDialog
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.StatusBadge
import com.az.pubgtoolx.ui.theme.CyberError
import com.az.pubgtoolx.ui.theme.CyberSuccess
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.launch

@Composable
fun OperationLogScreen(onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val logFlow = remember { OperationLog.flow(context) }
    val entries by logFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    var confirmClear by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "İşlem Kayıtları", subtitle = "Son ${entries.size} işlem", onBack = onBack)
        if (entries.isEmpty()) {
            CyberCard(modifier = Modifier.fillMaxWidth().padding(horizontal = Dimens.ScreenPadding)) {
                Text("Henüz kayıtlı işlem yok.", fontSize = 13.sp, color = CyberTextMuted)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = Dimens.ScreenPadding, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(Dimens.ItemSpacing),
            ) {
                items(entries) { e ->
                    CyberCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("${e.module} • ${e.action}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            if (e.success) StatusBadge("Başarılı", CyberSuccess) else StatusBadge("Başarısız", CyberError)
                        }
                        Text(Format.dateTime(e.time), fontSize = 11.sp, color = CyberTextMuted)
                        if (e.detail.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(e.detail, fontSize = 12.sp, color = CyberTextMuted)
                        }
                    }
                }
                item {
                    CyberButton(text = "Kayıtları temizle", onClick = { confirmClear = true }, secondary = true)
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "Kayıtlar silinsin mi?",
            text = "Tüm işlem kayıtları silinecek. Yapılan sistem değişiklikleri geri alınmaz.",
            confirmLabel = "Sil",
            onConfirm = {
                confirmClear = false
                scope.launch { OperationLog.clear(context) }
            },
            onDismiss = { confirmClear = false },
        )
    }
}
