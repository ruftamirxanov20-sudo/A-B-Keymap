package com.az.pubgtoolx.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.az.pubgtoolx.ui.components.ScreenBackground
import com.az.pubgtoolx.ui.screens.SettingsScreen
import com.az.pubgtoolx.ui.screens.activesav.ActiveSavScreen
import com.az.pubgtoolx.ui.screens.aim.AimLabHomeScreen
import com.az.pubgtoolx.ui.screens.aim.AimPlayScreen
import com.az.pubgtoolx.ui.screens.cleaner.CleanerScreen
import com.az.pubgtoolx.ui.screens.compat.CompatibilityScreen
import com.az.pubgtoolx.ui.screens.dpi.DpiScreen
import com.az.pubgtoolx.ui.screens.fps.FpsLabScreen
import com.az.pubgtoolx.ui.screens.overlay.OverlayScreen
import com.az.pubgtoolx.ui.screens.resolution.ResolutionScreen
import com.az.pubgtoolx.ui.screens.ToolsScreen
import com.az.pubgtoolx.ui.screens.home.HomeScreen
import com.az.pubgtoolx.ui.screens.hud.HudDesignerScreen
import com.az.pubgtoolx.ui.screens.logs.OperationLogScreen
import com.az.pubgtoolx.ui.screens.potato.PotatoScreen
import com.az.pubgtoolx.ui.screens.profiles.ProfilesScreen
import com.az.pubgtoolx.ui.screens.sensitivity.SensitivityScreen
import com.az.pubgtoolx.ui.screens.weapons.WeaponsScreen
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSurface
import com.az.pubgtoolx.ui.theme.CyberText
import com.az.pubgtoolx.ui.theme.CyberTextMuted

/** Sekmeler arası geçiş: durum korunur, aynı sekmeye tekrar basınca yığın büyümez. */
private fun NavController.openTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun AzApp() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    // Modül/oyun ekranlarında alt çubuk gizlenir; ilk karede (rota null) gösterilir.
    val showBottomBar = currentRoute == null || BottomTab.entries.any { it.route == currentRoute }

    val openModule: (ToolModule) -> Unit = { navController.navigate(Routes.module(it.id)) }
    val back: () -> Unit = { navController.popBackStack() }

    ScreenBackground {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                if (showBottomBar) {
                    NavigationBar(containerColor = CyberSurface, contentColor = CyberText) {
                        BottomTab.entries.forEach { tab ->
                            NavigationBarItem(
                                selected = currentRoute == tab.route,
                                onClick = { navController.openTab(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label, fontSize = 11.sp, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberPrimary,
                                    selectedTextColor = CyberPrimary,
                                    indicatorColor = CyberPrimary.copy(alpha = 0.18f),
                                    unselectedIconColor = CyberTextMuted,
                                    unselectedTextColor = CyberTextMuted,
                                ),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Routes.HOME,
                modifier = Modifier.padding(innerPadding),
                // Hafif geçişler: yalnızca kısa solma, kaydırma/ölçekleme yok.
                enterTransition = { fadeIn(tween(150)) },
                exitTransition = { fadeOut(tween(100)) },
                popEnterTransition = { fadeIn(tween(150)) },
                popExitTransition = { fadeOut(tween(100)) },
            ) {
                composable(Routes.HOME) {
                    HomeScreen(
                        onOpenModule = openModule,
                        onOpenSettings = { navController.openTab(Routes.SETTINGS) },
                    )
                }
                composable(Routes.TOOLS) {
                    ToolsScreen(onOpenModule = openModule)
                }
                composable(Routes.AIM) {
                    ModuleContent(ToolModule.AIM_TRAINING, navController, onBack = null)
                }
                composable(Routes.PROFILES) {
                    ProfilesScreen(onOpenModule = openModule)
                }
                composable(Routes.SETTINGS) {
                    SettingsScreen(onOpenLogs = { navController.navigate(Routes.LOGS) })
                }
                composable(Routes.LOGS) {
                    OperationLogScreen(onBack = back)
                }
                composable(Routes.MODULE_PATTERN) { entry ->
                    val module = ToolModule.fromId(entry.arguments?.getString(Routes.MODULE_ARG))
                    if (module != null) {
                        ModuleContent(module, navController, onBack = back)
                    }
                }
                composable(
                    route = Routes.AIM_PLAY_PATTERN,
                    arguments = listOf(
                        navArgument(Routes.ARG_MODE) { type = NavType.StringType },
                        navArgument(Routes.ARG_DIFFICULTY) { type = NavType.StringType },
                        navArgument(Routes.ARG_SECONDS) { type = NavType.IntType },
                    ),
                ) { entry ->
                    val args = entry.arguments
                    AimPlayScreen(
                        mode = args?.getString(Routes.ARG_MODE) ?: "SNIPER",
                        difficulty = args?.getString(Routes.ARG_DIFFICULTY) ?: "MEDIUM",
                        seconds = args?.getInt(Routes.ARG_SECONDS) ?: 60,
                        onExit = back,
                    )
                }
            }
        }
    }
}

/** Her modülün gerçek ekranını gösterir. */
@Composable
private fun ModuleContent(module: ToolModule, navController: NavController, onBack: (() -> Unit)?) {
    when (module) {
        ToolModule.SENSITIVITY -> SensitivityScreen(onBack = onBack)
        ToolModule.AIM_TRAINING -> AimLabHomeScreen(
            onStart = { m, d, s -> navController.navigate(Routes.aimPlay(m, d, s)) },
            onBack = onBack,
        )
        ToolModule.RESOLUTION -> ResolutionScreen(onBack = onBack)
        ToolModule.DPI -> DpiScreen(onBack = onBack)
        ToolModule.CLEANER -> CleanerScreen(onBack = onBack)
        ToolModule.FPS_LAB -> FpsLabScreen(onBack = onBack)
        ToolModule.OVERLAY -> OverlayScreen(onBack = onBack)
        ToolModule.HUD -> HudDesignerScreen(onBack = onBack)
        ToolModule.WEAPONS -> WeaponsScreen(
            onTrain = { mode -> navController.navigate(Routes.aimPlay(mode, "MEDIUM", 60)) },
            onBack = onBack,
        )
        ToolModule.COMPAT -> CompatibilityScreen(onBack = onBack)
        ToolModule.POTATO -> PotatoScreen(onBack = onBack)
        ToolModule.ACTIVE_SAV -> ActiveSavScreen(onBack = onBack)
    }
}
