package com.az.pubgtoolx.core.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Context.azDataStore: DataStore<Preferences> by preferencesDataStore(name = "az_store")

/** Tüm kalıcı listelerin anahtarları. Her liste bir JSON dizisidir (JSONObject öğeleri). */
object StoreKeys {
    const val AIM_HISTORY = "aim_history"
    const val SENS_PROFILES = "sens_profiles"
    const val HUD_PROFILES = "hud_profiles"
    const val DPI_PROFILES = "dpi_profiles"
    const val RES_PROFILES = "res_profiles"
    const val WEAPON_PROFILES = "weapon_profiles"
    const val FPS_RECORDS = "fps_records"
    const val OP_LOG = "op_log"
}

/**
 * Hafif yerel depo (DataStore Preferences üstünde JSON listeleri).
 * Okuma/yazma yalnızca cihazda yapılır; internet gerekmez.
 */
object AppStore {

    fun newId(): String = UUID.randomUUID().toString()

    fun stringFlow(context: Context, key: String): Flow<String?> {
        val k = stringPreferencesKey(key)
        return context.applicationContext.azDataStore.data.map { it[k] }
    }

    suspend fun getString(context: Context, key: String): String? = stringFlow(context, key).first()

    suspend fun putString(context: Context, key: String, value: String) {
        val k = stringPreferencesKey(key)
        context.applicationContext.azDataStore.edit { it[k] = value }
    }

    suspend fun remove(context: Context, key: String) {
        val k = stringPreferencesKey(key)
        context.applicationContext.azDataStore.edit { it.remove(k) }
    }

    /** Tüm yerel verileri siler (profiller, geçmiş, kayıtlar). */
    suspend fun clearAll(context: Context) {
        context.applicationContext.azDataStore.edit { it.clear() }
    }

    fun arrayFlow(context: Context, key: String): Flow<List<JSONObject>> =
        stringFlow(context, key).map { parseObjects(it) }

    suspend fun getArray(context: Context, key: String): List<JSONObject> =
        parseObjects(getString(context, key))

    /** Atomik oku-değiştir-yaz. */
    suspend fun updateArray(
        context: Context,
        key: String,
        transform: (List<JSONObject>) -> List<JSONObject>,
    ) {
        val k = stringPreferencesKey(key)
        context.applicationContext.azDataStore.edit { prefs ->
            val current = parseObjects(prefs[k])
            prefs[k] = toJson(transform(current))
        }
    }

    /** "id" alanına göre ekler veya değiştirir; en yeni başa gelir. */
    suspend fun upsert(context: Context, key: String, item: JSONObject, max: Int = 200) {
        val id = item.optString("id")
        updateArray(context, key) { current ->
            (listOf(item) + current.filter { it.optString("id") != id }).take(max)
        }
    }

    suspend fun deleteById(context: Context, key: String, id: String) {
        updateArray(context, key) { current -> current.filter { it.optString("id") != id } }
    }

    fun parseObjects(raw: String?): List<JSONObject> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<JSONObject>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i)
                if (o != null) out.add(o)
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun toJson(list: List<JSONObject>): String {
        val arr = JSONArray()
        for (o in list) arr.put(o)
        return arr.toString()
    }
}
