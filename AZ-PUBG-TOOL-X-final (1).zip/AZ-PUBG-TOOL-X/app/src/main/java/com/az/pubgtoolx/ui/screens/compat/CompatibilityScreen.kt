package com.az.pubgtoolx.ui.screens.compat

import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.device.DeviceInfo
import com.az.pubgtoolx.core.device.DeviceInfoProvider
import com.az.pubgtoolx.core.game.GamePackages
import com.az.pubgtoolx.core.shizuku.ShizukuState
import com.az.pubgtoolx.core.util.copyToClipboard
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.monitor.needsNotificationPermission
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.InfoRow
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.components.rememberShizuku
import com.az.pubgtoolx.ui.screens.resolution.CheckLevel
import com.az.pubgtoolx.ui.screens.resolution.CheckLine
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.Dimens

private data class FeatureRow(val name: String, val level: CheckLevel, val text: String)

private fun freeInternalMb(): Long {
    return try {
        val st = StatFs(Environment.getDataDirectory().path)
        st.availableBytes / (1024L * 1024L)
    } catch (e: Exception) {
        -1L
    }
}

private fun tierOf(ramMb: Long): String = when {
    ramMb <= 0L -> "Belirlenemedi"
    ramMb <= 3500L -> "Düşük seviye (≈ 3 GB ve altı)"
    ramMb <= 6500L -> "Orta seviye (≈ 4–6 GB)"
    else -> "Üst seviye (≈ 8 GB ve üzeri)"
}

@Composable
fun CompatibilityScreen(onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val shizuku = rememberShizuku()
    val shizukuState by shizuku.state.collectAsStateWithLifecycle()

    var refreshKey by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refreshKey += 1 }

    // refreshKey değişince yeniden okunur (izin ayarından dönüşte güncel olsun).
    val info: DeviceInfo = remember(refreshKey) { DeviceInfoProvider.read(context) }
    val canDraw = remember(refreshKey) { Settings.canDrawOverlays(context) }
    val needNotif = remember(refreshKey) { needsNotificationPermission(context) }
    val installedGames = remember(refreshKey) { GamePackages.installed(context) }
    val freeMb = remember(refreshKey) { freeInternalMb() }

    val shizukuReady = shizukuState == ShizukuState.READY
    val shizukuText = when (shizukuState) {
        ShizukuState.READY -> "Hazır"
        ShizukuState.NEEDS_PERMISSION -> "Çalışıyor, bu uygulamaya izin verilmedi"
        ShizukuState.PERMISSION_BLOCKED -> "İzin reddedilmiş"
        ShizukuState.NOT_RUNNING -> "Yüklü ama çalışmıyor"
        ShizukuState.NOT_INSTALLED -> "Yüklü değil"
    }

    val needsShizuku = if (shizukuReady) CheckLevel.OK else CheckLevel.WARN
    val shizukuHint = if (shizukuReady) "Shizuku hazır" else "Shizuku hazır değil ($shizukuText)"

    val features = listOf(
        FeatureRow("Aim Training Lab", CheckLevel.OK, "Çalışır (2D, çevrimdışı)"),
        FeatureRow("Sensitivity Studio", CheckLevel.OK, "Çalışır (planlama/referans; oyun ayarını değiştirmez)"),
        FeatureRow("HUD Designer", CheckLevel.OK, "Çalışır (planlama taslağı; oyun HUD'unu değiştirmez)"),
        FeatureRow("Weapon Database", CheckLevel.OK, "Çalışır (çevrimdışı, yerleşik veri)"),
        FeatureRow(
            "FPS Lab",
            needsShizuku,
            if (shizukuReady) "Ekran hızı + oyun FPS'i (oyun/cihaz desteklerse)" else "Yalnızca ekran kare hızı; oyun FPS'i için Shizuku gerekir",
        ),
        FeatureRow(
            "Gaming Overlay",
            if (canDraw) CheckLevel.OK else CheckLevel.WARN,
            if (canDraw) "Çalışır (oyun FPS'i için ayrıca Shizuku)" else "\"Diğer uygulamaların üzerinde göster\" izni gerekli",
        ),
        FeatureRow("Resolution / iPad View", needsShizuku, shizukuHint),
        FeatureRow("DP / DPI Controller", needsShizuku, shizukuHint),
        FeatureRow("Potato Graphics (animasyon ölçekleri)", needsShizuku, shizukuHint),
        FeatureRow(
            "Phone Cleaner",
            if (Build.VERSION.SDK_INT >= 30) CheckLevel.OK else CheckLevel.WARN,
            if (Build.VERSION.SDK_INT >= 30) "Çalışır (silme sistem onayıyla)" else "Android 11 altında toplu silme desteklenmez; yalnızca analiz",
        ),
        FeatureRow(
            "Active.sav Manager",
            CheckLevel.OK,
            if (shizukuReady) "Dosya seçici + Shizuku ile oyun klasörü" else "Dosya seçici ile çalışır; Android 13+ cihazlarda oyun klasörü için Shizuku gerekir",
        ),
    )

    val report = remember(refreshKey, shizukuState) {
        val sb = StringBuilder()
        sb.append("AZ PUBG TOOL X uyumluluk raporu\n")
        sb.append("Cihaz: ").append(info.model).append('\n')
        sb.append("Android: ").append(info.androidVersion).append(" (API ").append(info.apiLevel).append(")\n")
        sb.append("İşlemci: ").append(info.cpu).append(" • ").append(info.abi).append('\n')
        sb.append("RAM: ").append(info.totalRamMb).append(" MB • ").append(tierOf(info.totalRamMb)).append('\n')
        sb.append("Ekran: ").append(info.resolution).append(" • ").append(info.dpi).append(" dpi • ").append(info.refreshRateHz).append(" Hz\n")
        sb.append("Shizuku: ").append(shizukuText).append('\n')
        sb.append("Overlay izni: ").append(if (canDraw) "var" else "yok").append('\n')
        sb.append("PUBG: ").append(if (installedGames.isEmpty()) "yüklü sürüm bulunamadı" else installedGames.joinToString { it.label }).append('\n')
        sb.toString()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "Device Compatibility", subtitle = "Cihazınızda neler çalışır?", onBack = onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Cihaz")
                Spacer(Modifier.height(6.dp))
                InfoRow("Model", info.model)
                InfoRow("Android", "${info.androidVersion} (API ${info.apiLevel})")
                InfoRow("İşlemci", info.cpu)
                InfoRow("Mimari", info.abi)
                InfoRow("RAM", "${info.totalRamMb} MB")
                InfoRow("Ekran", "${info.resolution} • ${info.dpi} dpi")
                InfoRow("Yenileme hızı", if (info.refreshRateHz > 0) "${info.refreshRateHz} Hz" else "Okunamadı")
                InfoRow("Boş dahili depolama", if (freeMb >= 0) "$freeMb MB" else "Okunamadı")
                InfoRow("Sınıf", tierOf(info.totalRamMb))
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Gereksinim kontrolleri")
                Spacer(Modifier.height(6.dp))
                CheckLine(
                    if (info.apiLevel >= 26) CheckLevel.OK else CheckLevel.ERROR,
                    if (info.apiLevel >= 26) "Android sürümü destekleniyor (en az Android 8)" else "Android 8'den eski: uygulama desteklenmez",
                )
                CheckLine(
                    if (info.abi.contains("64")) CheckLevel.OK else CheckLevel.WARN,
                    if (info.abi.contains("64")) "64 bit işlemci mimarisi" else "32 bit mimari: oyun performansı sınırlı olabilir",
                )
                CheckLine(
                    when {
                        info.totalRamMb >= 4000L -> CheckLevel.OK
                        info.totalRamMb > 0L -> CheckLevel.WARN
                        else -> CheckLevel.WARN
                    },
                    if (info.totalRamMb >= 4000L) "RAM yeterli" else "RAM sınırlı: düşük grafik ve Potato önerileri işe yarar",
                )
                CheckLine(
                    if (installedGames.isNotEmpty()) CheckLevel.OK else CheckLevel.WARN,
                    if (installedGames.isNotEmpty()) "PUBG Mobile bulundu: ${installedGames.joinToString { it.label }}" else "Yüklü PUBG Mobile sürümü bulunamadı",
                )
                CheckLine(
                    if (shizukuReady) CheckLevel.OK else CheckLevel.WARN,
                    "Shizuku: $shizukuText",
                )
                CheckLine(
                    if (canDraw) CheckLevel.OK else CheckLevel.WARN,
                    if (canDraw) "Overlay izni verilmiş" else "Overlay izni verilmemiş (yalnızca Overlay için gerekli)",
                )
                if (needNotif) {
                    CheckLine(CheckLevel.WARN, "Bildirim izni yok: servis bildirimi görünmeyebilir")
                }
                if (info.apiLevel >= 33) {
                    CheckLine(
                        CheckLevel.WARN,
                        "Android 13+ : Android/data klasörüne normal erişim yok; oyun klasörü dosyaları için Shizuku gerekir",
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Not: Bu kontroller yalnızca okuma yapar; hiçbir sistem ayarı değiştirmez.",
                    fontSize = 11.sp,
                    color = CyberTextMuted,
                )
            }

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Modül uyumluluğu")
                Spacer(Modifier.height(6.dp))
                features.forEach { f ->
                    CheckLine(f.level, "${f.name}: ${f.text}")
                }
            }

            CyberButton(
                text = "Raporu kopyala",
                onClick = {
                    copyToClipboard(context, "Uyumluluk raporu", report)
                    toast(context, "Rapor panoya kopyalandı")
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(Dimens.SectionSpacing))
        }
    }
}
