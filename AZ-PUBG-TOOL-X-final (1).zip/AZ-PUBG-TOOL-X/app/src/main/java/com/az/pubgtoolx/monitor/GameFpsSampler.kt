package com.az.pubgtoolx.monitor

import android.content.Context
import com.az.pubgtoolx.core.game.GamePackages
import com.az.pubgtoolx.core.shizuku.ShizukuShell

/** Tek bir oyun FPS örneği. [fps] null ise okunamadı; nedeni [message] içindedir. */
data class GameFpsSample(
    val fps: Int?,
    val packageName: String?,
    val message: String,
)

/** Saf ayrıştırma fonksiyonları (Android'e bağımlı değil, ayrı test edilebilir). */
object GameFpsParser {

    private const val NANOS = 1_000_000_000L

    /** `dumpsys window` odak çıktısında bilinen bir PUBG paketi geçiyorsa onu döndürür. */
    fun findGamePackage(focusOutput: String): String? {
        for (pkg in GamePackages.ALL) {
            if (focusOutput.contains(pkg.packageName)) return pkg.packageName
        }
        return null
    }

    /**
     * `dumpsys SurfaceFlinger --list` çıktısından paketin oyun karelerini taşıyan katmanını seçer.
     * SurfaceView / BLAST içeren katman tercih edilir.
     */
    fun pickLayer(listOutput: String, packageName: String): String? {
        var best: String? = null
        var bestScore = -1
        for (raw in listOutput.lines()) {
            val line = raw.trim()
            if (line.isEmpty() || !line.contains(packageName)) continue
            if (line.startsWith("Background for") || line.startsWith("Bounds for")) continue
            var score = 1
            if (line.contains("SurfaceView")) score += 2
            if (line.contains("BLAST")) score += 1
            if (score > bestScore) {
                best = line
                bestScore = score
            }
        }
        return best
    }

    /**
     * `dumpsys SurfaceFlinger --latency <katman>` çıktısından FPS hesaplar.
     * İlk satır yenileme periyodudur; sonraki satırlar "istenen / sunulan / hazır" zaman damgalarıdır.
     * Sunulan (2. sütun) zaman damgaları kullanılır; 0 ve Long.MAX_VALUE atılır.
     * [nowNanos] verilirse ve son kare 3 sn'den eskiyse null döner (kare akışı durmuş).
     */
    fun fpsFromLatency(output: String, nowNanos: Long?): Int? {
        val times = ArrayList<Long>()
        val lines = output.lines()
        for (i in 1 until lines.size) {
            val parts = lines[i].trim().split(Regex("\\s+"))
            if (parts.size < 3) continue
            val present = parts[1].toLongOrNull() ?: continue
            if (present <= 0L || present == Long.MAX_VALUE) continue
            times.add(present)
        }
        if (times.size < 2) return null
        times.sort()
        val latest = times[times.size - 1]
        val earliest = times[0]
        if (nowNanos != null && nowNanos - latest > 3 * NANOS) return null
        val span = latest - earliest
        if (span <= 0L) return null

        val fps: Long = if (span >= NANOS) {
            var count = 0L
            val windowStart = latest - NANOS
            for (t in times) {
                if (t > windowStart) count++
            }
            count
        } else {
            ((times.size - 1).toLong() * NANOS) / span
        }
        if (fps <= 0L || fps > 1000L) return null
        return fps.toInt()
    }
}

/**
 * Ön plandaki PUBG Mobile'ın gerçek FPS'ini Shizuku üzerinden okur (SurfaceFlinger zaman damgaları).
 * ~1 sn aralıkla çağrılması beklenir. Desteklenmeyen cihazlarda null FPS + açık mesaj döner; hiçbir değer uydurulmaz.
 */
class GameFpsSampler(context: Context) {

    private val appContext: Context = context.applicationContext
    private var cachedPackage: String? = null
    private var cachedLayer: String? = null
    private var tick = 0

    suspend fun sample(): GameFpsSample {
        if (!ShizukuShell.isReady()) {
            return GameFpsSample(null, null, "Shizuku hazır değil")
        }
        try {
            val needFocus = cachedLayer == null || tick % 3 == 0
            tick++

            var pkg: String? = cachedPackage
            if (needFocus) {
                val focus = ShizukuShell.exec(
                    appContext,
                    "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'",
                )
                pkg = GameFpsParser.findGamePackage(focus.output)
                if (pkg == null) {
                    cachedPackage = null
                    cachedLayer = null
                    val msg = if (focus.output.isBlank()) {
                        "Ön plandaki uygulama okunamadı"
                    } else {
                        "Ön planda PUBG Mobile bulunamadı"
                    }
                    return GameFpsSample(null, null, msg)
                }
                if (pkg != cachedPackage) {
                    cachedPackage = pkg
                    cachedLayer = null
                }
            }
            if (pkg == null) {
                return GameFpsSample(null, null, "Ön planda PUBG Mobile bulunamadı")
            }

            var layer: String? = cachedLayer
            if (layer == null) {
                val list = ShizukuShell.exec(appContext, "dumpsys SurfaceFlinger --list")
                layer = GameFpsParser.pickLayer(list.output, pkg)
                if (layer == null) {
                    return GameFpsSample(
                        null,
                        pkg,
                        "SurfaceFlinger katmanı bulunamadı (bu cihaz/Android sürümü bu yöntemi desteklemiyor olabilir)",
                    )
                }
                cachedLayer = layer
            }
            if (layer.contains('\'')) {
                cachedLayer = null
                return GameFpsSample(null, pkg, "Katman adı desteklenmiyor")
            }

            var latency = ShizukuShell.exec(appContext, "dumpsys SurfaceFlinger --latency '$layer'")
            var fps = GameFpsParser.fpsFromLatency(latency.output, System.nanoTime())
            if (fps == null && layer.contains('#')) {
                val shortName = layer.substringBeforeLast('#')
                if (shortName.isNotEmpty() && !shortName.contains('\'')) {
                    latency = ShizukuShell.exec(appContext, "dumpsys SurfaceFlinger --latency '$shortName'")
                    fps = GameFpsParser.fpsFromLatency(latency.output, System.nanoTime())
                }
            }
            if (fps == null) {
                cachedLayer = null
                return GameFpsSample(null, pkg, "FPS okunamadı (katman zaman damgası vermedi; bu cihazda desteklenmiyor olabilir)")
            }
            return GameFpsSample(fps, pkg, "OK")
        } catch (e: Exception) {
            cachedLayer = null
            return GameFpsSample(null, cachedPackage, "FPS okunamadı: ${e.message ?: "bilinmeyen hata"}")
        }
    }
}
