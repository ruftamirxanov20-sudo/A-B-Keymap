package com.az.pubgtoolx.ui.screens.resolution

import android.content.Context
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.view.Display
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.theme.CyberError
import com.az.pubgtoolx.ui.theme.CyberOutline
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSuccess
import com.az.pubgtoolx.ui.theme.CyberText
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning
import kotlin.math.roundToInt

/** Uygulamanın gördüğü gerçek ekran ölçüleri (kısa/uzun kenar piksel ve DPI). */
internal class ScreenMetrics(val shortPx: Int, val longPx: Int, val densityDpi: Int)

@Suppress("DEPRECATION")
internal fun appMetrics(context: Context): ScreenMetrics {
    val metrics = DisplayMetrics()
    try {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display: Display? = dm.getDisplay(Display.DEFAULT_DISPLAY)
        display?.getRealMetrics(metrics)
    } catch (e: Exception) {
        // aşağıdaki yedek kullanılır
    }
    if (metrics.widthPixels <= 0 || metrics.heightPixels <= 0) {
        val r = context.resources.displayMetrics
        return ScreenMetrics(
            minOf(r.widthPixels, r.heightPixels),
            maxOf(r.widthPixels, r.heightPixels),
            r.densityDpi,
        )
    }
    return ScreenMetrics(
        minOf(metrics.widthPixels, metrics.heightPixels),
        maxOf(metrics.widthPixels, metrics.heightPixels),
        metrics.densityDpi,
    )
}

internal fun gcdOf(a: Int, b: Int): Int {
    var x = a
    var y = b
    while (y != 0) {
        val t = x % y
        x = y
        y = t
    }
    return if (x == 0) 1 else x
}

/** Sadeleştirilmiş en-boy oranı (uzun:kısa), ör. "20:9". Sadeleşmiyorsa "2.22:1". */
internal fun aspectText(w: Int, h: Int): String {
    if (w <= 0 || h <= 0) return "—"
    val longS = maxOf(w, h)
    val shortS = minOf(w, h)
    val g = gcdOf(longS, shortS)
    val a = longS / g
    val b = shortS / g
    return if (a <= 32 && b <= 32) "$a:$b" else "%.2f:1".format(longS.toDouble() / shortS.toDouble())
}

/** px değerini dp'ye çevirir (dp = px * 160 / dpi). */
internal fun pxToDp(px: Int, dpi: Int): Int {
    if (dpi <= 0) return 0
    return (px * 160f / dpi).roundToInt()
}

internal enum class CheckLevel { OK, WARN, ERROR }

@Composable
internal fun CheckLine(level: CheckLevel, text: String) {
    val color = when (level) {
        CheckLevel.OK -> CyberSuccess
        CheckLevel.WARN -> CyberWarning
        CheckLevel.ERROR -> CyberError
    }
    val mark = when (level) {
        CheckLevel.OK -> "✔"
        CheckLevel.WARN -> "⚠"
        CheckLevel.ERROR -> "✖"
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
    ) {
        Text(mark, color = color, fontSize = 13.sp, modifier = Modifier.width(22.dp))
        Text(text, color = if (level == CheckLevel.OK) CyberText else color, fontSize = 12.sp)
    }
}

/** İşlem sonucu mesajı (başarı yeşil, hata kırmızı). */
@Composable
internal fun StatusCard(text: String, ok: Boolean, modifier: Modifier = Modifier) {
    CyberCard(modifier = modifier.fillMaxWidth()) {
        Text(
            text = if (ok) "✔ $text" else "✖ $text",
            color = if (ok) CyberSuccess else CyberError,
            fontSize = 13.sp,
        )
    }
}

/** Tek satırlık giriş alanı; [numeric] true ise yalnızca rakam kabul eder. */
@Composable
internal fun AzTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    numeric: Boolean = false,
) {
    OutlinedTextField(
        value = value,
        onValueChange = { raw ->
            onValueChange(if (numeric) raw.filter { it.isDigit() }.take(5) else raw.take(40))
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text,
        ),
        modifier = modifier,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = CyberText,
            unfocusedTextColor = CyberText,
            focusedBorderColor = CyberPrimary,
            unfocusedBorderColor = CyberOutline,
            focusedLabelColor = CyberPrimary,
            unfocusedLabelColor = CyberTextMuted,
            cursorColor = CyberPrimary,
        ),
    )
}
