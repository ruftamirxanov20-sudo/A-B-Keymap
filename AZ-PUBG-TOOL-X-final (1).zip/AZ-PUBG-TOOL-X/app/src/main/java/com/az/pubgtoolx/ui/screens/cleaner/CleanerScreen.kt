package com.az.pubgtoolx.ui.screens.cleaner

import android.app.Activity
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.az.pubgtoolx.core.log.OperationLog
import com.az.pubgtoolx.core.util.Format
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.ui.components.ConfirmDialog
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberChipRow
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.InfoRow
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.components.ShizukuGate
import com.az.pubgtoolx.ui.components.rememberShizuku
import com.az.pubgtoolx.ui.theme.CyberError
import com.az.pubgtoolx.ui.theme.CyberOutline
import com.az.pubgtoolx.ui.theme.CyberPrimary
import com.az.pubgtoolx.ui.theme.CyberSuccess
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val THRESHOLDS_MB = listOf(50L, 100L, 250L, 500L)

@Composable
fun CleanerScreen(onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizuku = rememberShizuku()

    var storage by remember { mutableStateOf<StorageStat?>(null) }
    var ownCache by remember { mutableStateOf<Long?>(null) }
    var cacheMessage by remember { mutableStateOf<String?>(null) }
    var confirmOwnCache by remember { mutableStateOf(false) }

    var hasPerm by remember { mutableStateOf(CleanerLogic.hasAnyMediaPermission(context)) }
    var thresholdIdx by rememberSaveable { mutableIntStateOf(1) }
    var files by remember { mutableStateOf<List<LargeFile>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var fileMessage by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var pendingIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var reloadKey by remember { mutableIntStateOf(0) }

    var sysMessage by remember { mutableStateOf<String?>(null) }
    var sysOk by remember { mutableStateOf(true) }
    var caches by remember { mutableStateOf<CacheAnalysis?>(null) }
    var sysBusy by remember { mutableStateOf(false) }
    var confirmTrim by remember { mutableStateOf(false) }

    suspend fun reloadFiles() {
        loading = true
        val min = THRESHOLDS_MB[thresholdIdx.coerceIn(0, THRESHOLDS_MB.size - 1)] * CleanerLogic.MB
        files = withContext(Dispatchers.IO) { CleanerLogic.queryLargeFiles(context, min, 50) }
        loading = false
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasPerm = CleanerLogic.hasAnyMediaPermission(context)
        reloadKey += 1
    }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val ids = pendingIds
        if (result.resultCode == Activity.RESULT_OK) {
            scope.launch {
                reloadFiles()
                val removed = ids.count { id -> files.none { it.id == id } }
                selected = emptySet()
                fileMessage = "$removed dosya silindi (liste yeniden okunarak doğrulandı)."
                OperationLog.add(context, "Cleaner", "Büyük dosya silme", removed > 0, "$removed dosya silindi")
            }
        } else {
            fileMessage = "Silme iptal edildi; hiçbir dosya silinmedi."
        }
    }

    LaunchedEffect(Unit) {
        storage = withContext(Dispatchers.IO) { CleanerLogic.sharedStorage() ?: CleanerLogic.internalStorage() }
        ownCache = withContext(Dispatchers.IO) { CleanerLogic.ownCacheBytes(context) }
    }

    LaunchedEffect(hasPerm, thresholdIdx, reloadKey) {
        if (hasPerm) reloadFiles()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "Phone Cleaner", subtitle = "Depolama analizi ve temizlik", onBack = onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            // --- Depolama ---
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Depolama")
                Spacer(Modifier.height(8.dp))
                val st = storage
                if (st == null) {
                    Text("Okunamadı", fontSize = 13.sp, color = CyberTextMuted)
                } else {
                    UsageBar(st.fraction)
                    Spacer(Modifier.height(8.dp))
                    InfoRow("Toplam", Format.bytes(st.total))
                    InfoRow("Kullanılan", Format.bytes(st.used))
                    InfoRow("Boş", Format.bytes(st.free))
                }
            }

            // --- Kendi önbellek ---
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                SectionTitle("Uygulamanın kendi önbelleği")
                Spacer(Modifier.height(6.dp))
                InfoRow("Boyut", ownCache?.let { Format.bytes(it) } ?: "Ölçülüyor…")
                if (cacheMessage != null) {
                    Spacer(Modifier.height(4.dp))
                    Text(cacheMessage ?: "", fontSize = 12.sp, color = CyberSuccess)
                }
                Spacer(Modifier.height(8.dp))
                CyberButton(
                    text = "Önbelleği temizle",
                    onClick = { confirmOwnCache = true },
                    enabled = (ownCache ?: 0L) > 0L,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            // --- Büyük dosyalar ---
            SectionTitle("Büyük dosyalar")
            CyberChipRow(
                options = THRESHOLDS_MB.map { "≥ $it MB" },
                selectedIndex = thresholdIdx,
                onSelect = { thresholdIdx = it },
            )
            if (!hasPerm) {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Büyük dosyaları listelemek için medya erişim izni gerekir. İzin yalnızca bu listeyi oluşturmak için kullanılır.",
                        fontSize = 12.sp,
                        color = CyberTextMuted,
                    )
                    Spacer(Modifier.height(8.dp))
                    CyberButton(
                        text = "İzin iste",
                        onClick = { permLauncher.launch(CleanerLogic.mediaPermissions()) },
                    )
                }
            } else {
                Text(
                    "Yalnızca sistemin medya olarak gösterdiği dosyalar listelenir; belgeler veya APK gibi dosyalar görünmeyebilir.",
                    fontSize = 11.sp,
                    color = CyberTextMuted,
                )
                if (loading) {
                    Text("Taranıyor…", fontSize = 13.sp, color = CyberTextMuted)
                } else if (files.isEmpty()) {
                    Text("Bu boyutta dosya bulunamadı.", fontSize = 13.sp, color = CyberTextMuted)
                }
                if (fileMessage != null) {
                    Text(fileMessage ?: "", fontSize = 12.sp, color = CyberWarning)
                }
                for (f in files) {
                    val isSel = selected.contains(f.id)
                    CyberCard(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            selected = if (isSel) selected - f.id else selected + f.id
                        },
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = isSel,
                                onCheckedChange = { checked ->
                                    selected = if (checked) selected + f.id else selected - f.id
                                },
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(f.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(f.path, fontSize = 11.sp, color = CyberTextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(Format.bytes(f.size) + "  •  " + Format.dateTime(f.dateMillis), fontSize = 11.sp, color = CyberTextMuted)
                            }
                        }
                    }
                }
                if (files.isNotEmpty()) {
                    if (Build.VERSION.SDK_INT >= 30) {
                        val selBytes = files.filter { selected.contains(it.id) }.sumOf { it.size }
                        CyberButton(
                            text = "Seçilenleri sil (${selected.size} • ${Format.bytes(selBytes)})",
                            onClick = { confirmDelete = true },
                            enabled = selected.isNotEmpty(),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    } else {
                        Text(
                            "Bu Android sürümünde (11 altı) uygulama içinden silme desteklenmiyor; dosyaları Dosyalar uygulamasından silebilirsin.",
                            fontSize = 12.sp,
                            color = CyberTextMuted,
                        )
                    }
                }
            }

            // --- Shizuku ile sistem önbelleği ---
            SectionTitle("Sistem önbelleği (Shizuku)")
            ShizukuGate(controller = shizuku, featureText = "Diğer uygulamaların önbelleğini görmek ve temizlemek") {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    CyberButton(
                        text = "Harici önbellekleri analiz et",
                        onClick = {
                            scope.launch {
                                sysBusy = true
                                caches = CleanerLogic.analyzeExternalCaches(context)
                                sysBusy = false
                            }
                        },
                        enabled = !sysBusy,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    val ca = caches
                    if (ca != null) {
                        Spacer(Modifier.height(8.dp))
                        if (ca.error != null) {
                            Text(ca.error, fontSize = 12.sp, color = CyberError)
                        }
                        for (e in ca.entries) {
                            InfoRow(e.packageName, Format.bytes(e.bytes))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Tüm uygulama önbelleklerini temizlemek uygulamaların ilk açılışını yavaşlatabilir.",
                        fontSize = 12.sp,
                        color = CyberTextMuted,
                    )
                    Spacer(Modifier.height(8.dp))
                    CyberButton(
                        text = "Tüm önbellekleri temizle",
                        onClick = { confirmTrim = true },
                        enabled = !sysBusy,
                        secondary = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (sysMessage != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(sysMessage ?: "", fontSize = 12.sp, color = if (sysOk) CyberSuccess else CyberError)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmOwnCache) {
        ConfirmDialog(
            title = "Önbellek temizlensin mi?",
            text = "Bu uygulamanın geçici önbellek dosyaları silinecek. Profilleriniz ve ayarlarınız etkilenmez.",
            confirmLabel = "Temizle",
            onConfirm = {
                confirmOwnCache = false
                scope.launch {
                    val before = ownCache ?: 0L
                    val error = withContext(Dispatchers.IO) { CleanerLogic.clearOwnCache(context) }
                    val after = withContext(Dispatchers.IO) { CleanerLogic.ownCacheBytes(context) }
                    ownCache = after
                    val freed = before - after
                    cacheMessage = if (error != null) {
                        "Temizleme hatası: $error"
                    } else if (freed > 0L) {
                        "${Format.bytes(freed)} temizlendi."
                    } else {
                        "Temizlenecek bir şey yoktu (ölçülen fark yok)."
                    }
                    OperationLog.add(context, "Cleaner", "Kendi önbelleği", error == null, cacheMessage ?: "")
                }
            },
            onDismiss = { confirmOwnCache = false },
        )
    }

    if (confirmDelete) {
        val count = selected.size
        ConfirmDialog(
            title = "Dosyalar silinsin mi?",
            text = "$count dosya silinecek. Sistem ayrıca onay isteyecek. Bu işlem geri alınamaz.",
            confirmLabel = "Devam",
            onConfirm = {
                confirmDelete = false
                val chosen = files.filter { selected.contains(it.id) }
                try {
                    val sender = CleanerLogic.createDeleteIntentSender(context, chosen.map { it.uri })
                    if (sender == null) {
                        fileMessage = "Bu cihazda silme isteği oluşturulamadı."
                    } else {
                        pendingIds = chosen.map { it.id }.toSet()
                        deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
                    }
                } catch (e: Exception) {
                    fileMessage = "Silme isteği başarısız: ${e.message}"
                    toast(context, "Silme isteği başarısız")
                }
            },
            onDismiss = { confirmDelete = false },
        )
    }

    if (confirmTrim) {
        ConfirmDialog(
            title = "Tüm önbellekler temizlensin mi?",
            text = "Sistem genelinde uygulama önbellekleri silinecek (pm trim-caches). Uygulamalar ilk açılışta yavaşlayabilir.",
            confirmLabel = "Temizle",
            onConfirm = {
                confirmTrim = false
                scope.launch {
                    sysBusy = true
                    val r = CleanerLogic.trimAllCaches(context)
                    sysMessage = r.message
                    sysOk = r.ok
                    storage = withContext(Dispatchers.IO) { CleanerLogic.sharedStorage() ?: CleanerLogic.internalStorage() }
                    sysBusy = false
                }
            },
            onDismiss = { confirmTrim = false },
        )
    }
}

@Composable
private fun UsageBar(fraction: Float) {
    val shape = RoundedCornerShape(6.dp)
    val f = fraction.coerceIn(0f, 1f)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(shape)
            .background(CyberOutline),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(f)
                .fillMaxHeight()
                .background(if (f > 0.9f) CyberError else CyberPrimary),
        )
    }
}
