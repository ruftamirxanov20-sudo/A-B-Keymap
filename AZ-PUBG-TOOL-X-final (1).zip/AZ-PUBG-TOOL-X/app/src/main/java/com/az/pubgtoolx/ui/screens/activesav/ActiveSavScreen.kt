package com.az.pubgtoolx.ui.screens.activesav

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.az.pubgtoolx.core.game.GamePackages
import com.az.pubgtoolx.core.log.OperationLog
import com.az.pubgtoolx.core.shizuku.ShizukuShell
import com.az.pubgtoolx.core.shizuku.ShizukuState
import com.az.pubgtoolx.core.util.Format
import com.az.pubgtoolx.core.util.copyToClipboard
import com.az.pubgtoolx.core.util.toast
import com.az.pubgtoolx.ui.components.ConfirmDialog
import com.az.pubgtoolx.ui.components.CyberButton
import com.az.pubgtoolx.ui.components.CyberCard
import com.az.pubgtoolx.ui.components.CyberChipRow
import com.az.pubgtoolx.ui.components.CyberTopBar
import com.az.pubgtoolx.ui.components.InfoRow
import com.az.pubgtoolx.ui.components.SectionTitle
import com.az.pubgtoolx.ui.components.ShizukuGate
import com.az.pubgtoolx.ui.components.rememberShizuku
import com.az.pubgtoolx.ui.screens.resolution.CheckLevel
import com.az.pubgtoolx.ui.screens.resolution.CheckLine
import com.az.pubgtoolx.ui.screens.resolution.StatusCard
import com.az.pubgtoolx.ui.theme.CyberTextMuted
import com.az.pubgtoolx.ui.theme.CyberWarning
import com.az.pubgtoolx.ui.theme.Dimens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private sealed class Origin {
    class Saf(val uri: Uri) : Origin()
    class Game(val packageName: String) : Origin()
}

@Composable
fun ActiveSavScreen(onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizuku = rememberShizuku()
    val shizukuState by shizuku.state.collectAsStateWithLifecycle()
    val shizukuReady = shizukuState == ShizukuState.READY

    var sourceIdx by remember { mutableIntStateOf(0) }
    var safUri by remember { mutableStateOf<Uri?>(null) }
    val games = remember { GamePackages.installed(context) }
    var gameIdx by remember { mutableIntStateOf(0) }

    var loaded by remember { mutableStateOf<LoadedFile?>(null) }
    var analysis by remember { mutableStateOf<SavAnalysis?>(null) }
    var showHex by remember { mutableStateOf(false) }

    var backups by remember { mutableStateOf<List<BackupItem>>(emptyList()) }
    var reloadBackups by remember { mutableIntStateOf(0) }
    var compareItem by remember { mutableStateOf<BackupItem?>(null) }
    var compareBytes by remember { mutableStateOf<ByteArray?>(null) }

    var statusText by remember { mutableStateOf<String?>(null) }
    var statusOk by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }

    var restoreTarget by remember { mutableStateOf<BackupItem?>(null) }
    var deleteTarget by remember { mutableStateOf<BackupItem?>(null) }
    var exportItem by remember { mutableStateOf<BackupItem?>(null) }

    val origin: Origin? = when (sourceIdx) {
        0 -> safUri?.let { Origin.Saf(it) }
        else -> games.getOrNull(gameIdx)?.let { Origin.Game(it.packageName) }
    }

    fun fail(text: String) {
        statusText = text
        statusOk = false
    }

    fun ok(text: String) {
        statusText = text
        statusOk = true
    }

    fun setLoaded(f: LoadedFile?) {
        loaded = f
        analysis = if (f != null) ActiveSavLogic.analyze(f.bytes) else null
        showHex = false
    }

    suspend fun readOrigin(o: Origin): Pair<LoadedFile?, String?> {
        return when (o) {
            is Origin.Saf -> withContext(Dispatchers.IO) { ActiveSavLogic.readSaf(context, o.uri) }
            is Origin.Game -> {
                val path = GamePackages.activeSavPath(o.packageName)
                val r = ShizukuShell.readFile(context, path)
                val bytes = r.bytes
                if (bytes == null) {
                    Pair(null, r.error ?: "Dosya okunamadı.")
                } else {
                    val st = ShizukuShell.exec(context, "stat -c %Y '$path'")
                    val sec = if (st.ok) st.output.trim().toLongOrNull() else null
                    Pair(LoadedFile(bytes, "Active.sav (${o.packageName})", sec?.let { it * 1000L }), null)
                }
            }
        }
    }

    suspend fun writeOrigin(o: Origin, bytes: ByteArray): String? {
        return when (o) {
            is Origin.Saf -> withContext(Dispatchers.IO) { ActiveSavLogic.writeSaf(context, o.uri, bytes) }
            is Origin.Game -> {
                val r = ShizukuShell.writeFile(context, GamePackages.activeSavPath(o.packageName), bytes)
                if (r.ok) null else (r.error ?: "Yazılamadı.")
            }
        }
    }

    LaunchedEffect(reloadBackups) {
        backups = withContext(Dispatchers.IO) { ActiveSavLogic.listBackups(context) }
    }

    LaunchedEffect(compareItem) {
        val item = compareItem
        compareBytes = if (item == null) null else withContext(Dispatchers.IO) {
            try {
                item.file.readBytes()
            } catch (e: Exception) {
                null
            }
        }
    }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            safUri = uri
            scope.launch {
                busy = true
                val (f, err) = readOrigin(Origin.Saf(uri))
                if (f == null) {
                    setLoaded(null)
                    fail(err ?: "Dosya okunamadı.")
                    OperationLog.add(context, "Active.sav", "Dosya okuma", false, err ?: "Hata")
                } else {
                    setLoaded(f)
                    ok("Dosya okundu: ${f.name} (${Format.bytes(f.bytes.size.toLong())}). Hiçbir şey değiştirilmedi.")
                    OperationLog.add(context, "Active.sav", "Dosya okuma", true, f.name)
                }
                busy = false
            }
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val item = exportItem
        exportItem = null
        if (uri != null && item != null) {
            scope.launch {
                val err = withContext(Dispatchers.IO) {
                    try {
                        ActiveSavLogic.exportTo(context, uri, item.file.readBytes())
                    } catch (e: Exception) {
                        "Yedek okunamadı: ${e.message}"
                    }
                }
                if (err == null) {
                    ok("Yedek dışa aktarıldı.")
                    OperationLog.add(context, "Active.sav", "Yedeği dışa aktarma", true, item.file.name)
                } else {
                    fail(err)
                    OperationLog.add(context, "Active.sav", "Yedeği dışa aktarma", false, err)
                }
            }
        }
    }

    fun readFromGame() {
        val o = origin
        if (o == null) {
            fail("Önce yüklü bir PUBG Mobile sürümü seçin.")
            return
        }
        scope.launch {
            busy = true
            val (f, err) = readOrigin(o)
            if (f == null) {
                setLoaded(null)
                fail(err ?: "Dosya okunamadı.")
                OperationLog.add(context, "Active.sav", "Oyun klasöründen okuma", false, err ?: "Hata")
            } else {
                setLoaded(f)
                ok("Dosya okundu (${Format.bytes(f.bytes.size.toLong())}). Hiçbir şey değiştirilmedi.")
                OperationLog.add(context, "Active.sav", "Oyun klasöründen okuma", true, f.name)
            }
            busy = false
        }
    }

    fun makeBackup() {
        val f = loaded ?: return
        val tag = when (val o = origin) {
            is Origin.Game -> o.packageName
            else -> "dosya"
        }
        scope.launch {
            busy = true
            val (file, err) = withContext(Dispatchers.IO) { ActiveSavLogic.saveBackup(context, f.bytes, tag) }
            if (file == null) {
                fail(err ?: "Yedek alınamadı.")
                OperationLog.add(context, "Active.sav", "Yedek alma", false, err ?: "Hata")
            } else {
                ok("Yedek alındı ve doğrulandı: ${file.name}")
                OperationLog.add(context, "Active.sav", "Yedek alma", true, file.name)
                reloadBackups += 1
            }
            busy = false
        }
    }

    fun restore(item: BackupItem) {
        val o = origin
        if (o == null) {
            fail("Hedef dosya belli değil. Önce bir dosya seçin veya oyun sürümünü seçin.")
            return
        }
        scope.launch {
            busy = true
            val data = withContext(Dispatchers.IO) {
                try {
                    item.file.readBytes()
                } catch (e: Exception) {
                    null
                }
            }
            if (data == null) {
                fail("Yedek dosyası okunamadı; hiçbir şey değiştirilmedi.")
                busy = false
                return@launch
            }
            // 1) Mevcut dosyanın güvenlik yedeği
            val (current, _) = readOrigin(o)
            val safetyBytes = current?.bytes
            if (safetyBytes != null) {
                val (sf, serr) = withContext(Dispatchers.IO) { ActiveSavLogic.saveBackup(context, safetyBytes, "guvenlik_oncesi") }
                if (sf == null) {
                    fail("Güvenlik yedeği alınamadığı için geri yükleme iptal edildi: ${serr ?: ""}")
                    OperationLog.add(context, "Active.sav", "Geri yükleme", false, "Güvenlik yedeği alınamadı")
                    busy = false
                    return@launch
                }
            }
            // 2) Yaz
            val werr = writeOrigin(o, data)
            if (werr != null) {
                var msg = "Geri yükleme başarısız: $werr"
                if (safetyBytes != null) {
                    val rb = writeOrigin(o, safetyBytes)
                    msg += if (rb == null) " Önceki dosya geri konuldu." else " Önceki dosya geri konulamadı: $rb"
                }
                fail(msg)
                OperationLog.add(context, "Active.sav", "Geri yükleme", false, msg)
                reloadBackups += 1
                busy = false
                return@launch
            }
            // 3) Geri okuyup doğrula
            val (after, rerr) = readOrigin(o)
            val expected = ActiveSavLogic.sha256(data)
            if (after != null && ActiveSavLogic.sha256(after.bytes) == expected) {
                setLoaded(after)
                ok("Geri yüklendi ve SHA-256 ile doğrulandı. Oyunun dosyayı kabul edip etmediği ayrıca oyunda denenmelidir.")
                OperationLog.add(context, "Active.sav", "Geri yükleme", true, item.file.name)
            } else {
                var msg = "Doğrulama başarısız: yazılan dosya beklenenle aynı değil (${rerr ?: "hash farklı"})."
                if (safetyBytes != null) {
                    val rb = writeOrigin(o, safetyBytes)
                    msg += if (rb == null) " Önceki dosya geri konuldu." else " Önceki dosya geri konulamadı: $rb"
                }
                fail(msg)
                OperationLog.add(context, "Active.sav", "Geri yükleme", false, msg)
            }
            reloadBackups += 1
            busy = false
        }
    }

    val canRestore = origin != null && (origin is Origin.Saf || shizukuReady)

    Column(modifier = Modifier.fillMaxSize()) {
        CyberTopBar(title = "Active.sav Manager", subtitle = "Analiz, yedek ve geri yükleme", onBack = onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(Dimens.SectionSpacing),
        ) {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Bu araç dosyanın içeriğini düzenlemez ve oyunun bütünlük/güvenlik kontrollerini aşmaya çalışmaz. Yalnızca seçtiğiniz dosyayı okur, inceler, yedekler ve yedeği geri yükler. Geri yüklemeden önce oyunu tamamen kapatın; oyun dosyayı reddedebilir veya sorun çıkarabilir, sorumluluk size aittir.",
                    fontSize = 12.sp,
                    color = CyberWarning,
                )
            }

            SectionTitle("Kaynak")
            CyberChipRow(
                options = listOf("Dosya seç", "Oyun klasörü (Shizuku)"),
                selectedIndex = sourceIdx,
                onSelect = {
                    if (it != sourceIdx) {
                        sourceIdx = it
                        setLoaded(null)
                        compareItem = null
                        statusText = null
                    }
                },
            )

            if (sourceIdx == 0) {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Sistem dosya seçicisinden Active.sav dosyasını (veya bir kopyasını) seçin. Android 13 ve üzerinde Android/data klasörü dosya seçicide görünmez; bu durumda dosyayı başka bir klasöre kopyalayın veya Shizuku kaynağını kullanın.",
                        fontSize = 12.sp,
                        color = CyberTextMuted,
                    )
                    Spacer(Modifier.height(8.dp))
                    CyberButton(
                        text = "Dosya seç",
                        onClick = { openLauncher.launch(arrayOf("*/*")) },
                        enabled = !busy,
                    )
                }
            } else {
                ShizukuGate(controller = shizuku, featureText = "Oyun klasöründeki dosyayı okumak") {
                    CyberCard(modifier = Modifier.fillMaxWidth()) {
                        if (games.isEmpty()) {
                            Text(
                                "Yüklü bir PUBG Mobile sürümü bulunamadı.",
                                fontSize = 13.sp,
                                color = CyberTextMuted,
                            )
                        } else {
                            CyberChipRow(
                                options = games.map { it.label },
                                selectedIndex = gameIdx,
                                onSelect = {
                                    gameIdx = it
                                    setLoaded(null)
                                },
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                GamePackages.activeSavPath(games[gameIdx.coerceIn(0, games.size - 1)].packageName),
                                fontSize = 10.sp,
                                color = CyberTextMuted,
                            )
                            Text(
                                "Shizuku ile en fazla 512 KB'lık dosyalar okunur/yazılır. Dosya yoksa veya konum farklıysa okuma hata verir.",
                                fontSize = 11.sp,
                                color = CyberTextMuted,
                            )
                            Spacer(Modifier.height(8.dp))
                            CyberButton(text = "Dosyayı oku", onClick = { readFromGame() }, enabled = !busy)
                        }
                    }
                }
            }

            if (statusText != null) {
                StatusCard(text = statusText ?: "", ok = statusOk)
            }

            // --- Dosya bilgisi ---
            val f = loaded
            val a = analysis
            if (f != null && a != null) {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    SectionTitle("Dosya bilgisi")
                    Spacer(Modifier.height(6.dp))
                    InfoRow("Ad", f.name)
                    InfoRow("Boyut", "${Format.bytes(a.size.toLong())} (${a.size} bayt)")
                    InfoRow("Son değişiklik", f.modified?.let { Format.dateTime(it) } ?: "Bilinmiyor")
                    InfoRow("Başlık (ilk 16 bayt)", a.headerHex)
                    InfoRow("Entropi", "%.2f / 8 bit".format(a.entropy))
                    InfoRow("Okunabilir metin oranı", "%${a.printablePercent}")
                    Spacer(Modifier.height(4.dp))
                    Text("SHA-256", fontSize = 12.sp, color = CyberTextMuted)
                    Text(a.sha256, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.height(8.dp))
                    CheckLine(
                        if (a.looksLikeGvas) CheckLevel.OK else CheckLevel.WARN,
                        if (a.looksLikeGvas) "Unreal Engine kayıt dosyası başlığı (GVAS) görünüyor" else "Bilinen UE kayıt başlığı (GVAS) yok; farklı biçimde, sıkıştırılmış veya şifreli olabilir",
                    )
                    CheckLine(
                        if (a.size > 0) CheckLevel.OK else CheckLevel.ERROR,
                        if (a.size > 0) "Dosya boş değil" else "Dosya boş",
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Bu analiz yalnızca ham baytlara bakar; kayıt içeriği yorumlanmaz.",
                        fontSize = 11.sp,
                        color = CyberTextMuted,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CyberButton(text = "Yedek al", onClick = { makeBackup() }, enabled = !busy)
                        CyberButton(
                            text = if (showHex) "Hex'i gizle" else "Hex önizleme",
                            onClick = { showHex = !showHex },
                            secondary = true,
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    CyberButton(
                        text = "SHA-256'yı kopyala",
                        onClick = {
                            copyToClipboard(context, "SHA-256", a.sha256)
                            toast(context, "Kopyalandı")
                        },
                        secondary = true,
                    )
                    if (showHex) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            ActiveSavLogic.hexDump(f.bytes),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                        )
                        if (f.bytes.size > 256) {
                            Text("İlk 256 bayt gösteriliyor.", fontSize = 10.sp, color = CyberTextMuted)
                        }
                    }
                }
            }

            // --- Yedekler ---
            SectionTitle("Yedekler")
            if (backups.isEmpty()) {
                Text("Henüz yedek yok.", fontSize = 13.sp, color = CyberTextMuted)
            }
            backups.forEach { item ->
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    Text(item.file.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${Format.bytes(item.size)} • ${Format.dateTime(item.modified)} • kaynak: ${item.tag}",
                        fontSize = 11.sp,
                        color = CyberTextMuted,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        CyberButton(
                            text = "Geri yükle",
                            onClick = { restoreTarget = item },
                            enabled = canRestore && !busy,
                        )
                        CyberButton(
                            text = if (compareItem?.file == item.file) "Karşılaştırmayı kapat" else "Karşılaştır",
                            onClick = { compareItem = if (compareItem?.file == item.file) null else item },
                            secondary = true,
                        )
                        CyberButton(
                            text = "Dışa aktar",
                            onClick = {
                                exportItem = item
                                exportLauncher.launch(item.file.name)
                            },
                            secondary = true,
                        )
                        CyberButton(text = "Sil", onClick = { deleteTarget = item }, secondary = true)
                    }
                }
            }
            if (backups.isNotEmpty() && !canRestore) {
                Text(
                    if (sourceIdx == 0) "Geri yüklemek için önce hedef dosyayı seçin." else "Geri yüklemek için Shizuku hazır olmalı ve oyun sürümü seçili olmalı.",
                    fontSize = 11.sp,
                    color = CyberTextMuted,
                )
            }

            // --- Değişiklik raporu + uyumluluk ---
            val cItem = compareItem
            val cBytes = compareBytes
            if (cItem != null && cBytes != null) {
                CyberCard(modifier = Modifier.fillMaxWidth()) {
                    SectionTitle("Değişiklik raporu ve uyumluluk")
                    Spacer(Modifier.height(4.dp))
                    Text("Yedek: ${cItem.file.name}", fontSize = 11.sp, color = CyberTextMuted)
                    val cur = loaded
                    if (cur == null) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Karşılaştırmak için önce mevcut dosyayı okuyun.",
                            fontSize = 12.sp,
                            color = CyberTextMuted,
                        )
                    } else {
                        val report = ActiveSavLogic.compare(cur.bytes, cBytes)
                        val bAnalysis = ActiveSavLogic.analyze(cBytes)
                        val cAnalysis = ActiveSavLogic.analyze(cur.bytes)
                        Spacer(Modifier.height(6.dp))
                        InfoRow("Mevcut boyut", "${report.sizeA} bayt")
                        InfoRow("Yedek boyutu", "${report.sizeB} bayt")
                        InfoRow("Farklı bayt", "${report.differingBytes} / ${report.comparedBytes}")
                        InfoRow("İlk fark konumu", report.firstDifference?.let { "bayt $it" } ?: "yok")
                        Spacer(Modifier.height(6.dp))
                        CheckLine(
                            if (report.identical) CheckLevel.OK else CheckLevel.WARN,
                            if (report.identical) "Mevcut dosya yedekle birebir aynı" else "Mevcut dosya yedekten farklı",
                        )
                        CheckLine(
                            if (bAnalysis.looksLikeGvas == cAnalysis.looksLikeGvas) CheckLevel.OK else CheckLevel.WARN,
                            if (bAnalysis.looksLikeGvas == cAnalysis.looksLikeGvas) "Dosya başlık türü aynı" else "Dosya başlık türleri farklı",
                        )
                        val sizeRatio = if (report.sizeA > 0) kotlin.math.abs(report.sizeA - report.sizeB) * 100 / report.sizeA else 100
                        CheckLine(
                            if (sizeRatio <= 25) CheckLevel.OK else CheckLevel.WARN,
                            if (sizeRatio <= 25) "Boyut farkı makul (%$sizeRatio)" else "Boyut farkı büyük (%$sizeRatio): farklı sürüm/bölge dosyası olabilir",
                        )
                        val o = origin
                        if (o is Origin.Game) {
                            CheckLine(
                                if (cItem.tag == o.packageName) CheckLevel.OK else CheckLevel.WARN,
                                if (cItem.tag == o.packageName) "Yedek aynı oyun sürümünden alınmış" else "Yedek farklı bir kaynaktan alınmış (${cItem.tag}); bu sürümle uyumsuz olabilir",
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(Dimens.SectionSpacing))
        }
    }

    val rt = restoreTarget
    if (rt != null) {
        val o = origin
        val warn = if (o is Origin.Game && rt.tag != o.packageName) "\n\nUyarı: Bu yedek \"${rt.tag}\" kaynağından alınmış, hedef \"${o.packageName}\"." else ""
        ConfirmDialog(
            title = "Yedek geri yüklensin mi?",
            text = "Hedef dosyanın üzerine yazılacak. Önce mevcut dosyanın otomatik güvenlik yedeği alınır, yazma sonrası SHA-256 ile doğrulanır; hata olursa önceki dosya geri konur. Oyunun tamamen kapalı olduğundan emin olun.$warn",
            confirmLabel = "Geri yükle",
            onConfirm = {
                restoreTarget = null
                restore(rt)
            },
            onDismiss = { restoreTarget = null },
        )
    }
    val dt = deleteTarget
    if (dt != null) {
        ConfirmDialog(
            title = "Yedek silinsin mi?",
            text = "${dt.file.name} kalıcı olarak silinecek.",
            confirmLabel = "Sil",
            onConfirm = {
                deleteTarget = null
                val deleted = ActiveSavLogic.deleteBackup(dt)
                if (compareItem?.file == dt.file) compareItem = null
                if (deleted) ok("Yedek silindi.") else fail("Yedek silinemedi.")
                reloadBackups += 1
            },
            onDismiss = { deleteTarget = null },
        )
    }
}
