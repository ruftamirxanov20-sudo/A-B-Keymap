package com.az.pubgtoolx.ui.screens.weapons

/**
 * Yalnızca birbirini tutan, genel bilgiler tutulur (kategori, mermi türü, atış modu).
 * Hasar, atış hızı, şarjör gibi sayısal değerler sürüme göre değiştiği ve kaynaklar birbirini
 * tutmadığı için YOKTUR; kullanıcı kendi değerlerini girer. null = doğrulanamadı.
 */
internal data class Weapon(
    val name: String,
    val category: String,
    val ammo: String?,
    val fireMode: String?,
)

internal object WeaponData {

    val CATEGORIES = listOf("AR", "SMG", "DMR", "Sniper", "LMG", "Shotgun", "Pistol")

    /** Silah kategorisi → Aim Lab modu. */
    fun aimMode(category: String): String = when (category) {
        "AR" -> "AR"
        "SMG" -> "SMG"
        "DMR" -> "PRECISION"
        "Sniper" -> "SNIPER"
        "Shotgun" -> "FLICK"
        "LMG" -> "TRACKING"
        else -> "REFLEX"
    }

    fun aimReason(category: String): String = when (category) {
        "AR" -> "Orta mesafe sürekli atış → AR modu"
        "SMG" -> "Yakın mesafe hızlı hedef değişimi → SMG modu"
        "DMR" -> "Tek tek isabetli atış → Precision modu"
        "Sniper" -> "Uzak mesafe tek atış → Sniper modu"
        "Shotgun" -> "Yakın mesafe ani hedef → Flick modu"
        "LMG" -> "Uzun süreli hedef takibi → Tracking modu"
        else -> "Hızlı tepki → Reflex modu"
    }

    val ALL: List<Weapon> = listOf(
        Weapon("M416", "AR", "5.56 mm", "Otomatik"),
        Weapon("SCAR-L", "AR", "5.56 mm", "Otomatik"),
        Weapon("QBZ", "AR", "5.56 mm", "Otomatik"),
        Weapon("G36C", "AR", "5.56 mm", "Otomatik"),
        Weapon("AUG A3", "AR", "5.56 mm", "Otomatik"),
        Weapon("M16A4", "AR", "5.56 mm", "Yarı / üçlü atış"),
        Weapon("Beryl M762", "AR", "7.62 mm", "Otomatik"),
        Weapon("AKM", "AR", "7.62 mm", "Otomatik"),
        Weapon("Groza", "AR", "7.62 mm", "Otomatik"),
        Weapon("Mk47 Mutant", "AR", "7.62 mm", "Yarı / üçlü atış"),

        Weapon("UMP", "SMG", null, "Otomatik"),
        Weapon("Vector", "SMG", ".45 ACP", "Otomatik"),
        Weapon("Thompson", "SMG", ".45 ACP", "Otomatik"),
        Weapon("Micro UZI", "SMG", "9 mm", "Otomatik"),
        Weapon("PP-19 Bizon", "SMG", "9 mm", "Otomatik"),

        Weapon("SKS", "DMR", "7.62 mm", "Yarı otomatik"),
        Weapon("SLR", "DMR", "7.62 mm", "Yarı otomatik"),
        Weapon("Mk14", "DMR", "7.62 mm", "Yarı / tam otomatik"),
        Weapon("Mini14", "DMR", "5.56 mm", "Yarı otomatik"),
        Weapon("QBU", "DMR", "5.56 mm", "Yarı otomatik"),
        Weapon("VSS", "DMR", "9 mm", "Yarı / tam otomatik"),

        Weapon("Kar98k", "Sniper", "7.62 mm", "Sürgülü"),
        Weapon("M24", "Sniper", "7.62 mm", "Sürgülü"),
        Weapon("AWM", "Sniper", ".300 Magnum", "Sürgülü"),
        Weapon("Win94", "Sniper", ".45 ACP", "Levye"),

        Weapon("M249", "LMG", "5.56 mm", "Otomatik"),
        Weapon("DP-28", "LMG", "7.62 mm", "Otomatik"),

        Weapon("S12K", "Shotgun", "12 kalibre", "Yarı otomatik"),
        Weapon("S1897", "Shotgun", "12 kalibre", "Pompalı"),
        Weapon("S686", "Shotgun", "12 kalibre", "Çift namlu"),
        Weapon("Sawed-off", "Shotgun", "12 kalibre", "Çift namlu"),

        Weapon("P1911", "Pistol", ".45 ACP", "Yarı otomatik"),
        Weapon("P92", "Pistol", "9 mm", "Yarı otomatik"),
        Weapon("R45", "Pistol", ".45 ACP", "Revolver"),
        Weapon("R1895", "Pistol", "7.62 mm", "Revolver"),
    )
}
