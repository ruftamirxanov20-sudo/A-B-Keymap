package com.az.pubgtoolx.core.log

import android.content.Context
import com.az.pubgtoolx.core.data.AppStore
import com.az.pubgtoolx.core.data.StoreKeys
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONObject

data class OpEntry(
    val time: Long,
    val module: String,
    val action: String,
    val success: Boolean,
    val detail: String,
)

/** Sistem işlemlerinin kalıcı kaydı (en yeni başta, en fazla 100 kayıt). */
object OperationLog {

    private const val MAX = 100

    fun flow(context: Context): Flow<List<OpEntry>> =
        AppStore.arrayFlow(context, StoreKeys.OP_LOG).map { list ->
            list.map {
                OpEntry(
                    time = it.optLong("time"),
                    module = it.optString("module"),
                    action = it.optString("action"),
                    success = it.optBoolean("success"),
                    detail = it.optString("detail"),
                )
            }
        }

    suspend fun add(context: Context, module: String, action: String, success: Boolean, detail: String) {
        val obj = JSONObject()
            .put("time", System.currentTimeMillis())
            .put("module", module)
            .put("action", action)
            .put("success", success)
            .put("detail", detail.take(300))
        AppStore.updateArray(context, StoreKeys.OP_LOG) { cur -> (listOf(obj) + cur).take(MAX) }
    }

    suspend fun clear(context: Context) {
        AppStore.remove(context, StoreKeys.OP_LOG)
    }
}
