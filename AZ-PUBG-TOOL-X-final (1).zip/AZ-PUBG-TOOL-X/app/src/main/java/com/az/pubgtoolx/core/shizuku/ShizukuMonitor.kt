package com.az.pubgtoolx.core.shizuku

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

/** Shizuku bağlantı durumu. Yalnızca gerçekten okunabilen durumlar vardır. */
enum class ShizukuState {
    NOT_INSTALLED,
    NOT_RUNNING,
    NEEDS_PERMISSION,
    PERMISSION_BLOCKED,
    READY,
}

const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"

/**
 * Shizuku binder / izin durumunu izler. Sistem işlemi yapmaz; sadece durum okur.
 * start() ve stop() ViewModel yaşam döngüsüne bağlıdır (sızıntı olmasın diye dinleyiciler kaldırılır).
 */
class ShizukuMonitor(private val context: Context) {

    private val _state = MutableStateFlow(computeState())
    val state: StateFlow<ShizukuState> = _state.asStateFlow()

    private val binderReceived = Shizuku.OnBinderReceivedListener { refresh() }
    private val binderDead = Shizuku.OnBinderDeadListener { refresh() }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    fun start() {
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)
        refresh()
    }

    fun stop() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionResult)
    }

    fun refresh() {
        _state.value = computeState()
    }

    /** Kullanıcıya Shizuku'nun kendi izin penceresini gösterir. */
    fun requestPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                refresh()
                return
            }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                refresh()
                return
            }
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
            refresh()
        }
    }

    private fun computeState(): ShizukuState {
        return try {
            if (!Shizuku.pingBinder()) {
                if (isShizukuInstalled()) ShizukuState.NOT_RUNNING else ShizukuState.NOT_INSTALLED
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                ShizukuState.READY
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                ShizukuState.PERMISSION_BLOCKED
            } else {
                ShizukuState.NEEDS_PERMISSION
            }
        } catch (_: Throwable) {
            ShizukuState.NOT_RUNNING
        }
    }

    private fun isShizukuInstalled(): Boolean {
        return try {
            context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE) != null
        } catch (_: Throwable) {
            false
        }
    }

    private companion object {
        const val REQUEST_CODE = 1001
    }
}
