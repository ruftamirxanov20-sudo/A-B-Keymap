package com.example.fpsayar

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GameTab(pkg: String, installed: List<Pair<String, String>>, onPkg: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableIntStateOf(1) }
    var fps by remember { mutableIntStateOf(60) }
    var bright by remember { mutableFloatStateOf(100f) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var applied by remember { mutableStateOf(false) }
    var cur by remember { mutableStateOf<GvasFile?>(null) }

    suspend fun reload() {
        cur = Sav.readParsed(ctx, pkg)
    }
    LaunchedEffect(pkg) { applied = false; reload() }

    GCard("OYUN SÜRÜMÜ") {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            installed.forEach { (name, p) -> GChip(name, pkg == p) { onPkg(p) } }
        }
    }

    GCard("GRAFİK") {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Mapping.qualities.forEachIndexed { i, n -> GChip(n, q == i) { q = i } }
        }
    }

    GCard("FPS") {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Mapping.fpsList.forEach { f -> GChip("$f", fps == f) { fps = f } }
        }
    }

    GCard("PARLAKLIK  •  ${bright.toInt()}") {
        Slider(
            value = bright, onValueChange = { bright = it }, valueRange = 10f..200f,
            colors = SliderDefaults.colors(
                thumbColor = Neon, activeTrackColor = Neon, inactiveTrackColor = Color(0xFF2A3556)
            )
        )
    }

    GButton(if (busy) "Yazılıyor..." else "UYGULA", enabled = !busy) {
        scope.launch {
            busy = true
            msg = try {
                Sav.apply(ctx, pkg, Choice(q, fps, bright.toInt()))
                applied = true
                "✓ ${Mapping.qualities[q]} • $fps FPS • parlaklık ${bright.toInt()} yazıldı."
            } catch (e: Exception) {
                applied = false
                "✗ ${e.message}"
            }
            reload()
            busy = false
        }
    }
    if (applied) GButton("OYUNU AÇ", accent = false) {
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
    }
    if (msg.isNotEmpty()) Text(msg)

    GCard("OYUNDAN ÖĞRET") {
        Hint(
            "Seçeneklerin dosyadaki karşılığı tahmini olabilir. Doğrulamak için oyunda ayarı seçin, " +
                "oyundan çıkın, 'Oku'ya basın, sonra yukarıda seçili grafik/FPS için 'öğret' deyin. " +
                "Bir kez öğretince uygulama bu telefonda hep doğru değeri yazar."
        )
        val g = cur
        Text(
            if (g == null) "Dosya okunamadı."
            else "Dosyada: grafik=${g.getInt("BattleRenderQuality")} • FPS seviyesi=${g.getInt("BattleFPS")} • " +
                "ince ayar=${g.getInt("FPSFineTuneNum")} • parlaklık=${g.getFloat("ScreenLightness")}"
        )
        GButton("Oku", accent = false) { scope.launch { reload() } }
        if (g != null) {
            GButton("Mevcut grafiği '${Mapping.qualities[q]}' olarak öğret", accent = false) {
                g.getInt("BattleRenderQuality")?.let {
                    Mapping.learnQuality(ctx, q, it); msg = "✓ Grafik '${Mapping.qualities[q]}' = $it öğrenildi."
                }
            }
            GButton("Mevcut FPS'i '$fps' olarak öğret", accent = false) {
                g.getInt("BattleFPS")?.let {
                    Mapping.learnLevel(ctx, fps, it); msg = "✓ $fps FPS = seviye $it öğrenildi."
                }
            }
            GButton("Öğrenilenleri sıfırla", accent = false) { Mapping.reset(ctx); msg = "Varsayılan eşleme geri yüklendi." }
        }
    }
}
