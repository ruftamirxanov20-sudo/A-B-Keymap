package com.example.fpsayar

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

data class Out(val code: Int, val text: String) {
    val ok get() = code == 0
}

object Shell {
    /** 0 = Shizuku çalışmıyor, 1 = izin gerekli, 2 = hazır */
    fun status(): Int = try {
        when {
            !Shizuku.pingBinder() -> 0
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> 1
            else -> 2
        }
    } catch (e: Throwable) { 0 }

    // Shizuku 13+ newProcess özel (private) olduğu için reflection ile çağrılır.
    private val method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).also { it.isAccessible = true }
    }

    suspend fun run(cmd: String): Out = withContext(Dispatchers.IO) {
        try {
            val p = method.invoke(null, arrayOf("sh", "-c", "( $cmd ) 2>&1"), null, null) as Process
            val text = p.inputStream.bufferedReader().readText().trim()
            Out(p.waitFor(), text)
        } catch (e: Throwable) {
            Out(-1, e.message ?: "hata")
        }
    }

    suspend fun physicalSize(): Pair<Int, Int>? =
        Regex("Physical size: (\\d+)x(\\d+)").find(run("wm size").text)
            ?.let { it.groupValues[1].toInt() to it.groupValues[2].toInt() }

    suspend fun physicalDensity(): Int? =
        Regex("Physical density: (\\d+)").find(run("wm density").text)
            ?.groupValues?.get(1)?.toInt()
}
