package com.example.fpsayar

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BackupTab(pkg: String, installed: List<Pair<String, String>>, onPkg: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }

    fun go(which: String) = scope.launch {
        msg = try { Sav.restore(ctx, pkg, which); "✓ Yedek geri yüklendi." } catch (e: Exception) { "✗ ${e.message}" }
    }

    GCard("OYUN SÜRÜMÜ") {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            installed.forEach { (name, p) -> GChip(name, pkg == p) { onPkg(p) } }
        }
    }
    GCard("YEDEKLER") {
        Hint(
            "UYGULA'ya her basışta Active.sav otomatik yedeklenir. İlk orijinal dosya hiç ezilmez, " +
                "ayrıca her seferde 'son' yedek güncellenir. Yedekler ${Sav.ROOT} klasöründedir."
        )
        GButton("Orijinal ayarlara dön") { go("orijinal") }
        GButton("Son yedeğe dön", accent = false) { go("son") }
        if (msg.isNotEmpty()) Text(msg)
    }
}
