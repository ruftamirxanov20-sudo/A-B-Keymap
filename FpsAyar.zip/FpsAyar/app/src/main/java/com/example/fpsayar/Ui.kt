package com.example.fpsayar

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Bg1 = Color(0xFF0A0E1A)
val Bg2 = Color(0xFF141C33)
val CardBg = Color(0xFF182036)
val Neon = Color(0xFF00E676)
val Cyan = Color(0xFF00E5FF)
val Orange = Color(0xFFFF6D00)
val Muted = Color(0xFF8E9AB8)
val OnNeon = Color(0xFF04210F)

@Composable
fun GCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardBg)
            .border(1.dp, Color(0x3300E676), RoundedCornerShape(20.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title, color = Neon, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.6.sp)
        content()
    }
}

@Composable
fun GButton(text: String, enabled: Boolean = true, accent: Boolean = true, onClick: () -> Unit) {
    val brush = if (accent) Brush.horizontalGradient(listOf(Neon, Cyan))
    else Brush.horizontalGradient(listOf(Color(0xFF26304D), Color(0xFF26304D)))
    Box(
        Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(14.dp)).background(brush)
            .alpha(if (enabled) 1f else 0.4f).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (accent) OnNeon else Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun GChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(12.dp)).background(if (selected) Neon else Color(0xFF222C48))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(text, color = if (selected) OnNeon else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun Hint(text: String) = Text(text, color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
