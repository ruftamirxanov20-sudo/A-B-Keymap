package com.example.fpsayar

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

private const val JUNK =
    "find /sdcard -type f \\( -iname '*.tmp' -o -iname '*.log' -o -iname '*.temp' \\) ! -path '/sdcard/Android/*'"

@Composable
fun CleanTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    fun freeBytes() = StatFs(Environment.getDataDirectory().path).availableBytes
    fun ramFree(): Long {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.availMem
    }
    fun fmt(b: Long) = Formatter.formatFileSize(ctx, b)

    var free by remember { mutableStateOf(freeBytes()) }
    var ram by remember { mutableStateOf(ramFree()) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var found by remember { mutableIntStateOf(0) }

    fun task(block: suspend () -> String) {
        scope.launch {
            busy = true
            msg = block()
            free = freeBytes(); ram = ramFree()
            busy = false
        }
    }

    GCard("DURUM") {
        Text("Boş depolama: ${fmt(free)}")
        Text("Boş RAM: ${fmt(ram)}")
    }

    GCard("TEMİZLİK") {
        GButton("Önbellekleri temizle", enabled = !busy) {
            task {
                val before = freeBytes()
                val r1 = Shell.run("pm trim-caches 100G")
                Shell.run("rm -rf /sdcard/Android/data/*/cache/* /sdcard/Android/data/*/code_cache/*")
                val gain = (freeBytes() - before).coerceAtLeast(0)
                "✓ Önbellek temizlendi • ${fmt(gain)} boşaldı" +
                    if (!r1.ok && r1.text.isNotBlank()) "\n(pm: ${r1.text.take(80)})" else ""
            }
        }
        GButton("Arka plan uygulamalarını kapat (RAM)", enabled = !busy, accent = false) {
            task {
                val before = ramFree()
                val r = Shell.run("am kill-all")
                val gain = (ramFree() - before).coerceAtLeast(0)
                if (r.ok) "✓ Arka plan kapatıldı • yaklaşık ${fmt(gain)} RAM boşaldı" else "✗ ${r.text.take(80)}"
            }
        }
        GButton("Gereksiz dosyaları tara", enabled = !busy, accent = false) {
            task {
                found = Shell.run("$JUNK | wc -l").text.trim().toIntOrNull() ?: 0
                if (found == 0) "Gereksiz dosya bulunamadı." else "$found gereksiz dosya bulundu (.tmp, .log, .temp)"
            }
        }
        if (found > 0) GButton("Bulunan $found dosyayı sil", enabled = !busy) {
            task {
                val before = freeBytes()
                Shell.run("$JUNK -delete; rm -rf /sdcard/DCIM/.thumbnails")
                found = 0
                "✓ Silindi • ${fmt((freeBytes() - before).coerceAtLeast(0))} boşaldı"
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (msg.isNotEmpty()) Text(msg)
        Hint("Fotoğraf, video ve belgelerinize dokunulmaz. Sadece önbellek, geçici ve günlük dosyaları silinir.")
    }
}
