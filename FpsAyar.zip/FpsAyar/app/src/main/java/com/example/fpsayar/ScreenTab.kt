package com.example.fpsayar

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScreenTab() {
    val scope = rememberCoroutineScope()
    var phys by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var dens by remember { mutableStateOf<Int?>(null) }
    var wT by remember { mutableStateOf("") }
    var hT by remember { mutableStateOf("") }
    var dT by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    var failPid by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        phys = Shell.physicalSize(); dens = Shell.physicalDensity()
        wT = phys?.first?.toString() ?: ""; hT = phys?.second?.toString() ?: ""
        dT = dens?.toString() ?: ""
    }

    fun apply(w: Int, h: Int, d: Int?) {
        scope.launch {
            // Güvenlik ağı: uygulama kapanırsa bile 12 sn sonra çözünürlük eski haline döner.
            failPid = Shell.run(
                "nohup sh -c 'sleep 12; wm size reset; wm density reset' >/dev/null 2>&1 & echo \$!"
            ).text.trim()
            Shell.run("wm size ${w}x$h" + (d?.let { "; wm density $it" } ?: ""))
            confirm = true
        }
    }

    fun ratioHeight(a: Int, b: Int): Int = ((phys?.first ?: 1080) * a / b / 2) * 2

    GCard("ÇÖZÜNÜRLÜK  •  İPAD MODU") {
        phys?.let { p -> Text("Ekran: ${p.first}x${p.second}  •  DPI: ${dens ?: 0}") }
        GButton("İPAD MODU (4:3)") { phys?.let { apply(it.first, ratioHeight(4, 3), null) } }
        Hint("Diğer oranlar")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("3:2" to (3 to 2), "16:10" to (16 to 10), "16:9" to (16 to 9), "18:9" to (18 to 9)).forEach { (n, r) ->
                GChip(n, false) { phys?.let { apply(it.first, ratioHeight(r.first, r.second), null) } }
            }
        }
        Hint("Özel değer")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val kb = KeyboardOptions(keyboardType = KeyboardType.Number)
            OutlinedTextField(wT, { wT = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("Genişlik") }, keyboardOptions = kb, singleLine = true)
            OutlinedTextField(hT, { hT = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("Yükseklik") }, keyboardOptions = kb, singleLine = true)
            OutlinedTextField(dT, { dT = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("DPI") }, keyboardOptions = kb, singleLine = true)
        }
        GButton("Uygula") {
            val w = wT.toIntOrNull(); val h = hT.toIntOrNull()
            if (w != null && h != null && w > 200 && h > 200) apply(w, h, dT.toIntOrNull()?.takeIf { it in 100..900 })
        }
        GButton("Varsayılana dön", accent = false) {
            scope.launch { Shell.run("wm size reset; wm density reset"); msg = "✓ Varsayılan çözünürlük geri geldi." }
        }
    }

    GCard("YENİLEME HIZI (Hz)") {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(60, 90, 120, 144).forEach { hz ->
                GChip("$hz Hz", false) {
                    scope.launch {
                        Shell.run("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz")
                        msg = "✓ $hz Hz istendi."
                    }
                }
            }
        }
        GButton("Yenileme hızını sıfırla", accent = false) {
            scope.launch {
                Shell.run("settings delete system min_refresh_rate; settings delete system peak_refresh_rate")
                msg = "✓ Sıfırlandı."
            }
        }
        Hint("Her cihaz desteklemeyebilir. Çalışmazsa ekran ayarlarından da kontrol edin.")
    }
    if (msg.isNotEmpty()) Text(msg)

    if (confirm) ConfirmDialog(
        onOk = { scope.launch { Shell.run("kill $failPid"); confirm = false } },
        onCancel = { scope.launch { Shell.run("kill $failPid; wm size reset; wm density reset"); confirm = false } }
    )
}

@Composable
fun ConfirmDialog(onOk: () -> Unit, onCancel: () -> Unit) {
    var left by remember { mutableIntStateOf(5) }
    LaunchedEffect(Unit) {
        while (left > 0) { delay(1000); left-- }
        onCancel() // süre doldu -> eski çözünürlük
    }
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Çözünürlük değişti") },
        text = { Text("Çözünürlüğü beğendiyseniz TAMAM'a basın. Süre bitince eski haline dönülür.\n\nKalan süre: $left") },
        confirmButton = { Button(onClick = onOk) { Text("TAMAM") } },
        dismissButton = { OutlinedButton(onClick = onCancel) { Text("İPTAL") } },
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    )
}
