package com.example.fpsayar

import android.content.Context
import java.io.File

/** Oyun sürümleri. */
val GAMES = listOf(
    "Global" to "com.tencent.ig", "KR" to "com.pubg.krmobile", "VN" to "com.vng.pubgmobile",
    "TW" to "com.rekoo.pubgm", "BGMI" to "com.pubg.imobile"
)

/**
 * Seçenek -> dosya değeri eşlemesi.
 * Varsayılanlar TAHMİNİDİR. Oyundan "öğret" ile telefon kendi değerini kaydeder.
 */
object Mapping {
    val qualities = listOf("Süper Akıcı", "Akıcı", "Dengeli", "HD", "HDR", "Ultra HDR")
    val fpsList = listOf(15, 30, 45, 60, 90, 120, 144)

    private fun p(c: Context) = c.getSharedPreferences("map", Context.MODE_PRIVATE)

    fun quality(c: Context, idx: Int) = p(c).getInt("q_$idx", idx)
    fun level(c: Context, fps: Int) = p(c).getInt(
        "lv_$fps", when (fps) { 15 -> 1; 30 -> 3; 45 -> 4; 60 -> 6; 90 -> 7; else -> 8 }
    )

    fun learnQuality(c: Context, idx: Int, v: Int) = p(c).edit().putInt("q_$idx", v).apply()
    fun learnLevel(c: Context, fps: Int, v: Int) = p(c).edit().putInt("lv_$fps", v).apply()
    fun reset(c: Context) = p(c).edit().clear().apply()
}

data class Choice(val quality: Int, val fps: Int, val brightness: Int)

/** Active.sav okuma / yazma (Shizuku üzerinden). */
object Sav {
    const val ROOT = "/sdcard/FPSAyar"

    fun file(pkg: String) =
        "/sdcard/Android/data/$pkg/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Active.sav"

    private fun tmp(c: Context): File {
        val dir = c.getExternalFilesDir(null) ?: c.filesDir
        dir.mkdirs()
        return File(dir, "tmp.sav")
    }

    suspend fun read(c: Context, pkg: String): ByteArray? {
        val t = tmp(c); t.writeBytes(ByteArray(0))
        val r = Shell.run("cat '${file(pkg)}' > '${t.absolutePath}'")
        return if (r.ok && t.length() > 0) t.readBytes() else null
    }

    suspend fun readParsed(c: Context, pkg: String): GvasFile? = read(c, pkg)?.let { GvasFile.parse(it) }

    private suspend fun write(c: Context, pkg: String, data: ByteArray) {
        val t = tmp(c); t.writeBytes(data)
        val r = Shell.run("cat '${t.absolutePath}' > '${file(pkg)}'")
        if (!r.ok) throw IllegalStateException("Yazılamadı: ${r.text}")
        val size = Shell.run("wc -c < '${file(pkg)}'").text.trim().toIntOrNull()
        if (size != data.size) throw IllegalStateException("Doğrulama başarısız, yedekten geri yükleyin")
    }

    suspend fun apply(c: Context, pkg: String, ch: Choice) {
        Shell.run("am force-stop $pkg")
        val bytes = read(c, pkg) ?: throw IllegalStateException(
            "Active.sav okunamadı. Oyunu bir kez açıp kapatın ve doğru sürümü seçin."
        )
        var g = GvasFile.parse(bytes) ?: throw IllegalStateException("Dosya formatı tanınmadı, değişiklik yapılmadı.")
        Shell.run(
            "mkdir -p $ROOT; [ -f $ROOT/Active_${pkg}_orijinal.bak ] || cp -f '${file(pkg)}' $ROOT/Active_${pkg}_orijinal.bak; " +
                "cp -f '${file(pkg)}' $ROOT/Active_${pkg}_son.bak"
        )
        val level = Mapping.level(c, ch.fps)
        val q = Mapping.quality(c, ch.quality)
        g = g.withInt("FPSLevel", level).withInt("BattleFPS", level).withInt("LobbyFPS", level)
            .withInt("FPSFineTuneNum", ch.fps).withBool("FPSFineTuneSwitch", ch.fps >= 60)
            .withInt("BattleRenderQuality", q).withInt("LobbyRenderQuality", q)
            .withFloat("ScreenLightness", ch.brightness / 100f)
        write(c, pkg, g.data)
    }

    /** which = "orijinal" veya "son" */
    suspend fun restore(c: Context, pkg: String, which: String) {
        val bak = "$ROOT/Active_${pkg}_$which.bak"
        if (!Shell.run("[ -f '$bak' ]").ok) throw IllegalStateException("Bu yedek bulunamadı")
        Shell.run("am force-stop $pkg")
        val r = Shell.run("cat '$bak' > '${file(pkg)}'")
        if (!r.ok) throw IllegalStateException("Geri yüklenemedi: ${r.text}")
    }
}
