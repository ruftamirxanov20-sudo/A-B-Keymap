package com.example.fpsayar

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Bir GVAS (UE4 save) özelliğinin dosyadaki yeri. */
class Prop(val name: String, val type: String, val valueOff: Int)

/**
 * Active.sav (GVAS) okuyucu / düzenleyici.
 * Sadece bilinen alanları değiştirir, geri kalan her bayta dokunmaz.
 * Alan yoksa "None" sonlandırıcısından hemen önce yenisini ekler.
 */
class GvasFile private constructor(
    val data: ByteArray,
    private val props: Map<String, Prop>,
    private val noneStart: Int
) {
    private fun bb() = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)

    fun getInt(n: String): Int? = props[n]?.takeIf { it.type == "IntProperty" }?.let { bb().getInt(it.valueOff) }
    fun getFloat(n: String): Float? = props[n]?.takeIf { it.type == "FloatProperty" }?.let { bb().getFloat(it.valueOff) }
    fun getBool(n: String): Boolean? = props[n]?.takeIf { it.type == "BoolProperty" }?.let { data[it.valueOff].toInt() != 0 }

    fun withInt(n: String, v: Int): GvasFile {
        val p = props[n]
        if (p != null) {
            check(p.type == "IntProperty") { "$n alanı beklenen türde değil" }
            val c = data.copyOf(); ByteBuffer.wrap(c).order(ByteOrder.LITTLE_ENDIAN).putInt(p.valueOff, v)
            return reparse(c)
        }
        return insert(fstr(n) + fstr("IntProperty") + le64(4) + byteArrayOf(0) + le32(v))
    }

    fun withFloat(n: String, v: Float): GvasFile {
        val p = props[n]
        if (p != null) {
            check(p.type == "FloatProperty") { "$n alanı beklenen türde değil" }
            val c = data.copyOf(); ByteBuffer.wrap(c).order(ByteOrder.LITTLE_ENDIAN).putFloat(p.valueOff, v)
            return reparse(c)
        }
        return insert(fstr(n) + fstr("FloatProperty") + le64(4) + byteArrayOf(0) + le32(java.lang.Float.floatToIntBits(v)))
    }

    fun withBool(n: String, v: Boolean): GvasFile {
        val b: Byte = if (v) 1 else 0
        val p = props[n]
        if (p != null) {
            check(p.type == "BoolProperty") { "$n alanı beklenen türde değil" }
            val c = data.copyOf(); c[p.valueOff] = b
            return reparse(c)
        }
        return insert(fstr(n) + fstr("BoolProperty") + le64(0) + byteArrayOf(b, 0))
    }

    private fun insert(add: ByteArray): GvasFile {
        val out = ByteArrayOutputStream(data.size + add.size)
        out.write(data, 0, noneStart); out.write(add); out.write(data, noneStart, data.size - noneStart)
        return reparse(out.toByteArray())
    }

    private fun reparse(c: ByteArray) = parse(c) ?: throw IllegalStateException("Dosya düzenlenirken bozuldu, yazılmadı")

    companion object {
        private val LE = ByteOrder.LITTLE_ENDIAN

        private fun le32(v: Int) = ByteBuffer.allocate(4).order(LE).putInt(v).array()
        private fun le64(v: Long) = ByteBuffer.allocate(8).order(LE).putLong(v).array()
        private fun le64(v: Int) = le64(v.toLong())
        private fun fstr(s: String): ByteArray {
            val b = s.toByteArray(Charsets.US_ASCII)
            return le32(b.size + 1) + b + byteArrayOf(0)
        }

        private fun readStr(b: ByteBuffer, p: Int): Pair<String, Int> {
            val n = b.getInt(p)
            return when {
                n == 0 -> "" to p + 4
                n > 0 -> {
                    val s = String(b.array(), p + 4, n - 1, Charsets.ISO_8859_1)
                    s to p + 4 + n
                }
                else -> {
                    val chars = -n
                    val s = String(b.array(), p + 4, (chars - 1) * 2, Charsets.UTF_16LE)
                    s to p + 4 + chars * 2
                }
            }
        }

        fun parse(d: ByteArray): GvasFile? = try { parseOrThrow(d) } catch (e: Exception) { null }

        private fun parseOrThrow(d: ByteArray): GvasFile? {
            if (d.size < 32 || String(d, 0, 4, Charsets.US_ASCII) != "GVAS") return null
            val b = ByteBuffer.wrap(d).order(LE)
            var p = 4 + 8 + 10                 // sürüm bilgileri + motor sürümü
            p = readStr(b, p).second            // motor sürüm metni
            p += 4                              // custom version formatı
            val cnt = b.getInt(p); p += 4
            require(cnt in 0..1000)
            p += cnt * 20
            p = readStr(b, p).second            // sınıf adı
            val props = LinkedHashMap<String, Prop>()
            while (true) {
                val start = p
                val (name, p1) = readStr(b, p); p = p1
                if (name == "None") return GvasFile(d, props, start)
                val (type, p2) = readStr(b, p); p = p2
                val size = b.getLong(p).toInt(); p += 8
                require(size >= 0)
                when (type) {
                    "BoolProperty" -> { props[name] = Prop(name, type, p); p += 2 }
                    "StructProperty" -> { p = readStr(b, p).second; p += 17 + size }
                    "ByteProperty", "EnumProperty", "ArrayProperty", "SetProperty" -> { p = readStr(b, p).second; p += 1 + size }
                    "MapProperty" -> { p = readStr(b, p).second; p = readStr(b, p).second; p += 1 + size }
                    else -> { props[name] = Prop(name, type, p + 1); p += 1 + size }
                }
                require(p <= d.size)
            }
        }
    }
}
