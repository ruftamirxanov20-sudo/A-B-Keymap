package com.example.fpsayar

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Neon)) {
                Surface(color = Color.Transparent, contentColor = Color.White) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var status by remember { mutableIntStateOf(Shell.status()) }
    var tab by remember { mutableIntStateOf(0) }
    val installed = remember {
        GAMES.filter { g ->
            try { ctx.packageManager.getPackageInfo(g.second, 0); true } catch (e: Exception) { false }
        }.ifEmpty { GAMES }
    }
    var pkg by remember { mutableStateOf(installed.first().second) }

    DisposableEffect(Unit) {
        val l1 = Shizuku.OnRequestPermissionResultListener { _, _ -> status = Shell.status() }
        val l2 = Shizuku.OnBinderReceivedListener { status = Shell.status() }
        val l3 = Shizuku.OnBinderDeadListener { status = Shell.status() }
        Shizuku.addRequestPermissionResultListener(l1)
        Shizuku.addBinderReceivedListener(l2)
        Shizuku.addBinderDeadListener(l3)
        onDispose {
            Shizuku.removeRequestPermissionResultListener(l1)
            Shizuku.removeBinderReceivedListener(l2)
            Shizuku.removeBinderDeadListener(l3)
        }
    }

    val tabs = listOf("🎮" to "Oyun", "📐" to "Ekran", "🧹" to "Temizlik", "💾" to "Yedek")

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg1, Bg2)))) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0F1526)) {
                    tabs.forEachIndexed { i, (icon, label) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Text(icon, fontSize = 20.sp) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedTextColor = Neon, unselectedTextColor = Muted,
                                indicatorColor = Color(0x3300E676)
                            )
                        )
                    }
                }
            }
        ) { pad ->
            Column(
                Modifier.padding(pad).statusBarsPadding().padding(horizontal = 16.dp)
                    .fillMaxSize().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("⚡ ", fontSize = 26.sp)
                    Text("FPS", fontSize = 26.sp, fontWeight = FontWeight.Black, color = Neon)
                    Text(" AYAR", fontSize = 26.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Spacer(Modifier.weight(1f))
                    Text(
                        when (status) { 0 -> "● Shizuku kapalı"; 1 -> "● İzin gerekli"; else -> "● Shizuku bağlı" },
                        color = if (status == 2) Neon else Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold
                    )
                }
                if (status != 2) {
                    GCard("SHIZUKU") {
                        Text(
                            if (status == 0) "Shizuku çalışmıyor. Shizuku uygulamasını açıp başlatın. Android 11 ve üstünde ilk başlatma için Wi-Fi'ye bağlı olmanız gerekir (internet şart değil)."
                            else "Uygulamanın Shizuku iznine ihtiyacı var."
                        )
                        if (status == 0) GButton("Shizuku'yu aç", accent = false) {
                            ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                                ?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        }
                        if (status == 1) GButton("İzin ver") {
                            try { Shizuku.requestPermission(0) } catch (_: Throwable) {}
                        }
                    }
                } else when (tab) {
                    0 -> GameTab(pkg, installed) { pkg = it }
                    1 -> ScreenTab()
                    2 -> CleanTab()
                    else -> BackupTab(pkg, installed) { pkg = it }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
