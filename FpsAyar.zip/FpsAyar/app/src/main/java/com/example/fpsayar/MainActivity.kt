package com.example.fpsayar

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.text.KeyboardOptions
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { App() } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    var status by remember { mutableIntStateOf(Shell.status()) }
    var tab by remember { mutableIntStateOf(0) }

    DisposableEffect(Unit) {
        val l1 = Shizuku.OnRequestPermissionResultListener { _, _ -> status = Shell.status() }
        val l2 = Shizuku.OnBinderReceivedListener { status = Shell.status() }
        val l3 = Shizuku.OnBinderDeadListener { status = Shell.status() }
        Shizuku.addRequestPermissionResultListener(l1)
        Shizuku.addBinderReceivedListener(l2)
        Shizuku.addBinderDeadListener(l3)
        onDispose {
            Shizuku.removeRequestPermissionResultListener(l1)
            Shizuku.removeBinderReceivedListener(l2)
            Shizuku.removeBinderDeadListener(l3)
        }
    }

    val tabs = listOf(
        "📐" to R.string.tab_res, "🔄" to R.string.tab_refresh,
        "🧹" to R.string.tab_clean, "💾" to R.string.tab_sav
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icon) }, label = { Text(stringResource(label)) }
                    )
                }
            }
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        stringResource(when (status) { 0 -> R.string.sh_off; 1 -> R.string.sh_perm; else -> R.string.sh_ready }),
                        Modifier.weight(1f)
                    )
                    if (status == 0) TextButton(onClick = {
                        ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                            ?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }) { Text(stringResource(R.string.sh_open)) }
                    if (status == 1) TextButton(onClick = {
                        try { Shizuku.requestPermission(0) } catch (_: Throwable) {}
                    }) { Text(stringResource(R.string.sh_grant)) }
                }
            }
            if (status != 2) {
                Text(stringResource(R.string.need_shizuku))
            } else when (tab) {
                0 -> ResolutionTab()
                1 -> RefreshTab()
                2 -> CleanTab()
                else -> SavTab()
            }
        }
    }
}

/* ---------------- Çözünürlük + iPad modu ---------------- */

@Composable
fun ResolutionTab() {
    val scope = rememberCoroutineScope()
    var phys by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var dens by remember { mutableStateOf<Int?>(null) }
    var wT by remember { mutableStateOf("") }
    var hT by remember { mutableStateOf("") }
    var dT by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    var failPid by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        phys = Shell.physicalSize(); dens = Shell.physicalDensity()
        wT = phys?.first?.toString() ?: ""; hT = phys?.second?.toString() ?: ""
        dT = dens?.toString() ?: ""
    }

    fun apply(w: Int, h: Int, d: Int?) {
        scope.launch {
            // Güvenlik ağı: uygulama kapanırsa bile 12 sn sonra çözünürlük eski haline döner.
            failPid = Shell.run(
                "nohup sh -c 'sleep 12; wm size reset; wm density reset' >/dev/null 2>&1 & echo \$!"
            ).text.trim()
            Shell.run("wm size ${w}x$h" + (d?.let { "; wm density $it" } ?: ""))
            confirm = true
        }
    }

    // Fiziksel genişliğe göre dikey oran: yükseklik = genişlik * a / b
    fun ratioHeight(a: Int, b: Int): Int = ((phys?.first ?: 1080) * a / b / 2) * 2

    phys?.let { p ->
        Text(stringResource(R.string.res_current, p.first, p.second, dens ?: 0))
        Button(
            onClick = { apply(p.first, ratioHeight(4, 3), null) },
            modifier = Modifier.fillMaxWidth()
        ) { Text(stringResource(R.string.res_ipad)) }

        Text(stringResource(R.string.res_presets))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("3:2" to (3 to 2), "16:10" to (16 to 10), "16:9" to (16 to 9), "18:9" to (18 to 9)).forEach { (name, r) ->
                OutlinedButton(onClick = { apply(p.first, ratioHeight(r.first, r.second), null) }) { Text(name) }
            }
        }
    }

    Text(stringResource(R.string.res_custom))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        val kb = KeyboardOptions(keyboardType = KeyboardType.Number)
        OutlinedTextField(wT, { wT = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text(stringResource(R.string.res_w)) }, keyboardOptions = kb, singleLine = true)
        OutlinedTextField(hT, { hT = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text(stringResource(R.string.res_h)) }, keyboardOptions = kb, singleLine = true)
        OutlinedTextField(dT, { dT = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text(stringResource(R.string.res_dpi)) }, keyboardOptions = kb, singleLine = true)
    }
    Button(
        onClick = {
            val w = wT.toIntOrNull(); val h = hT.toIntOrNull()
            if (w != null && h != null && w > 200 && h > 200) apply(w, h, dT.toIntOrNull()?.takeIf { it in 100..900 })
        },
        modifier = Modifier.fillMaxWidth()
    ) { Text(stringResource(R.string.apply)) }
    OutlinedButton(
        onClick = { scope.launch { Shell.run("wm size reset; wm density reset") } },
        modifier = Modifier.fillMaxWidth()
    ) { Text(stringResource(R.string.reset)) }

    if (confirm) ConfirmDialog(
        onOk = { scope.launch { Shell.run("kill $failPid"); confirm = false } },
        onCancel = { scope.launch { Shell.run("kill $failPid; wm size reset; wm density reset"); confirm = false } }
    )
}

@Composable
fun ConfirmDialog(onOk: () -> Unit, onCancel: () -> Unit) {
    var left by remember { mutableIntStateOf(5) }
    LaunchedEffect(Unit) {
        while (left > 0) { delay(1000); left-- }
        onCancel() // süre doldu -> eski çözünürlük
    }
    AlertDialog(
        onDismissRequest = {},
        title = { Text(stringResource(R.string.confirm_title)) },
        text = { Text(stringResource(R.string.confirm_text, left)) },
        confirmButton = { Button(onClick = onOk) { Text(stringResource(R.string.ok)) } },
        dismissButton = { OutlinedButton(onClick = onCancel) { Text(stringResource(R.string.cancel)) } },
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    )
}

/* ---------------- Yenileme hızı ---------------- */

@Composable
fun RefreshTab() {
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    val done = stringResource(R.string.done)
    Text(stringResource(R.string.hz_title))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(60, 90, 120, 144).forEach { hz ->
            Button(onClick = {
                scope.launch {
                    Shell.run("settings put system min_refresh_rate $hz; settings put system peak_refresh_rate $hz")
                    msg = "$hz Hz — $done"
                }
            }) { Text("$hz") }
        }
    }
    OutlinedButton(onClick = {
        scope.launch {
            Shell.run("settings delete system min_refresh_rate; settings delete system peak_refresh_rate")
            msg = done
        }
    }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.hz_reset)) }
    Text(stringResource(R.string.hz_note))
    if (msg.isNotEmpty()) Text(msg)
}

/* ---------------- Telefon temizleme ---------------- */

private const val JUNK =
    "find /sdcard -type f \\( -iname '*.tmp' -o -iname '*.log' -o -iname '*.temp' \\) ! -path '/sdcard/Android/*'"

@Composable
fun CleanTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    fun freeSpace() = Formatter.formatFileSize(ctx, StatFs(Environment.getDataDirectory().path).availableBytes)
    var free by remember { mutableStateOf(freeSpace()) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var found by remember { mutableIntStateOf(0) }
    val done = stringResource(R.string.done)
    val failed = stringResource(R.string.failed)

    fun task(block: suspend () -> String) {
        scope.launch { busy = true; msg = block(); free = freeSpace(); busy = false }
    }

    Text(stringResource(R.string.clean_free, free))
    Button(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = {
        task { if (Shell.run("pm trim-caches 100G").ok) done else failed }
    }) { Text(stringResource(R.string.clean_cache)) }
    Button(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = {
        task { if (Shell.run("am kill-all").ok) done else failed }
    }) { Text(stringResource(R.string.clean_bg)) }
    OutlinedButton(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = {
        task {
            found = Shell.run("$JUNK | wc -l").text.trim().toIntOrNull() ?: 0
            ""
        }
    }) { Text(stringResource(R.string.clean_scan)) }
    if (found > 0) {
        Text(stringResource(R.string.clean_found, found))
        Button(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = {
            task {
                Shell.run("$JUNK -delete; rm -rf /sdcard/DCIM/.thumbnails")
                found = 0; done
            }
        }) { Text(stringResource(R.string.clean_junk)) }
    }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    if (msg.isNotEmpty()) Text(msg)
}

/* ---------------- Active.sav yedek / şablon ---------------- */

private val GAMES = listOf(
    "Global" to "com.tencent.ig", "KR" to "com.pubg.krmobile", "VN" to "com.vng.pubgmobile",
    "TW" to "com.rekoo.pubgm", "BGMI" to "com.pubg.imobile"
)

@Composable
fun SavTab() {
    val scope = rememberCoroutineScope()
    var pkg by remember { mutableStateOf(GAMES[0].second) }
    var msg by remember { mutableStateOf("") }
    val done = stringResource(R.string.done)
    val failed = stringResource(R.string.failed)
    val dir = "/sdcard/Android/data/$pkg/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames"
    val bak = "/sdcard/FPSAyar/Active_$pkg.bak"
    val tpl = "/sdcard/FPSAyar/Sablon.sav"

    fun go(cmd: String) {
        scope.launch {
            val r = Shell.run("mkdir -p /sdcard/FPSAyar; am force-stop $pkg; $cmd")
            msg = if (r.ok) done else "$failed\n${r.text}"
        }
    }

    Text(stringResource(R.string.sav_game))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        GAMES.forEach { (name, p) ->
            FilterChip(selected = pkg == p, onClick = { pkg = p }, label = { Text(name) })
        }
    }
    Button(modifier = Modifier.fillMaxWidth(), onClick = { go("cp -f '$dir/Active.sav' '$bak'") }) {
        Text(stringResource(R.string.sav_backup))
    }
    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { go("cp -f '$bak' '$dir/Active.sav'") }) {
        Text(stringResource(R.string.sav_restore))
    }
    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { go("cp -f '$tpl' '$dir/Active.sav'") }) {
        Text(stringResource(R.string.sav_template))
    }
    Text(stringResource(R.string.sav_note))
    if (msg.isNotEmpty()) Text(msg)
}
