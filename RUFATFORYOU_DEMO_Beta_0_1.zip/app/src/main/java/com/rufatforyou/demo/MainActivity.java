package com.rufatforyou.demo;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private int playerColor = Color.rgb(255, 70, 70);
    private int weaponColor = Color.rgb(70, 180, 255);
    private int vehicleColor = Color.rgb(255, 200, 50);
    private int skyColor = Color.rgb(80, 120, 220);
    private LinearLayout root;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(22));
        root.setBackgroundColor(Color.rgb(16, 20, 29));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = new TextView(this);
        brand.setText("RUFATFORYOU");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(26);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, full());
        TextView subtitle = new TextView(this);
        subtitle.setText("PBC COLOR LAB • DEMO BETA 0.1");
        subtitle.setTextColor(Color.rgb(120, 220, 190));
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(5), 0, dp(20));
        root.addView(subtitle, full());

        addSection("COLOR OPTIONS");
        addColorRow("Player color", 0);
        addColorRow("Weapon color", 1);
        addColorRow("Vehicle color", 2);
        addColorRow("Sky color", 3);

        addSection("SETTINGS");
        Button copy = button("COPY PBC (DEMO EXPORT)");
        copy.setOnClickListener(v -> exportDemoConfig());
        root.addView(copy, full());

        status = new TextView(this);
        status.setText("Ready. This demo changes only its own color profile.");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(13);
        status.setPadding(0, dp(16), 0, dp(8));
        root.addView(status, full());

        TextView note = new TextView(this);
        note.setText("Important: This beta does NOT modify PUBG, inject code, or generate a real game ProgramBinaryCache. It exports a clearly labeled demo JSON profile so the UI and color selection can be tested safely.");
        note.setTextColor(Color.rgb(255, 205, 120));
        note.setTextSize(13);
        note.setPadding(dp(12), dp(12), dp(12), dp(12));
        note.setBackgroundColor(Color.rgb(38, 34, 25));
        root.addView(note, full());
    }
    private LinearLayout.LayoutParams full() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private void addSection(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.rgb(120, 220, 190));
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setTextSize(14);
        t.setPadding(0, dp(16), 0, dp(8));
        root.addView(t, full());
    }
    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(28, 120, 105)));
        return b;
    }
    private void addColorRow(String label, int which) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(6), dp(8), dp(6));
        row.setBackgroundColor(Color.rgb(30, 36, 48));
        LinearLayout.LayoutParams rp = full();
        rp.bottomMargin = dp(8);
        root.addView(row, rp);

        TextView name = new TextView(this);
        name.setText(label);
        name.setTextColor(Color.WHITE);
        name.setTextSize(15);
        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1));

        View swatch = new View(this);
        swatch.setBackgroundColor(getColorValue(which));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(32), dp(32));
        sp.rightMargin = dp(8);
        row.addView(swatch, sp);

        Button change = new Button(this);
        change.setText("Change");
        change.setAllCaps(false);
        change.setOnClickListener(v -> {
            int[] colors = {Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.MAGENTA, Color.CYAN, Color.WHITE, Color.BLACK, Color.rgb(255,128,0), Color.rgb(120,80,255)};
            final String[] names = {"Red", "Green", "Blue", "Yellow", "Magenta", "Cyan", "White", "Black", "Orange", "Violet"};
            new android.app.AlertDialog.Builder(this)
                .setTitle("Choose " + label)
                .setItems(names, (d, index) -> {
                    setColorValue(which, colors[index]);
                    swatch.setBackgroundColor(colors[index]);
                    status.setText(label + " set to " + names[index] + ". Export a demo profile from Settings.");
                }).show();
        });
        row.addView(change);
    }
    private int getColorValue(int which) {
        switch(which) { case 0: return playerColor; case 1: return weaponColor; case 2: return vehicleColor; default: return skyColor; }
    }
    private void setColorValue(int which, int c) {
        switch(which) { case 0: playerColor=c; break; case 1: weaponColor=c; break; case 2: vehicleColor=c; break; default: skyColor=c; }
    }
    private String hex(int color) { return String.format("#%08X", color); }

    private void exportDemoConfig() {
        try {
            JSONObject json = new JSONObject();
            json.put("app", "RUFATFORYOU");
            json.put("format", "DEMO_COLOR_PROFILE_NOT_PUBG_PBC");
            json.put("version", "0.1-beta");
            JSONObject colors = new JSONObject();
            colors.put("player", hex(playerColor));
            colors.put("weapon", hex(weaponColor));
            colors.put("vehicle", hex(vehicleColor));
            colors.put("sky", hex(skyColor));
            json.put("colors", colors);

            File base = new File(getExternalFilesDir(null), "RUFATFORYOU");
            if (!base.exists() && !base.mkdirs()) throw new Exception("Could not create output folder");
            File out = new File(base, "ProgramBinaryCache_DEMO.json");
            try (FileOutputStream fos = new FileOutputStream(out)) {
                fos.write((json.toString(2) + "\n").getBytes(StandardCharsets.UTF_8));
            }
            status.setText("Demo profile saved:\n" + out.getAbsolutePath() + "\nThis is not a real PUBG ProgramBinaryCache.");
            Toast.makeText(this, "Demo profile exported", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            status.setText("Export failed: " + e.getMessage());
            Toast.makeText(this, "Export failed", Toast.LENGTH_LONG).show();
        }
    }
}
