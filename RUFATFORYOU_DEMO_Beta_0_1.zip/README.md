# RUFATFORYOU Demo Beta 0.1

Phone-friendly Android Studio / GitHub Actions source project.

## What works
- Four color categories: Player, Weapon, Vehicle, Sky
- Simple color chooser
- Settings section with a demo export button
- Exports a JSON color profile into the app's external files directory under `RUFATFORYOU/ProgramBinaryCache_DEMO.json`

## Important limitations
This is a standalone UI prototype. It does **not** modify PUBG Mobile, inject into the game, or create a valid PUBG `ProgramBinaryCache`. The uploaded PBC archive's exact binary format has not been established, so it would be misleading to generate a file and call it a working PUBG cache. The export is intentionally named `ProgramBinaryCache_DEMO.json`.

No official PUBG artwork is bundled. No wallhack or other cheat implementation is included.

## Build
Open this folder in Android Studio or upload it to GitHub and use an Android Gradle workflow. Build output is `app/build/outputs/apk/debug/app-debug.apk`.
