package com.example.autofire

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private fun seek(p: LinearLayout, label: String, key: String, min: Int, max: Int, def: Int) {
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val v = prefs.getInt(key, def)
        val t = TextView(this).apply { text = "$label: $v" }
        val s = SeekBar(this).apply {
            this.max = max - min; progress = v - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, pr: Int, u: Boolean) {
                    t.text = "$label: ${pr + min}"
                    prefs.edit().putInt(key, pr + min).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        p.addView(t); p.addView(s)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48) }
        seek(root, "Buton boyutu (dp)", "size", 30, 120, 60)
        seek(root, "Tıklama aralığı (ms)", "interval", 20, 300, 60)
        seek(root, "Tıklama süresi (ms)", "duration", 1, 100, 20)
        root.addView(Button(this).apply {
            text = "1) Erişilebilirlik iznini aç"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2) Başlat (yüzen pencere)"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
            }
        })
        root.addView(Button(this).apply {
            text = "Durdur"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
