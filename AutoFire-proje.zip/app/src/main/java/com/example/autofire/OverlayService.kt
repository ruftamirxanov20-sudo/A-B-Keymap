package com.example.autofire

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var a: TextView
    private lateinit var b: TextView
    private lateinit var lock: TextView
    private val lpA by lazy { params(100, 600) }
    private val lpB by lazy { params(100, 300) }
    private val lpL by lazy { params(20, 20) }
    private var locked = false
    private val h = Handler(Looper.getMainLooper())
    private var firing = false

    private val fire = object : Runnable {
        override fun run() {
            if (!firing) return
            val c = getSharedPreferences("cfg", MODE_PRIVATE)
            val loc = IntArray(2); b.getLocationOnScreen(loc)
            TapService.instance?.tap(loc[0] + b.width / 2f, loc[1] + b.height / 2f,
                c.getInt("duration", 20).toLong())
            h.postDelayed(this, c.getInt("interval", 60).toLong())
        }
    }

    private fun params(x: Int, y: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun circle(label: String, color: Int, sizePx: Int) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 18f
        width = sizePx; height = sizePx
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        alpha = 0.7f
    }

    private fun drag(v: View, lp: WindowManager.LayoutParams, onTap: (() -> Unit)? = null,
                     onDown: (() -> Unit)? = null, onUp: (() -> Unit)? = null,
                     canDrag: () -> Boolean = { true }) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; onDown?.invoke() }
                MotionEvent.ACTION_MOVE -> if (canDrag()) {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true
                    lp.x = ox + dx; lp.y = oy + dy; wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    onUp?.invoke(); if (!moved && e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
                }
            }
            true
        }
    }

    private fun applyLock() {
        lock.text = if (locked) "🔒" else "🔓"
        a.alpha = if (locked) 0.9f else 0.7f
        // Kilitliyken B dokunmaya kapalı: sentetik tıklama B'nin altındaki ateş tuşuna geçsin
        lpB.flags = if (locked) lpB.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    else lpB.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        wm.updateViewLayout(b, lpB)
    }

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("af", "AutoFire", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        startForeground(1, Notification.Builder(this, "af").setContentTitle("AutoFire çalışıyor")
            .setSmallIcon(android.R.drawable.ic_menu_compass).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val sz = (getSharedPreferences("cfg", MODE_PRIVATE).getInt("size", 60) * resources.displayMetrics.density).toInt()
        a = circle("A", Color.parseColor("#D32F2F"), sz)
        b = circle("B", Color.parseColor("#1976D2"), sz)
        lock = circle("🔓", Color.DKGRAY, (40 * resources.displayMetrics.density).toInt())
        lpL.x = 20; lpL.y = 120

        // A: kilitliyken basılı tut = otomatik ateş; kilitsizken sürüklenir
        drag(a, lpA, onDown = { if (locked) { firing = true; h.post(fire) } },
             onUp = { firing = false; h.removeCallbacks(fire) }, canDrag = { !locked })
        // B: kilitsizken sürüklenir (ateş tuşunun üstüne koy)
        drag(b, lpB, canDrag = { !locked })
        // Kilit düğmesi
        drag(lock, lpL, onTap = { locked = !locked; applyLock() }, canDrag = { !locked })

        wm.addView(a, lpA); wm.addView(b, lpB); wm.addView(lock, lpL)
    }

    override fun onDestroy() {
        firing = false; h.removeCallbacks(fire)
        listOf(a, b, lock).forEach { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }
    override fun onBind(i: Intent?): IBinder? = null
}
